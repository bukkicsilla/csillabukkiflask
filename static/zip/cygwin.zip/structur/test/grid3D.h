double cube(double y);
int grid3D_main( );