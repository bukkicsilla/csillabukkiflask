#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "no_pvm_mpi.h"
#include "line.h"
#include "lineeps.h"
#include "star2D.h"
#include "grid2D.h"
#include "grid3D.h"
#include "star3D.h"


int main(int argc , char *argv[] ){
   
   if (argc == 1){
      fprintf(stderr,"Usage: %s <testnumber>\n", argv[0] );
      printf("1.      no_pvm_mpi.c    \n");
      printf("2.      line.c          \n"); 
      printf("3.      lineeps.c       \n");
      printf("4.      grid2D.c        \n");
      printf("5.      star2D.c        \n");
      printf("6.      grid3D.c        \n");
      printf("7.      star3D.c        \n");
      exit(-1);}
   
   //printf("Test ist :%d \n", atoi(argv[1]));
   
   switch( atoi( argv[1] ) )
   {
   case 0x01:
      printf("You have choisen no_pvm_mpi testprogram.\n");
      no_pvm_mpi_main();
      break;
   case 0x02:
      printf("You have choisen line testprogram.\n");
      line_main();
      break;
   case 0x03:
      printf("You have choisen lineeps testprogram.\n");
      lineeps_main();
      break;
   case 0x04:
      printf("You have choisen grid2D testprogram.\n");
      grid2D_main();
      break;
   case 0x05:
      printf("You have choisen star2D testprogram.\n");
      star2D_main();
      break;
   case 0x06:
      printf("You have choisen grid3D testprogram.\n");
      grid3D_main();
      break;
   case 0x07:
      printf("You have choisen star3D testprogram.\n");
      star3D_main();
   default:
      printf("There is no testprogramm with this number.\n");
      return 0;
   }
   
   return 0;
}
