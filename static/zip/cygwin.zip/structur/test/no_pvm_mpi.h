int no_pvm_mpi1_main();
