/* 
*  dpmta_test2.c - PVM process for DPMTA implentation
*     using the distributed calling scheme and an SPMD
*     programming model.
*
*  w. t. rankin
*  j. mccarthy
*
*  Copyright (c) 1995 Duke University
*  All rights reserved
*
*
*  this program will instantiate and initialize the slave processes,
*  spawn multiple copies of the process (if needed), each of which 
*  will send particle data, and collect the resulting particle information
*  for the parallel FMA algorithm implementation.  The data will be returned
*  to the master (initial) process and dumped into a file.
*
*  this program is an example of how to use the PMTA interface routines
*  instantiating and calling the PMTA slave processes from a distributed
*  application.
*
*  the input data for the DPMTA runs is collected from a file specified 
*  on the command line.
*
*/

static char rcsid[]="$Id: dpmta_test3.c,v 1.12 2001/02/10 03:56:30 wrankin Exp $";


/* include files */
#include <stdio.h>
#include <stdlib.h>

#ifdef USE_PVM
#include "pvm3.h"
#endif
#ifdef USE_MPI
#include "mpi.h"
#endif

#include "dpmta.h"
#include "dpmta_config.h"   /* only needed for timing code */

/* prototypes */ 
int Read_PDB( char *, int *, PmtaVector *,  PmtaVector *, PmtaParticlePtr * );
void Dump_Results( int, PmtaInitData *, PmtaParticlePtr, PmtaPartInfoPtr,
   PmtaPartInfoPtr );


int main( int argc, char *argv[] )
{
   int i, j;                 /* loop counters */

   int iter;                 /* number of iterations */
   int mypid;                /* my process number */
   int nprocs;               /* number of slave processes */

#ifdef USE_PVM
   int mytid;                /* process's task id */
   int ptid;                 /* parent's task id */
   int info;                 /* pvm return info */
   int tids[64];             /* tids of pmta slaves */
   int mtids[64];            /* tids of calling processes */
#endif

#ifdef USE_MPI
   MPI_Status stat;
   MPI_Request req;
#endif


   double ptmp;              /* temp particle flag */
   
   int num_parts;            /* total number of particles */
   PmtaVector v1;            /* cell vector 1 */
   PmtaVector v2;            /* cell vector 2 */
   PmtaVector v3;            /* cell vector 3 */

   PmtaVector cubecenter;    /* coordinates of cube center */

   PmtaInitData    initdata;     /* DPMTA Initialization Data */
   PmtaParticlePtr particlelist; /* array of particle information */
   PmtaPartInfoPtr forcelist;    /* array of resulting force information */
   PmtaPartInfoPtr flist_lj;     /* array of resulting LJ force info */

#ifdef DATADUMP
   PmtaParticlePtr mast_plist;    /* array of particle information */
   PmtaPartInfoPtr mast_flist;    /* array of resulting force information */
   PmtaPartInfoPtr mast_flist_lj; /* array of resulting LJ forces */
#endif

#if defined VIRIAL || defined OLDVIRIAL
   double vpot;
   PmtaVector vfor;
   double vpot_lj;
   PmtaVector vfor_lj;
#endif

   /*
   *  enroll and see if we are the initial process
   */

#ifdef USE_PVM
   mytid = pvm_mytid();
   pvm_catchout(stdout);
   pvm_catchout(stderr);
#ifdef CRAY
   mypid = pvm_get_PE(mytid);
   ptid = pvm_gettid("",0);
#else
   mypid = pvm_joingroup("GlobalGroup");
   ptid = pvm_gettid("GlobalGroup",0);
#endif
#endif

#ifdef USE_MPI
   MPI_Init(&argc,&argv);
   MPI_Comm_rank(MPI_COMM_WORLD,&mypid);
   MPI_Comm_size(MPI_COMM_WORLD,&nprocs);
#endif

   /*
   *  if we have the first process, then we need to take care
   *  of spawning (if needed) and distribution the processing
   *  parameters
   *
   *  if we are running mpi, then all processes can parse the
   *  command line and gather their processing parameters
   */

#ifdef USE_PVM
   if ( mypid == 0 ) {
#endif

      /* check and load command line arguments */
      if (argc != 9) {
         fprintf(stderr,
            "%s <#procs> <#lvls> <pdb-filename> <fft> <mp> <theta> <iter> <pbc>\n",
            argv[0]);
#ifdef USE_PVM
         pvm_exit();
#endif
#ifdef USE_MPI
	 MPI_Finalize();
#endif
         exit(-1);
      }

      nprocs = atoi(argv[1]);
      initdata.nprocs = nprocs;
      initdata.nlevels = atoi(argv[2]);
      initdata.fft = atoi(argv[4]);
      initdata.mp = atoi(argv[5]);
      initdata.theta = atof(argv[6]);
      iter = atoi(argv[7]);
      initdata.pbc = atoi(argv[8]);
      initdata.kterm = 0;
      if (initdata.pbc > 0) {
         initdata.kterm = initdata.pbc - 1;
         initdata.pbc = 1;
      }

      num_parts = atoi(argv[3]);

      /*
      *  spawn other procs, wait for all other procs to join the
      *  group and then set contents of tid array
      */
#ifdef USE_PVM
      mtids[0] = mytid;
      if ( nprocs > 1 ) {
         info = pvm_spawn("dpmta_test3", NULL, 0, "", nprocs-1, &(mtids[1]));
      }
#endif


      /* reads in the contents of the PDB file */
      info = Read_PDB(argv[3],&num_parts,&(v1),&(cubecenter),
		   &mast_plist);
      if ( info < 0 ) {
         fprintf(stderr,"Error [%d] reading PDB file\n", info);
         exit(-1);
      }

      /* distribute data to other processes */

      /* set other constants */

      initdata.mp_lj = 4;
      initdata.mp_vir = 4;
      initdata.fftblock = 4;
      initdata.v1.x = v1.x;
      initdata.v1.y = 0.0;
      initdata.v1.z = 0.0;
      initdata.v2.x = 0.0;
      initdata.v2.y = v1.y;
      initdata.v2.z = 0.0;
      initdata.v3.x = 0.0;
      initdata.v3.y = 0.0;
      initdata.v3.z = v1.z;
      initdata.cellctr.x = cubecenter.x;
      initdata.cellctr.y = cubecenter.y;
      initdata.cellctr.z = cubecenter.z;

#ifdef USE_PVM
      initdata.calling_num = nprocs;
      initdata.calling_tids = mtids; 
#endif

      initdata.loadstep = 4;
      initdata.loadstep = 0.25;

      /* adjust number of parts by the numbr of processes */
      num_parts = num_parts / nprocs;

#ifdef USE_MPI
   if ( mypid == 0 ) {
#endif

#ifdef DATADUMP
      /* allocate particle arrays */
      mast_plist =
         (PmtaParticlePtr)malloc(num_parts*nprocs*sizeof(PmtaParticle));
      if ( mast_plist == (PmtaParticlePtr)NULL ) {
         fprintf(stderr,"Error: Particle Malloc failed\n");
         exit(-1);
      }

      mast_flist =
         (PmtaPartInfoPtr)malloc(num_parts*nprocs*sizeof(PmtaPartInfo));
      if ( mast_flist == (PmtaPartInfoPtr)NULL ) {
         fprintf(stderr,"Error: Flist Malloc failed\n");
         exit(-1);
      }

#ifdef COMP_LJ
      mast_flist_lj =
         (PmtaPartInfoPtr)malloc(num_parts*nprocs*sizeof(PmtaPartInfo));
      if ( mast_flist_lj == (PmtaPartInfoPtr)NULL ) {
         fprintf(stderr,"Error: Flist_LJ Malloc failed\n");
         exit(-1);
      }
#else
      mast_flist_lj = (PmtaPartInfoPtr)NULL;
#endif
#endif

#ifdef USE_PVM 

      /*
       * if this is pvm, then we spawned our other copies of
       * the dpmta_test3 executable and we need to pass them
       * the operational parameters
       */
      /* send other processes the number of particles */
      for ( i=1; i<nprocs; i++ ) {
         pvm_initsend(PvmDataDefault);
         pvm_pkint(&nprocs,1,1);         
         pvm_pkint(&iter,1,1);         
         pvm_pkint(&num_parts,1,1);
         pvm_pkdouble(&v1.x,3,1);
         pvm_pkdouble(&v2.x,3,1);
         pvm_pkdouble(&v3.x,3,1);
         pvm_pkdouble(&cubecenter.x,1,1);
         pvm_pkdouble(&cubecenter.y,1,1);
         pvm_pkdouble(&cubecenter.z,1,1);
         pvm_send(mtids[i],1);
      } /* for i */

#endif

      /* initialize slave tasks */
      PMTAinit(&(initdata),initdata.nprocs);

   } /* if mypid=0 */

   else {  /* not initial process */

#ifdef USE_PVM

      /* get initial message from master */
      pvm_recv(ptid,1);
      pvm_upkint(&nprocs,1,1);
      pvm_upkint(&iter,1,1);
      pvm_upkint(&num_parts,1,1);
      pvm_upkdouble(&v1.x,3,1);
      pvm_upkdouble(&v2.x,3,1);
      pvm_upkdouble(&v3.x,3,1);
      pvm_upkdouble(&cubecenter.x,1,1);
      pvm_upkdouble(&cubecenter.y,1,1);
      pvm_upkdouble(&cubecenter.z,1,1);

#endif

      PMTAinit(NULL,nprocs);

   } /* else */


   /* now all calling processes need to register */
   PMTAregister();

   /****************************************************************
   *
   *  particle list processing -
   *
   *  create the particle lists and send each processor the list of 
   *  particles in each cell.
   *
   */

   /* allocate particle arrays */
   particlelist = (PmtaParticlePtr)malloc(num_parts * sizeof(PmtaParticle));
   if ( particlelist == (PmtaParticlePtr)NULL ) {
      fprintf(stderr,"Error: Particle Malloc failed\n");
      exit(-1);
   }

   forcelist = (PmtaPartInfoPtr)malloc(num_parts * sizeof(PmtaPartInfo));
   if ( particlelist == (PmtaParticlePtr)NULL ) {
      fprintf(stderr,"Error: Flist Malloc failed\n");
      exit(-1);
   }

   flist_lj = (PmtaPartInfoPtr)malloc(num_parts * sizeof(PmtaPartInfo));
   if ( particlelist == (PmtaParticlePtr)NULL ) {
      fprintf(stderr,"Error: Flist_LJ Malloc failed\n");
      exit(-1);
   }


   /* create all particles */

#ifdef WIN32
   srand((long)mypid);
#else
   srand48((long)mypid);
#endif

   ptmp = 1.0;
   
   for (i=0; i<num_parts; i++) {

#ifdef LOADBAL
      /* make a very non-uniform distribution */
      if ( (i%4) != 0 ) {
	 particlelist[i].p.x = (drand48() * 0.5) * v1.x * ptmp + cubecenter.x;
	 particlelist[i].p.y = (drand48() * 0.5) * v2.y * ptmp + cubecenter.y;
	 particlelist[i].p.z = (drand48() * 0.5) * v3.z * ptmp + cubecenter.z;
	 ptmp *= -1.0;
	 if ( ((i/2)%2) == 0 )
	    particlelist[i].q = 1.0;
	 else
	    particlelist[i].q = -1.0;

      }
      else {
	 particlelist[i].p.x = (drand48() - 0.5) * v1.x + cubecenter.x;
	 particlelist[i].p.y = (drand48() - 0.5) * v2.y + cubecenter.y;
	 particlelist[i].p.z = (drand48() - 0.5) * v3.z + cubecenter.z;
	 if ( (i%2) == 0 )
	    particlelist[i].q = 1.0;
	 else
	    particlelist[i].q = -1.0;
      }
#else
#ifdef WIN32
      particlelist[i].p.y = (((double)rand()/(double)RAND_MAX) - 0.5) * v2.y + cubecenter.y;
      particlelist[i].p.x = (((double)rand()/(double)RAND_MAX) - 0.5) * v1.x + cubecenter.x;
      particlelist[i].p.z = (((double)rand()/(double)RAND_MAX) - 0.5) * v3.z + cubecenter.z;
#else
      particlelist[i].p.x = (drand48() - 0.5) * v1.x + cubecenter.x;
      particlelist[i].p.y = (drand48() - 0.5) * v2.y + cubecenter.y;
      particlelist[i].p.z = (drand48() - 0.5) * v3.z + cubecenter.z;
#endif
      if ( (i%2) == 0 )
	 particlelist[i].q = 1.0;
      else
	 particlelist[i].q = -1.0;
#endif
      
      particlelist[i].a = 1.0e-3;
      particlelist[i].b = 1.0e-6;

      forcelist[i].f.x = 0.0;
      forcelist[i].f.y = 0.0;
      forcelist[i].f.z = 0.0;
      forcelist[i].v = 0.0;

      flist_lj[i].f.x = 0.0;
      flist_lj[i].f.y = 0.0;
      flist_lj[i].f.z = 0.0;
      flist_lj[i].v = 0.0;
   } /* for i */

   /*
   *  send particles out to slaves and wait for results
   *  repeat for multiple iterations
   */

   for (i=0; i<iter; i++) {

#ifdef LOADPAUSE
      if ( i == 10 ) {
	 if ( mypid == 0 ) {
	    char stmp[80];
	    fprintf(stdout,"Reached 10 iterations - Hit <return>\n");
	    fscanf(stdin,"%s",stmp);
	 }
#ifdef USE_PVM
	 pvm_barrier("DpmtaBalance",nprocs);
#endif
      }
#endif

      PMTAforce(num_parts, particlelist, forcelist, flist_lj);

#if defined VIRIAL || defined OLDVIRIAL
      if ( mypid == 0 ) {
	 PMTAvirial( &vpot, &vfor, &vpot_lj, &vfor_lj );
	 fprintf(stderr,"Virial = %f (%f,%f,%f)\n",
		 vpot, vfor.x, vfor.y, vfor.z);
#ifdef COMP_LJ
	 fprintf(stderr,"LJ Virial = %f (%f,%f,%f)\n",
		 vpot_lj, vfor_lj.x, vfor_lj.y, vfor_lj.z);
#endif
      } /* if mypid */
#endif
   } /* for i */

   /*
   *  send response back to master
   */
#ifdef DATADUMP

#ifdef USE_PVM
   pvm_initsend(PvmDataInPlace);
   pvm_pkdouble(&(particlelist[0].p.x),num_parts*6,1);
   pvm_pkdouble(&(forcelist[0].f.x),num_parts*4,1);
#ifdef COMP_LJ
   pvm_pkdouble(&(flist_lj[0].f.x),num_parts*4,1);
#endif
   pvm_send(ptid,2);
#endif /* USE_PVM */

#ifdef USE_MPI
   MPI_Isend(&(particlelist[0].p.x),num_parts*6,MPI_DOUBLE,
	     0,2,MPI_COMM_WORLD,&req);
   MPI_Isend(&(forcelist[0].f.x),num_parts*4,MPI_DOUBLE,
	     0,3,MPI_COMM_WORLD,&req);
#ifdef COMP_LJ
   MPI_Isend(&(flist_lj[0].f.x),num_parts*4,MPI_DOUBLE,
	     0,4,MPI_COMM_WORLD,&req);
#endif
#endif /* USE_MPI */

   /*
   *  if we are the master, unpack particle data and print out
   */
   if ( mypid == 0 ) {
      for ( i=0; i<nprocs; i++ ) {

#ifdef USE_PVM
	 pvm_recv(-1,2);
         pvm_upkdouble(&(mast_plist[i*num_parts].p.x),
            num_parts*6,1);
         pvm_upkdouble(&(mast_flist[i*num_parts].f.x),
            num_parts*4,1);
#ifdef COMP_LJ
         pvm_upkdouble(&(mast_flist_lj[i*num_parts].f.x),
            num_parts*4,1);
#endif
#endif /* USE_PVM */

#ifdef USE_MPI
         MPI_Recv(&(mast_plist[i*num_parts].p.x),
            num_parts*6,MPI_DOUBLE,i,2,MPI_COMM_WORLD,&stat);
         MPI_Recv(&(mast_flist[i*num_parts].f.x),
            num_parts*4,MPI_DOUBLE,i,3,MPI_COMM_WORLD,&stat);
#ifdef COMP_LJ
         MPI_Recv(&(mast_flist_lj[i*num_parts].f.x),
            num_parts*4,MPI_DOUBLE,i,4,MPI_COMM_WORLD,&stat);
#endif
#endif /* USE_MPI */

      } /* for i */

      Dump_Results((num_parts*nprocs), &(initdata), mast_plist,
		   mast_flist, mast_flist_lj);

   } /* if mypid */

#endif /* DATADUMP */

   /*
   *  clean up and kill off slaves
   */

   PMTAexit();

#ifdef USE_PVM
   pvm_exit();
#endif
#ifdef USE_MPI
   MPI_Finalize();
#endif

   exit(0);

} /* main */


/****************************************************************
 *
 *  Read_PDB - read the contents of a PDB file containing all
 *    water and return the values in the pmrticle list array.
 *
 *  Taken from the PME code.
 */

int Read_PDB( char *filename,
	      int *nparts,
	      PmtaVector *box,
	      PmtaVector *ctr,
	      PmtaParticlePtr *plist )
{

   int i;
   char s1[80];
   double cgh, cgo;
   FILE *infile;

   /* open the small.pdb file that contains box info and particle data */
   if ( (infile = fopen(filename,"r") ) == NULL) {
      fprintf(stderr,"Error: Unable to open PDB file %s\n",filename);
      return(-1); 
   }

   /* end open start reading (below) */
   fscanf(infile,"%s %s %s",s1,s1,s1); /* will read the text */
   fscanf(infile,"%lf",&(box->x));
   fscanf(infile,"%d",nparts);

   /* used for water system, hydrogen and oxygen charges */
   /* cgh = sqrt(332.17752) * .417; */
   /* cgo = cgh * -2.; */

   cgh = 0.410;
   cgo = -0.820;

   /* we are assuming a cubic box here with the origin at (0,0,0)*/
   box->y = box->x;
   box->z = box->x;
   ctr->x = box->x / 2.0;
   ctr->y = box->y / 2.0;
   ctr->z = box->z / 2.0;

   /* allocate main particle info array (x,y,z,cg)*/
   *plist = (PmtaParticlePtr)malloc( (*nparts) * sizeof(PmtaParticle) );
   if ( (*plist) == NULL ) {
      fprintf(stderr,"Error: could not alloc particle list\n");
      return(-1);
   }

   /* read from file8 small.pdb */
   for (i = 0; i < (*nparts); i+=3) {
      fscanf(infile, "%lf %lf %lf",
	     &(*plist)[i].p.x, &(*plist)[i].p.y, &(*plist)[i].p.z);
      fscanf(infile, "%lf %lf %lf",
	     &(*plist)[i+1].p.x, &(*plist)[i+1].p.y, &(*plist)[i+1].p.z);
      fscanf(infile, "%lf %lf %lf",
	     &(*plist)[i+2].p.x, &(*plist)[i+2].p.y, &(*plist)[i+2].p.z); 

      (*plist)[i].q = cgo;
      (*plist)[i+1].q = cgh;
      (*plist)[i+2].q = cgh;


#ifdef COMP_LJ
      /* eventually want to get the actual parameters here */
      (*plist)[i].a = 0.0;
      (*plist)[i].b = 0.0;
      (*plist)[i+1].a = 0.0;
      (*plist)[i+1].b = 0.0;
      (*plist)[i+2].a = 0.0;
      (*plist)[i+2].b = 0.0;
#endif

   } /* for i */

   fclose(infile);

   return(0);

} /* Read_PDB */
