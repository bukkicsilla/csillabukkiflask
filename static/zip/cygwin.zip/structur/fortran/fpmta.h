C
C  fpmta.h - include file for DPMTA common block 
C    data structures and prototype
C
C  w. t. rankin
C
C  Copyright (c) 1997 Duke University
C  All rights reserved
C
C

C  $Id: fpmta.h,v 1.1 1997/09/29 20:50:27 wrankin Exp $
C
C  revision history:
 *
C  $Log: fpmta.h,v $
C  Revision 1.1  1997/09/29 20:50:27  wrankin
C  example FORTRAN interface files
C
C
C

C
C  here is the common block equivolent of PmtaInitData
C

      COMMON/FPMTADAT/   int nprocs;
   int nlevels;
   int mp;
   int mp_lj;
   int fft;
   int fftblock;
   int pbc;
   int kterm;
   double theta;
   PmtaVector v1;
   PmtaVector v2;
   PmtaVector v3;
   PmtaVector cellctr;
   int calling_num;
   int *calling_tids;

