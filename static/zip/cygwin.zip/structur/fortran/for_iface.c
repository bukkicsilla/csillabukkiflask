/* 
*  foriface.c - Fortran wrapper interface to DPMTA routines
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this program provides a fortran interface to the DPMTA routines 
*  by remapping pointers between a fortran program and dpmta.
*
*/

static char rcsid[]="$Id: for_iface.c,v 1.1 1997/09/29 20:50:25 wrankin Exp $";

/*
 * revision history:
 *
 * $Log: for_iface.c,v $
 * Revision 1.1  1997/09/29 20:50:25  wrankin
 * example FORTRAN interface files
 *
 *
*/


/* include files */
#include <stdio.h>
#include "dpmta.h"


/****************************************************************
*
*  FPMTAINIT() - initialize slave processes.
*
*  this routine remaps the contents of the two init arrays into
*  an initialization data structure and passes the structure to
*  the real PMTA interface routine.
*
*/

int FPMTAINIT( int *initdata, int *rtn_tids)
{

   PMTAinit( (PmtaInitDataPtr)initdata, rtn_tids );

}


/****************************************************************
*
*  FPMTAREGISTER() - register application slave processes.
*
*  this routine simply calls the exising DPMTA register routine
*/


int FPMTAREGISTER()
{

   PMTAregister();

} /* FPMTAREGISTER*/



/****************************************************************
*
*  FPMTAFORCE - calculate colomb forces
*
* 
*/


int FPMTAFORCE( 
   int *nparts,
   double *particles,
   double *results,
   double *results_lj )
{

   int np;  /* not needed -- just for clarity */

   np = *nparts;

   PMTAforce( np, (PmtaParticlePtr)particles,
	      (PmtaPartInfoPtr)results, (PmtaPartInfoPtr)results_lj );

} /* FPMTAFORCE */


/****************************************************************
*
*  FPMTARESIZE() - resizes the simulation cube
*
*/

int FPMTARESIZE(
   double *pvector1,
   double *pvector2,
   double *pvector3,
   double *cellctr )
{
   PMTAresize( (PmtaVector *)pvector1, (PmtaVector *)pvector2,
	       (PmtaVector *)pvector3, (PmtaVector *)cellctr );

} /* FPMTARESIZE */


/****************************************************************
 *
 *  PMTAvirial() - return the virial sums from the previous
 *
 */

int FPMTAVIRIAL(
   double *vp,
   double *vf,
   double *vp_lj,
   double *vf_lj )
{

   PMTAvirial( vp, (PmtaVector *)vf, vp_lj, (PmtaVector *)vf_lj );

} /* FPMTAVIRIAL */


/****************************************************************
*
*  FPMTAEXIT() - shuts down slave processes
*
*
*/

int FPMTAEXIT()
{

   PMTAexit();

} /* PMTAexit */
