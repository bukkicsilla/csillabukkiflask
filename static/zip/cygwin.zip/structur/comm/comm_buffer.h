/*
 *  comm_buffer.h - type and constant definitions for communication
 *    buffer library
 *
 *  w. t. rankin
 *
 *  Copyright (C)2000 Bill Rankin
 *  All Rights Reserved
 *
 */

/*
 * RCS Id: $Id: comm_buffer.h,v 1.2 2001/01/19 01:40:06 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: comm_buffer.h,v $
 * Revision 1.2  2001/01/19 01:40:06  wrankin
 * many changes.  code in general now works.
 *
 * Revision 1.1  2000/04/04 02:37:49  wrankin
 * updates to support generic communication library
 *   - all message buffering done by application
 *   - support for eventual MPI implementation
 *
 *
 */

#ifndef _COMM_BUFFER_H_
#define _COMM_BUFFER_H_

/* allocation block size */

#define COMM_BLK_SIZE 256


/*
 * generic buffer structure - used for sending and receiving
 *   message data 
 *
 * note that the order of the parameters is important here, since we
 * pass arround pieces of this structure as arrays
 */

typedef struct commbuf {
   int imax;  /* max number of ints */
   int fmax;  /* max number of dbls */
   int isize;  /* number of ints currently stored*/
   int fsize;  /* number of dbls currently stored */
   int icurr;  /* pointer to current int */
   int fcurr;  /* pointer to current dbl */
   int *iarray;    /* data */
   double *farray; /* data */
} CommBuf;

typedef CommBuf *CommBufPtr;

CommBufPtr comm_buf_create( int inum, int fnum );
void comm_buf_clear( CommBufPtr cb );
void comm_buf_reset( CommBufPtr cb );
void comm_buf_delete( CommBufPtr cb );
void comm_buf_dump( CommBufPtr cb );
int comm_buf_resize( CommBufPtr cb, int inum, int fnum );
int comm_buf_addint( CommBufPtr cb, int *ibuff, int inum );
int comm_buf_adddbl( CommBufPtr cb, double *fbuff, int fnum );
int comm_buf_getint( CommBufPtr cb, int *ibuff, int inum );
int comm_buf_getdbl( CommBufPtr cb, double *fbuff, int fnum );

#endif

