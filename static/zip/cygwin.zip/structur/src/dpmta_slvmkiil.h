/* 
*  dpmta_slvmkiil.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_slvmkiil.h,v 3.1 1999/12/24 17:55:50 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_slvmkiil.h,v $
 * Revision 3.1  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.0  1999/04/01 16:45:34  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.1  1997/11/07 16:49:44  wrankin
 * massive cleanup of code.
 *  - ansi-fication and inclusion of prototypes
 *  - removed unused variables
 *  - all (except the test) code compiles with minimal warnings under gcc.
 *
 *
 */


/*
 * dpmta_slvmkiil.c
 */

#ifndef _DPMTA_SLV_MKIILH_
#define _DPMTA_SLVMKIIL_H_

void Init_Inv_Ilist();
void Make_Inv_Ilist();
void Delete_Inv_Ilist();


#endif
