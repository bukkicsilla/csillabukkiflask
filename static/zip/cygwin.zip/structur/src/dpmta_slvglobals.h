/****************************************************************
*
*  dpmta_slvglobals.h - global variables for dpmta pvm implementation
*
*  w. t. rankin
* 
*  these are the external references to the  global variables
*  used by the slave process during computation
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  note: dpmta_cell.h need to be included prior to this file in
*  all source modules.
*
*/

/*
 *  RCS info: $Id: dpmta_slvglobals.h,v 3.5 2001/02/10 03:54:28 wrankin Exp $
 *
 *  revision history:
 *
 *  $Log: dpmta_slvglobals.h,v $
 *  Revision 3.5  2001/02/10 03:54:28  wrankin
 *  additions to support new communications primitives
 *
 *  Revision 3.4  2000/04/04 02:38:06  wrankin
 *  updates to support generic communication library
 *    - all message buffering done by application
 *    - support for eventual MPI implementation
 *
 *  Revision 3.3  1999/12/24 17:55:50  wrankin
 *  wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 *  Revision 3.2  1999/05/17 19:56:48  wrankin
 *  additional cleanup for load balancing
 *
 *  Revision 3.1  1999/05/17 19:03:16  wrankin
 *  Added support for Load Balancing
 *
 *  Revision 3.0  1999/04/01 16:45:21  wrankin
 *  updates for DPMTA 3.0 - addition of load balancing code
 *
 *  Revision 2.4  1998/08/17 18:59:25  wrankin
 *  added flags for specification of PVM/MPI libraries
 *  renamed dpmta_pvm.h to dpmta_message.h and moved "pvm.h" ref
 *  removed static array references and added mallocs.
 *
 *  Revision 2.3  1998/08/04 15:14:17  wrankin
 *  added seperate multipole term parameter for virial code
 *
 *  Revision 2.2  1998/04/01 20:08:18  wrankin
 *  added support for HILBERT ordering
 *  general cleanup of code structure (more OOP if you will)
 *
 *  Revision 2.1  1997/11/07 16:49:28  wrankin
 *  massive cleanup of code.
 *   - ansi-fication and inclusion of prototypes
 *   - removed unused variables
 *   - all (except the test) code compiles with minimal warnings under gcc.
 *
 *
 *
*/

#ifndef _DPMTA_SLVGLOBALS_H_
#define _DPMTA_SLVGLOBALS_H_

#include "dpmta_cell.h"


extern CellPtrPtrPtr Dpmta_CellTbl;    /* pointer to cell table list */
extern IlistPtr      Dpmta_Intlist;    /* interaction list table */
extern HlistPtr      Dpmta_Hlist;      /* mpe transfer matrix table */
extern IIdata        Dpmta_IIlist;     /* inverse interaction data table */

/* message processing parameters */

extern int Dpmta_Pid;                  /* process id of slave */
extern int Dpmta_Nproc;                /* total number of processors */
extern int Dpmta_MyTid;                /* my task id */
extern int *Dpmta_Tids;                /* task ids of other slave processes */
extern int Dpmta_MasterTid;            /* task id of master process */

extern int Dpmta_CallingNum;           /* interface for slave particles */
extern int *Dpmta_CallingTids;         /* task ids of slave procs */

/* MPE processing parameters */

extern int Dpmta_NumLevels;            /* number of levels in spatial decomp */
extern int Dpmta_DownPassStart;        /* level where downward pass starts */
extern int Dpmta_FFT;                  /* FFT processing flag */
extern int Dpmta_PBC;                  /* periodic boundary cond. flag */
extern int Dpmta_Mp;                   /* # terms in the multipole exp (p) */
extern int Dpmta_FftBlock;             /* FFT Blocking size (b) */
extern int Dpmta_MpeSize;              /* # Complex in the multipole exp */
extern int Dpmta_LclSize;              /* # Complex in the local exp */

extern double Dpmta_Theta;             /* multipole acceptance parameter */
extern Vector Dpmta_CellVector1;       /* ||-piped vectors and magnitudes */
extern Vector Dpmta_CellVector2;
extern Vector Dpmta_CellVector3;
extern double Dpmta_MaxCellLen;	       /* length of longest side */
extern Vector Dpmta_CellCenter;        /* position of simulation cube center */
extern int Dpmta_Resize;               /* flag to initiate cell resizing */

#ifdef PIPED
extern double Dpmta_CV1Mag;
extern double Dpmta_CV2Mag;
extern double Dpmta_CV3Mag;
#endif

#ifdef COMP_LJ
extern int Dpmta_Mp_LJ;                /* # terms in mpe for LJ potential */
extern int Dpmta_MpeSize_LJ;           /* # Complex in the LJ multipole exp */
extern int Dpmta_LclSize_LJ;           /* # Complex in the LJ local exp */

extern MtypeLJ Dpmta_Temp_Mpe_LJ;      /* temporary LJ multipole exp buffer */
#endif

/* misc processing variables */

extern int *Dpmta_Sindex;              /* index to first owned cell */
extern int *Dpmta_Eindex;              /* index to last owned cells */
extern int *Dpmta_RMcell;              /* index to number of mpe's xfer'd */
extern int *Dpmta_RLcell;              /* index to number of loc's xfer'd */

extern Mtype Dpmta_Temp_Mpe;           /* temporary multipole exp buffer */

#if defined VIRIAL || defined OLDVIRIAL
extern Real Dpmta_Vpot;                /* virital potential */
extern Vector Dpmta_Vf;                /* virital force summation */
#ifdef VIRIAL
extern int Dpmta_Mp_Vir;               /* number of terms in the virial MPE */
#endif
#ifdef COMP_LJ
extern Real Dpmta_Vpot_LJ;             /* virital potential */
extern Vector Dpmta_Vf_LJ;             /* virital force summation */
#endif
#endif

extern int Dpmta_Power8[];             /* arrays to aid cell table indexing */
extern int Dpmta_LevelLocate[];        /* arrays to aid cell table indexing */

#ifdef MACROSCOPIC
extern int Dpmta_K;                    /* # of levels in macro expansion */
#endif

#ifdef LOADBAL
extern int Dpmta_LoadStep;             /* # of steps between load balancing */
extern double Dpmta_LoadWeight;        /* load balance weight factor */
#endif

#endif
