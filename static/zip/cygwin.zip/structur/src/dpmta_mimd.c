/*
*  dpmta_mimd - embedded DPMTA library interface.
*
*  w. t. rankin
*
*  Copyright (c) 1994 Duke University
*  All rights reserved
*
*  these routines merge the functionality of dpmta_slave and the
*  master interface routines into a single module for execution
*  on the Cray T3D/E or other platforms where a single executable
*  image is desired.
*
*/

static char rcsid[] = "$Id: dpmta_mimd.c,v 3.5 2001/02/10 03:54:28 wrankin Exp $";



/* include files */
#include <stdio.h>
#include "dpmta.h"
#include "dpmta_config.h"
#include "dpmta_cell.h"
#include "dpmta_slvglobals.h"
#include "comm.h"
#include "dpmta_message.h"


/*
*  some prototypes
*/

#include "dpmta_slviter.h"
#include "dpmta_slvcompute.h"
#include "dpmta_slvcomm.h"
#include "dpmta_slvscale.h"

#ifdef TIMEPERF
#include "dpmta_timer.h"
#endif

#ifdef LOADBAL
#include "dpmta_distload.h"
#endif


/****************************************************************
*
*  PMTAinit() - initialize slave processes.
*
*  PVM Specific:

*  this routine creates the PVM slave processes and sends them
*  initializing data.  it makes the assumption that all the 
*  processes are already enrolled in PVM.
*
*  for the MIMD interface, it is assumed that only one processor
*  will call this routine with a valid initdata.
*  the application is responsible for assuring this.
*
*  the extra 'nprocs' is required inorder to allow communication
*  setup for the slave processes (since the initdata only needs
*  to be setup for a single process.
*
*  this could be changed to require that all processes call PMTAinit()
*  with the same parameters, but the current way is simpler for
*  application programmers.
*
*
*/

int PMTAinit( PmtaInitDataPtr initdata, int np )
{

   /* initialize communications parameters and buffers */

   comm_init(np);
   comm_mkbuffs(2*np,2*np);

   Dpmta_Pid = comm_mypid();
   Dpmta_Nproc = np;


   /*
    *  send global data to other registered slaves
    *  (this is received later in this procedure...)
    *
    */

   if ( initdata != NULL ) {

      Send_Base_Info(initdata);

   } /* if initdata */


   /*
    * inititalization buffers or particle partitioning
    */

   Init_Local_Buffers();


   /*
   *  receive initialization message from master
   */

   Recv_Base_Info();


#ifdef TIMEPERF
   /*
    * inititialize data structure for performance timing
    */

   Init_Times(Dpmta_Pid,Dpmta_Nproc);
#endif

#ifdef LOADBAL
   /*
    * inititialize data structure for load balancing code.
    */

   Init_LoadBal(Dpmta_Pid,Dpmta_Nproc,
		Dpmta_LoadStep, Dpmta_NumLevels, Dpmta_LoadWeight);
#endif


   /*
   *  now each slave needs to process this information and
   *  allocate the appropriate data structures and constants.
   *  It would probably be best to rename this since we don't 
   *  use a master/slave architecture anymore.
   */

   Slave_Init();

   return(0);
}


/****************************************************************
*
*  PMTAregister() - register application slave processes.
*
*  all functions of this routine have been moved to PMTAinit().
*  the stub is left here for compatability.
*
*  this routine downloads the initializing data from the master process.
*  this data will be needed in order to correctly distribute the particle
*  data to the dpmta slaves.
*
*  for the T3D version, this process also performs all the initialzation
*  steps formerly run by the dpmta_slave slave process upon its creation.
*
*/

int PMTAregister()
{

   return (0);

} /* PMTAregister */



/****************************************************************
*
*  PMTAforce - calculate colomb forces
*
*  send particles to slaves
*  wait for returned forces and potential energies
*  prints out timing information if needed
* 
*/

int PMTAforce(
   int nparts,
   PmtaParticlePtr particles,
   PmtaPartInfoPtr results,
   PmtaPartInfoPtr results_lj )
{

   /*
   *  redistribute all particles to the other processors.
   *
   *  this routine also performs particle scaling to map the simulation
   *  space of the calling process to the unit cube of the slave.
   *
   *  we should probably combine this routine with the receive routine
   *  inorder to interleave the sending and receiving of messages so 
   *  that there is only one message out at any one time (saving 
   *  message buffers).
   */

#ifdef TIMEPERF
   Clear_Times();
   Start_E_Time(TIME_E_START);
   Start_CPU_Time();
#endif

   Send_Initial_Particles(nparts, particles,
      Dpmta_Nproc, Dpmta_Tids, Dpmta_NumLevels, Dpmta_Resize,
      (PmtaVector *)(&Dpmta_CellVector1), 
      (PmtaVector *)(&Dpmta_CellVector2), 
      (PmtaVector *)(&Dpmta_CellVector3),
      (PmtaVector *)(&Dpmta_CellCenter), Dpmta_Pid);

#ifdef TIMEPERF
   Store_E_Time(TIME_E_START,TIME_E_SENDINIT);
#endif
   
   /*
   *  receive particle lists and place in cell table.
   */

   Recv_Start_Iter();

#ifdef TIMEPERF
   Store_E_Time(TIME_E_START,TIME_E_RECVINIT);
#endif

   Slave_Start();

#ifdef TIMEPERF
   Store_CPU_Time(TIME_CPU_SORT);
#endif

   Rescale_Particles();


   /*
   *  compute all forces and potentials
   */

   Slave_Compute();


   /*
   *  send completed data to owning processor.
   */

   Rescale_Results();

   Send_Results();


   /*
   *  clean and free up the particle allocations and other data
   *  structures that are re-allocated on each time step.  perform
   *  this while the particle information is in transit.
   */

   Slave_Cleanup();


   /*
   *  collect the results from each other process
   */

   Recv_Final_Results(nparts, results, results_lj, Dpmta_Nproc);


#ifdef TIMEPERF
   Store_E_Time(TIME_E_START,TIME_E_END);
#endif

#ifdef TIMEPERF

   /*
   *  collect and dump timing results to master 
   */

   Collect_Print_Times();   

#endif

   
#ifdef LOADBAL
   /* exchange data needed to perform load balancing */
   Send_LoadBal();
   Recv_LoadBal();
#endif

   return(0);

} /* PMTAforce */



/****************************************************************
*
*  PMTAresize() - resizes the simulation cube
*
*  this routine changes the values of the CubeCenter and CubeLength
*  globals, which are used to scale the particle results.
*
*  note that for the distributed case, everybody need to make this call.
*
*
*/

int PMTAresize(
   PmtaVector *pvector1,
   PmtaVector *pvector2,
   PmtaVector *pvector3,   /* length of cell edges */
   PmtaVector *cellctr )   /* center of simulation cell */

{

   Dpmta_CellVector1.x = pvector1->x;
   Dpmta_CellVector1.y = pvector1->y;
   Dpmta_CellVector1.z = pvector1->z;
   Dpmta_CellVector2.x = pvector2->x;
   Dpmta_CellVector2.y = pvector2->y;
   Dpmta_CellVector2.z = pvector2->z;
   Dpmta_CellVector3.x = pvector3->x;
   Dpmta_CellVector3.y = pvector3->y;
   Dpmta_CellVector3.z = pvector3->z;
#ifdef PIPED
   Dpmta_CV1Mag = Vec_Mag(&Dpmta_CellVector1);
   Dpmta_CV2Mag = Vec_Mag(&Dpmta_CellVector2);
   Dpmta_CV3Mag = Vec_Mag(&Dpmta_CellVector3);
#endif
   Dpmta_CellCenter.x = cellctr->x;
   Dpmta_CellCenter.y = cellctr->y;
   Dpmta_CellCenter.z = cellctr->z;
   Dpmta_MaxCellLen = Max_CellLength();
   Dpmta_Resize = TRUE;

   return(0);

} /* PMTAresize */


/****************************************************************
 *
 *  PMTAvirial() - return the virial sums from the previous
 *
 */

int PMTAvirial(
   double *vp,
   PmtaVector *vf,
   double *vp_lj,
   PmtaVector *vf_lj )
{

#if defined VIRIAL || defined OLDVIRIAL
   Return_Virial(vp,vf,vp_lj,vf_lj);
   return(0);
#else
   return(-1);
#endif

} /* PMTAvirial */


/****************************************************************
*
*  PMTAexit() - shuts down slave processes
*
*  this routine calls routines to free up
*  all the dynamic memory buffers.
*
*/

int PMTAexit()
{

   /* free dynamic structures created by the multipole library */
   Slave_Delete();
   
   /* free up the MIMD local structures */
   Delete_Local_Buffers();
   
#ifdef TIMEPERF
   Delete_Times();
#endif

#ifdef LOADBAL
   /* hmmm, do we need to destroy the load bal stuff also? */
   Delete_LoadBal();
#endif

   /* clean up communication buffers */
   comm_delete();

   return(0);

}
