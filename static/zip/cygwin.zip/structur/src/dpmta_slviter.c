/****************************************************************
*
*  dpmta_slviter.c - iteration routines
*
*  w.t.rankin
*
*  Copyright (c) 2000 Duke University
*  All rights reserved
*
*  these routines handle the distribution and reception of data to
*  and from the slave processes during a single PMTA iteration.
*
*/

static char rcsid[]="$Id: dpmta_slviter.c,v 3.2 2001/02/10 03:54:28 wrankin Exp $";


#include <stdlib.h>
#include <stdio.h>
#include "dpmta.h"

/* dpmta configuration */

#include "dpmta_config.h"
#include "comm.h"
#include "dpmta_message.h"

/*
 * extern global vars
 */

#include "dpmta_slvglobals.h"

/*
 * extern prototyping
 */

#include "dpmta_distmisc.h"
#include "dpmta_distpart.h"
#include "dpmta_slvscale.h"

#ifdef TIMEPERF
#include "dpmta_timer.h"
#endif


/*
*  static communication buffers for sending and receiving
*  particle data.  Make them global so that we have them all
*  in one place in case we need to free() them later.
*/

static int         *SendPartCnt = NULL;
static int         SendPartCntSz = 0;
static int         *SendCellId = NULL;
static int         SendCellIdSz = 0;
static int         *SendIndex = NULL;
static int         SendIndexSz = 0;

static int         Msg_Term = -1;


#if defined VIRIAL || defined OLDVIRIAL
static double      VirPot;
static PmtaVector  VirForce;
#ifdef COMP_LJ
static double      VirPot_LJ;
static PmtaVector  VirForce_LJ;
#endif
#endif



/****************************************************************
*
*  Send_Base_Info() - send initialization message to other 
*    processors
*
*  message format:
*    4) int - number of levels in oct tree
*    5) int - fft flag
*    6) int - pbc flag
*    7) int - mp number
*    8) int - mp number for LJ (OPTIONAL)
*    9) dbl - theta, MAC separation parameter
*   10) int - number of macroscopic terms (OPTIONAL)
*   11) int - fft blocking factor
*   12) dbl[3][3] - cell size (edge vectors)
*   13) dbl[3] - cell size
*
*/


void Send_Base_Info( PmtaInitDataPtr idata )
{

   int i;              /* loop counter */

   for (i=0; i<(idata->nprocs); i++) {

      comm_newmsg(i);

      comm_pkint(i,&(idata->nlevels),1);
      comm_pkint(i,&(idata->fft),1);
      comm_pkint(i,&(idata->pbc),1);
      comm_pkint(i,&(idata->mp),1);
#ifdef COMP_LJ
      comm_pkint(i,&(idata->mp_lj),1);
#endif
#if defined VIRIAL || defined OLDVIRIAL
      comm_pkint(i,&(idata->mp_vir),1);
#endif
      comm_pkdbl(i,&(idata->theta),1);
#ifdef MACROSCOPIC
      comm_pkint(i,&(idata->kterm),1);
#endif
      comm_pkint(i,&(idata->fftblock),1);

      comm_pkdbl(i,&(idata->v1.x),3);
      comm_pkdbl(i,&(idata->v2.x),3);
      comm_pkdbl(i,&(idata->v3.x),3);
      comm_pkdbl(i,&(idata->cellctr.x),3);

      comm_send(i,i,MSG_INIT1);
   } /* for i */

} /* Send_Base_Info */


/****************************************************************
*
*  Recv_Base_Info() - receive initialization message from master
*    the master is defined at the process who called PMTAinit() with
*    the full set of operating parameters.
*
*  message format:
*    4) int - number of levels in oct tree
*    5) int - fft flag
*    6) int - mp number (and possible mp_lj, mp_vir);
*    7) dbl - theta, MAC separation parameter
*  7.1) int - k, the number of macroscopic levels
*    8) int - fft blocking factor
*    9) int - slave interface parameter
*   10) int[] - tids of calling slaves (if any)
*/

void Recv_Base_Info()
{

   Dpmta_Pid = comm_mypid();

   comm_recv(0,-1,MSG_INIT1);

   comm_upkint(0,&Dpmta_NumLevels,1);
   comm_upkint(0,&Dpmta_FFT,1);
   comm_upkint(0,&Dpmta_PBC,1);
   comm_upkint(0,&Dpmta_Mp,1);
#ifdef COMP_LJ
   comm_upkint(0,&Dpmta_Mp_LJ,1);
#endif
#if defined VIRIAL || defined OLDVIRIAL
   comm_upkint(0,&Dpmta_Mp_Vir,1);
#endif
   comm_upkdbl(0,&Dpmta_Theta,1);
#ifdef MACROSCOPIC
   comm_upkint(0,&Dpmta_K,1);
#endif
   comm_upkint(0,&Dpmta_FftBlock,1);

   comm_upkdbl(0,&(Dpmta_CellVector1.x),3);
   comm_upkdbl(0,&(Dpmta_CellVector2.x),3);
   comm_upkdbl(0,&(Dpmta_CellVector3.x),3);
   comm_upkdbl(0,&(Dpmta_CellCenter.x),3);
   Dpmta_MaxCellLen = Max_CellLength();

#ifdef PIPED
   Dpmta_CV1Mag = Vec_Mag(&Dpmta_CellVector1);
   Dpmta_CV2Mag = Vec_Mag(&Dpmta_CellVector2);
   Dpmta_CV3Mag = Vec_Mag(&Dpmta_CellVector3);
#endif

   /* force a resize */
   Dpmta_Resize = TRUE;

   if (Dpmta_PBC != 0)
      Dpmta_DownPassStart = 1;
   else
#ifdef CHILDCONV
      Dpmta_DownPassStart = 1;
#else
      Dpmta_DownPassStart = 2;
#endif

} /* Recv_Base_Info() */


/****************************************************************
*
*  Send_Initial_Particles() - sort and distribute particle lists
*     to the other processes.
*
*  this process will take a list of particles, scale the particle
*  positions to fit within the unit cube used by the slave process,
*  and then send the particles to the appropriate slave processes.
*
*  in order to sort the particle data, the routine simply traverses
*  the entire list once for each slave process and packs those
*  particles belonging to that slave.  not the most efficient 
*  distribution scheme, but it is simple and it works.
*
*/

void Send_Initial_Particles(
   int num_parts,               /* number of particles */
   PmtaParticlePtr part_table,  /* particle table */
   int num_proc,                /* number of slave processes */
   int *tids,                   /* array of slave process ids */
   int num_levels,              /* number of levels in oct-tree */
   int resize,                  /* resize flag */
   PmtaVector *cellvec1,        /* vectors representing cell edges */
   PmtaVector *cellvec2,
   PmtaVector *cellvec3,
   PmtaVector *cell_cen,        /* center coordinate of bounding cube */
   int procnum )                /* procnum of sending process */

{
   int    i,j;                  /* loop counters */
   int    num_cells;            /* number of cells */
   int    cells_per_proc;       /* number f cells per processor */
   int    sindex, eindex;       /* starting and ending cell indexes */
   int    cell_x, cell_y, cell_z;
   int    cell_id;              /* cell identifier */
   int    index;                /* cell index */
   int    proc_id;              /* processor id */
   int    wrap_mask;            /* mask to wrap cells around boundary */
   int    msg_type;             /* message type flag */
   double cell_edge;            /* number of cells per edge */
#ifdef PIPED
   double v2xv3dotp, v3xv1dotp, v1xv2dotp; /* Dot products */
   double shiftc;               /* Proportional shift of center */
   PmtaVector v1xv2, v2xv3, v3xv1; /* Cross Products */
   PmtaVector tmpc;             /* Temporary Parallelepiped center */
#else
   int    cell_mask;            /* cell id mask */
   PmtaVector cell_len;         /* length of cell cube sides */
#endif


   /*
   *  check to see if we have enough buffer space to hold the 
   *  particle and cell buffers and allocate extra if needed
   *
   */

   if ( num_parts > SendCellIdSz ) {
      SendCellId = (int *)realloc((void *)SendCellId,num_parts*sizeof(int));
      SendCellIdSz = num_parts;
      if ( SendCellId == (int *)NULL ) {
	 fprintf(stderr,"ERROR: realloc() %d parts in SendCellID failed\n",num_parts);
	 exit(-1);
      }
   }

   if ( num_parts > SendIndexSz ) {
      SendIndex = (int *)realloc((void *)SendIndex,num_parts*sizeof(int));
      SendIndexSz = num_parts;
      if ( SendIndex == (int *)NULL ) {
	 fprintf(stderr,"ERROR: realloc() %d parts in SendIndex failed\n",num_parts);
	 exit(-1);
      }
   }

   /*
   *  allocate cells index -  note that this should never have
   *  to be reallocated until we get into some funky reallocation
   *  scheme.  but is always pays to be prepared.
   */

   num_cells = (0x1) << (3 * (num_levels - 1));

   if ( num_cells > SendPartCntSz ) {
      SendPartCnt = (int *)realloc((void *)SendPartCnt,num_cells*sizeof(int));
      if ( SendPartCnt == (int *)NULL ) {
	 fprintf(stderr,"ERROR: realloc() %d parts in SendPartCnt failed\n",num_cells);
	 exit(-1);
      }
      SendPartCntSz = num_cells;
   }

   /* initailize counters */
   for (i=0; i<num_cells; i++) {
      SendPartCnt[i]=0;
   }

   /* compute cell numbers and size */
   cell_edge = (double)(0x1 << (num_levels-1));
   wrap_mask = (0x1 << (num_levels-1)) - 1;

#ifndef PIPED
   /* translate piped vectors to orthogonal values */
   cell_len.x = cellvec1->x;
   cell_len.y = cellvec2->y;
   cell_len.z = cellvec3->z;
#endif   


   /* cycle through all particles */
   for (i=0; i<num_parts; i++) {

#ifndef PIPED
      /* compute integer cell coordinates */
      cell_x = (int)(((part_table[i].p.x - cell_cen->x)/cell_len.x + 
               0.5) * cell_edge);
      cell_y = (int)(((part_table[i].p.y - cell_cen->y)/cell_len.y + 
               0.5) * cell_edge);
      cell_z = (int)(((part_table[i].p.z - cell_cen->z)/cell_len.z + 
               0.5) * cell_edge);

      /*
       * when running PBCs, it is a good thing if particles
       * do not get wrapped, but rather if they wander outside
       * the box, they are kept in the outter-most cell nearest
       * them.  otherwise it would look (to the simulation) that
       * a buch of particles were disappearing off of one side of
       * simulation space and appearing "magically" on the other.
       * this could play hell with constant energy sims.
       *
       * if the user wants wrapping, then simply define the PBC_WRAP
       * flag.
       */

#ifdef PBC_WRAP
      cell_x &= wrap_mask;
      cell_y &= wrap_mask;
      cell_z &= wrap_mask;
#else
      if ( cell_x < 0 )
	 cell_x = 0;
      if ( cell_x > wrap_mask )
	 cell_x = wrap_mask;
      if ( cell_y < 0 )
	 cell_y = 0;
      if ( cell_y > wrap_mask )
	 cell_y = wrap_mask;
      if ( cell_z < 0 )
	 cell_z = 0;
      if ( cell_z > wrap_mask )
	 cell_z = wrap_mask;
#endif

      /*
      *  build cell id from absolute coordinates
      *  there may be a more efficient way to do this
      */

      cell_mask = 0x1;
      cell_id = 0;
      cell_y = cell_y << 1;
      cell_z = cell_z << 2;
      for (j=1; j<num_levels; j++) {
         cell_id |= cell_x & cell_mask;
         cell_mask = cell_mask << 1;
         cell_id |= cell_y & cell_mask;
         cell_mask = cell_mask << 1;
         cell_id |= cell_z & cell_mask;
         cell_mask = cell_mask << 1;
         cell_x = cell_x << 2;
         cell_y = cell_y << 2;
	 cell_z = cell_z << 2;
      } /* for j */

#else
      /*
       * this is the code to handle the computation of cell
       * id's for the parallel piped implementation
       *
       * this code needs some massive cleaning up.  it is
       * inefficient (alot of the vector products should be
       * pulled out of the nparts loop) and doesn't do the
       * job right (although the answers are correct).
       *
       */
      
      tmpc.x = cell_cen->x;
      tmpc.y = cell_cen->y;
      tmpc.z = cell_cen->z;
      cell_id = 0;
      shiftc = 2.0;

      v2xv3.x = cellvec2->y * cellvec3->z - cellvec2->z * cellvec3->y;
      v2xv3.y = cellvec2->z * cellvec3->x - cellvec2->x * cellvec3->z;
      v2xv3.z = cellvec2->x * cellvec3->y - cellvec2->y * cellvec3->x;
 
      v3xv1.x = cellvec3->y * cellvec1->z - cellvec3->z * cellvec1->y;
      v3xv1.y = cellvec3->z * cellvec1->x - cellvec3->x * cellvec1->z;
      v3xv1.z = cellvec3->x * cellvec1->y - cellvec3->y * cellvec1->x;

      v1xv2.x = cellvec1->y * cellvec2->z - cellvec1->z * cellvec2->y;
      v1xv2.y = cellvec1->z * cellvec2->x - cellvec1->x * cellvec2->z;
      v1xv2.z = cellvec1->x * cellvec2->y - cellvec1->y * cellvec2->x;

      for(j=0;j<num_levels-1;j++)
      {
        cell_id = cell_id << 3;

        v2xv3dotp = ((part_table[i].p.x - tmpc.x) * v2xv3.x) +
                 ((part_table[i].p.y - tmpc.y) * v2xv3.y) +
                 ((part_table[i].p.z - tmpc.z) * v2xv3.z);
        v3xv1dotp = ((part_table[i].p.x - tmpc.x) * v3xv1.x) +
                 ((part_table[i].p.y - tmpc.y) * v3xv1.y) +
                 ((part_table[i].p.z - tmpc.z) * v3xv1.z);
        v1xv2dotp = ((part_table[i].p.x - tmpc.x) * v1xv2.x) +
                 ((part_table[i].p.y - tmpc.y) * v1xv2.y) +
                 ((part_table[i].p.z - tmpc.z) * v1xv2.z);

        if(v2xv3dotp<0) cell_x = 0;
        else cell_x = 1;

        if(v3xv1dotp<0) cell_y = 0;
        else cell_y = 1;

        if ( v1xv2dotp < 0 )
	   cell_z = 0;
        else
	   cell_z = 1;

        cell_y = cell_y << 1;
        cell_z = cell_z << 2;

        cell_id |= (cell_x | cell_y | cell_z);

        shiftc *= 2.0;

        if(cell_x)
        {
          tmpc.x += cellvec1->x/shiftc;
          tmpc.y += cellvec1->y/shiftc;
          tmpc.z += cellvec1->z/shiftc;
        }
        else
        {
          tmpc.x -= cellvec1->x/shiftc;
          tmpc.y -= cellvec1->y/shiftc;
          tmpc.z -= cellvec1->z/shiftc;
        }

        if(cell_y)
        {
          tmpc.x += cellvec2->x/shiftc;
          tmpc.y += cellvec2->y/shiftc;
          tmpc.z += cellvec2->z/shiftc;
        }
        else
        {
          tmpc.x -= cellvec2->x/shiftc;
          tmpc.y -= cellvec2->y/shiftc;
          tmpc.z -= cellvec2->z/shiftc;
        }

        if(cell_z)
        {
          tmpc.x += cellvec3->x/shiftc;
          tmpc.y += cellvec3->y/shiftc;
          tmpc.z += cellvec3->z/shiftc;
        }
        else
        {
          tmpc.x -= cellvec3->x/shiftc;
          tmpc.y -= cellvec3->y/shiftc;
          tmpc.z -= cellvec3->z/shiftc;
        }
      }
#endif

      /* store the cell index for the particle */
      SendCellId[i] = cell_id;

      /* map cell id to index */
      index = cell2index(cell_id,num_levels-1);
      SendIndex[i] = index;

      /* increment the partical counter for that cell */
      SendPartCnt[index] += 1;

   } /* for i */


   /*
   *  cycle through all slave processes, construct the appropriate 
   *  particle tables for each cell, and package the whole thing 
   *  up to ship it.
   *
   *  we will actually ship the thing in two parts, to give dpmta_slave
   *  something to do (allocate any particle arrays) while we are busy
   *  paking up messages
   *
   *  the message format(s):
   *
   *  MSG_PART1:
   *    0)   int        - message type
   *    0.1) int        - procnum
   *    1)   int        - cell resize flag
   *    1.1) real[3][3] - length of cell edges (if needed)
   *    1.2) real[3]    - position of cell center (if needed)
   *    2)   int        - the number of cells
   *    2.1) int        - the starting cell id
   *    3)   int[]      - number of particles per cell
   *
   *  MSG_PART2:
   *    0)   int        - message type
   *    0.1) int        - procnum
   *    1)   int        - cell id for first cell
   *    2)   int        - particle id
   *    3)   real[]     - array of particle data
   *    4+)  misc       - repeat 1-3 for each particle
   *    n)   int        - message terminator
   *
   */

   msg_type = MSG_PART1;

   for (i=0; i<num_proc; i++ ) {

      comm_newmsg(i);

      comm_pkint(i,&msg_type,1);
      comm_pkint(i,&procnum,1);

#ifdef BLUGGA
      /* ifndef EMBEDDED */
      comm_pkint(i,&resize,1);
      if (resize) {
         comm_pkdbl(i,&(cellvec1->x),3);
         comm_pkdbl(i,&(cellvec2->x),3);
         comm_pkdbl(i,&(cellvec3->x),3);
	 comm_pkdbl(i,&(cell_cen->x),3);
      }
#endif

      sindex = getsindex( i, num_levels-1 );
      eindex = geteindex( i, num_levels-1 );
      cells_per_proc = eindex - sindex + 1;

      comm_pkint(i,&(cells_per_proc),1);
      comm_pkint(i,&(sindex),1);
      comm_pkint(i,&(SendPartCnt[sindex]),cells_per_proc);
      
      comm_send(i,i,MSG_START);

   } /* for i */


   /*
    *  create the message buffers.
    */

   for (i=0; i<num_proc; i++ ) {
      comm_newmsg(num_proc+i);
   }

   /*
   *  cycle through each cell for that processor
   *  big assumption here that the particle data only
   *  consists of four (or six) doubles and no other data
   *  in the structure
   *
   *  note we also assume that we have more cells than
   *  processors in the bottom level of the tree.
   */

   /*
    * we can probably fold this into the allocation loop
    */
   
   msg_type = MSG_PART2;
   for (i=0; i<num_proc; i++ ) {
      comm_pkint(num_proc+i,&msg_type,1);
      comm_pkint(num_proc+i,&procnum,1);
   } /* for i */


   for (i=0; i<num_parts; i++) {
      index = SendIndex[i];
      proc_id = getslvpid_indx( num_levels-1, index );
      cell_id = SendCellId[i];
      
      comm_pkint(num_proc+proc_id,&cell_id,1);
      comm_pkint(num_proc+proc_id,&i,1);

#ifdef COMP_LJ
      comm_pkdbl(num_proc+proc_id,&(part_table[i].p.x),6);
#else
      comm_pkdbl(num_proc+proc_id,&(part_table[i].p.x),4);
#endif

   } /* for i */

   
   /*
    * terminate the messages and send them
    */

   for (i=0; i<num_proc; i++) {
      comm_pkint(num_proc+i,&(Msg_Term),1);
      comm_send(num_proc+i,i,MSG_START);
   } /* for i */

} /* end procedure */



/****************************************************************
*
*  Recv_Final_Results() - receives completed data from slaves
*
*  we may wish to modify the message format to pass the information
*  back by cells.
*
*  message format:
*     0) real[]  - virial data (if needed)
*     1) int     - particle id number
*     2) real[]  - array of force data for particle
*     3+) repeat 1-2 for each cell
*     n) int     - message terminator
*
*  after reception of messages, we need to scale the results by the
*  length of the simulation space.
*
*/

void Recv_Final_Results(
   int num_parts,                /* number of particles to generate */
   PmtaPartInfoPtr fresults,     /* array of force results */
   PmtaPartInfoPtr fresults_lj,  /* array of LJ force results */
   int nprocs )                  /* number of slave processes */
{

   int i;                    /* loop counters */
   int partid;               /* particle index */


#if defined VIRIAL || defined OLDVIRIAL
   double ftmp[4];           /* virial values from slaves */
#endif

   /*
   *  cycle through and receive particle message from each
   *  processor, placing the results in the receive buffer
   */

#if defined VIRIAL || defined OLDVIRIAL
   VirPot = 0.0;
   VirForce.x = 0.0;
   VirForce.y = 0.0;
   VirForce.z = 0.0;
#ifdef COMP_LJ
   VirPot_LJ = 0.0;
   VirForce_LJ.x = 0.0;
   VirForce_LJ.y = 0.0;
   VirForce_LJ.z = 0.0;
#endif
#endif

   for (i=0; i<nprocs; i++) {
      comm_recv(0,-1, MSG_RESLT);

#if defined VIRIAL || defined OLDVIRIAL
      comm_upkdbl(0,ftmp,4);
      VirPot += ftmp[0];
      VirForce.x += ftmp[1];
      VirForce.y += ftmp[2];
      VirForce.z += ftmp[3];
#ifdef COMP_LJ
      comm_upkdbl(0,ftmp,4);
      VirPot_LJ += ftmp[0];
      VirForce_LJ.x += ftmp[1];
      VirForce_LJ.y += ftmp[2];
      VirForce_LJ.z += ftmp[3];
#endif
#endif

      comm_upkint(0,&partid,1);
      while ( partid != -1 ) {
         comm_upkdbl(0,&(fresults[partid].f.x),4);
#ifdef COMP_LJ
         comm_upkdbl(0,&(fresults_lj[partid].f.x),4);
#endif
         comm_upkint(0,&partid,1);
      } /* while partid */
   } /* for i */

} /* Recv_Slave_Results */


#if defined VIRIAL || defined OLDVIRIAL
/****************************************************************
 *
 *  Return_Virial() - returns the virial from the last particle
 *    reception.  This simple routine os provided to prevent direct
 *    access to the global virial variables, which could cause potential
 *    linking problems with the calling application.
 *
 */

void Return_Virial( double *vp, PmtaVector *vf,
   double *vp_lj, PmtaVector *vf_lj  ) {

   *vp = VirPot;
   vf->x = VirForce.x;
   vf->y = VirForce.y;
   vf->z = VirForce.z;

#ifdef COMP_LJ
   *vp_lj = VirPot_LJ;
   vf_lj->x = VirForce_LJ.x;
   vf_lj->y = VirForce_LJ.y;
   vf_lj->z = VirForce_LJ.z;
#endif

} /* Return_Virial() */

#endif


/****************************************************************
*
* Init_Local_Buffers() - initializes local datastructures
*
*/

void Init_Local_Buffers()
{

   SendPartCnt = NULL;
   SendCellId = NULL;
   
   SendPartCntSz = 0;
   SendCellIdSz = 0;

} /* Init_Local_Buffers */
   

/****************************************************************
*
* Delete_Local_Buffers() - free up locally allocated dynamic data
*   structures.
*
*/

void Delete_Local_Buffers()
{

   free( SendPartCnt );
   free( SendCellId );

} /* Delete_Local_Buffers */
