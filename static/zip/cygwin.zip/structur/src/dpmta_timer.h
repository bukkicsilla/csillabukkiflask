/****************************************************************
*
*  dpmta_timer.h - global variables for dpmta timer 
*    routines
*
*  w. t. rankin
* 
*  these are the external references to the  global variables
*  used by the slave process for timing
*
*  Copyright (c) 1994 Duke University
*  All rights reserved
*
*  RCS info: $Id: dpmta_timer.h,v 3.0 1999/04/01 16:45:42 wrankin Exp $
*/

/*
 *  revision history:
 *
 *  $Log: dpmta_timer.h,v $
 *  Revision 3.0  1999/04/01 16:45:42  wrankin
 *  updates for DPMTA 3.0 - addition of load balancing code
 *
 *  Revision 2.12  1999/03/18 21:23:13  wrankin
 *  clean up timing code.
 *  added timing synchronization
 *
 *  Revision 2.11  1999/01/11 21:48:27  wrankin
 *  fixed MIMD processing error.
 *  fixed SERIAL processing error.
 *  general cleanup of initialization processing.
 *
 *  Revision 2.10  1998/07/16 20:00:39  wrankin
 *  cleaned up makefile and removed indents on preprocessor directives
 *
 *  Revision 2.9  1998/07/15 21:11:10  wrankin
 *  large overhaul to the timing code
 *
 *  Revision 2.8  1997/11/07 16:54:26  wrankin
 *  massive cleanup of code.
 *   - ansi-fication and inclusion of prototypes
 *   - removed unused variables
 *   - all (except the test) code compiles with minimal warnings under gcc.
 *
 *  Revision 2.7  1997/03/12 20:12:56  wrankin
 *  added support for SGIMP64 architecture (IRIX 6.2)
 *
 * Revision 2.6  1997/03/04  19:18:21  wrankin
 * updates to timing codes
 *
 * Revision 2.5  1997/02/26  20:43:35  wrankin
 * updated timing measurements and placed routines in single module
 *
 * Revision 2.4  1997/02/24  19:12:31  wrankin
 * fixes to timing code
 *
 * Revision 2.3  1997/01/28  17:10:47  wrankin
 * added new timing codes for macroscopic expansion calculations
 *
 * Revision 2.2  1996/10/18  17:05:13  wrankin
 * improved PVM message passing structures.
 * made current and cleaned up T3D library code
 * added additional test codes
 * implement new heirarchical make structure
 *
 * Revision 2.1  1995/06/13  04:26:26  wrankin
 * No updates.
 * Sources placed under CVS.
 *
 * Revision 1.1  1995/04/24  04:19:52  wrankin
 * Initial revision
 *
 *
*/

/* size and contents of timing array fields */

#ifndef _DPMTA_TIME_H_
#define _DPMTA_TIME_H_

#define TIME_DATA_SZ 20

#define TIME_E_START 0
#define TIME_E_END 1
#define TIME_E_SENDMPE 2
#define TIME_E_RECVMPE 3
#define TIME_E_SENDRES 4
#define TIME_E_SENDPART 5
#define TIME_E_RECVPART 6
#define TIME_CPU_SORT 7
#define TIME_CPU_RESIZE 8
#define TIME_CPU_UPWARD 9
#define TIME_CPU_DIRECT 10
#define TIME_CPU_DOWNWARD 11
#define TIME_CPU_FORCE 12
#define TIME_CPU_MACPRE 13
#define TIME_CPU_MACRO 14
#define TIME_CPU_RESCALE 15

#define TIME_E_RECVINIT 16
#define TIME_E_SENDINIT 17

#define TIME_DUMMY 19


/*
 * dpmta_timer.c
 */

void Init_Times( int, int );
void Delete_Times();
void Clear_Times();
void Start_E_Time( int );
void Store_E_Time( int, int );
void Start_CPU_Time();
void Store_CPU_Time( int );
void Collect_Print_Times();
#endif
