/* 
grid2D.c : The structure of the particles looks like as a grid in the plane (2D). 
*/


/* include files */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#include "dpmta.h"
#include "dpmta_config.h"   /* only needed for timing code */
#include "grid2D.h"

int grid2D_main()
{
   int i, j,l;                 /* loop counters */
   
   int iteration;            /* number of iterations */
   int process_number;           /* my process number */
   int number_processes;               /* number of slave processes */
   
   double distance;              /* distance between two adjacent gridpoints */
   int k;                       /* number of gridpoints are k*k  */
   
   
   
   double temp_part_flag;              /* temp particle flag */
   
   int number_particles;            /* total number of particles */
   PmtaVector v1;            /* cell vector 1 */
   PmtaVector v2;            /* cell vector 2 */
   PmtaVector v3;            /* cell vector 3 */
   
   PmtaVector center;    /* coordinates of cube center */
   
   PmtaInitData    initial;     /* DPMTA Initialization Data */
   PmtaParticlePtr particle_list; /* array of particle information */
   PmtaPartInfoPtr force_list;    /* array of resulting force information */
   PmtaPartInfoPtr LJ_list;     /* array of resulting LJ force info */
   FILE* fp;
   FILE* gp;
   FILE* np;  /*number of particles*/
   int *num_part = (int*)malloc(sizeof(int) * 19);
   num_part[0] = 10;
   num_part[1] = 25;
   num_part[2] = 50;
   num_part[3] = 75;
   num_part[4] = 100;
   num_part[5] = 250;
   num_part[6] = 500;
   num_part[7] = 750;
   num_part[8] = 1000;
   num_part[9] = 2500;
   num_part[10] = 5000;
   num_part[11] = 7500;
   num_part[12] = 10000;
   num_part[13] = 25000;
   num_part[14] = 50000;
   num_part[15] = 75000;
   num_part[16] = 100000;
   num_part[17] = 200000;
   num_part[18] = 300000;
   
   /*
    *  enroll and see if we are the initial process
    */
   
   
   
   process_number = 0;
   
   number_processes = 1;  
   initial.nprocs = number_processes;
   initial.nlevels = 6;
  	initial.fft = 1; 
   initial.mp = 4;
   initial.theta = 0.7;
   iteration = 1;
   initial.pbc = 1;
      
            
   if (initial.pbc > 0) {
      initial.kterm = initial.pbc - 1;
   }
    
   
   /* set other constants */
   
   initial.mp_lj = 4;
   initial.mp_vir = 4;
   initial.fftblock = 4;
   initial.v1.x = v1.x = 32.0;
   initial.v1.y = v1.y = 0.0;
   initial.v1.z = v1.z = 0.0;
   initial.v2.x = v2.x = 0.0;
   initial.v2.y = v2.y = 32.0;
   initial.v2.z = v2.z = 0.0;
   initial.v3.x = v3.x = 0.0;
   initial.v3.y = v3.y = 0.0;
   initial.v3.z = v3.z = 32.0;
   initial.cellctr.x = center.x = 0.0;
   initial.cellctr.y = center.y = 0.0;
   initial.cellctr.z = center.z = 0.0;
   
   initial.loadstep = 4;
   initial.loadstep = 0.25;
   
   np=fopen("n_grid2D.txt","w");
   
   /*for loop for number of particles */
   for (l = 8; l < 13;l++){
      number_particles = num_part[l];
      printf("total number of particles : %d\n\n",number_particles);
      fprintf(np, "%d\n", number_particles);

      /* adjust number of parts by the numbr of processes */
      number_particles = number_particles / number_processes;
      
      
      /* initialize slave tasks */
      PMTAinit(&(initial),initial.nprocs);
      
      
      
      /* now all calling processes need to register */
      PMTAregister();
      
      /****************************************************************
       *
       *  particle list processing -
       *
       *  create the particle lists and send each processor the list of 
       *  particles in each cell.
       *
       */
      
      /* allocate particle arrays */
      particle_list = (PmtaParticlePtr)malloc(number_particles * sizeof(PmtaParticle));
      if ( particle_list == (PmtaParticlePtr)NULL ) {
         fprintf(stderr,"Error: Particle Malloc failed\n");
         exit(-1);
      }
      
      force_list = (PmtaPartInfoPtr)malloc(number_particles * sizeof(PmtaPartInfo));
      if ( particle_list == (PmtaParticlePtr)NULL ) {
         fprintf(stderr,"Error: Force_list Malloc failed\n");
         exit(-1);
      }
      
      LJ_list = (PmtaPartInfoPtr)malloc(number_particles * sizeof(PmtaPartInfo));
      if ( particle_list == (PmtaParticlePtr)NULL ) {
         fprintf(stderr,"Error: LJ_list Malloc failed\n");
         exit(-1);
      }
      
      
      /* create all particles */
      
      
      
      temp_part_flag = 1.0;
      
      /* compute the root of number of gridpoints which needs for the particles */
      if (  (int)sqrt((double)number_particles) == sqrt((double)number_particles) )
      {
         k = (int)sqrt((double)number_particles);
      }
      else
      {
         k = (int)(sqrt((double)number_particles)) +1;
      }
      //printf("number of grid :%d\n\n",k);
       /* compute the distance between two adjacent gridpoints */ 
       distance = v1.x/(k-1);
      //distance = 0.1;
      //printf("distance :%lg\n\n",distance);
      
      /* create all particles */
      particle_list[0].p.x = -v1.x/2.0 + center.x;
      //printf("i = %d p.x = %lg\n",0,particle_list[0].p.x);
      particle_list[0].p.y = -v2.y/2.0 + center.y;
      // printf("i = %d p.y = %lg\n\n",0,particle_list[0].p.y);
      particle_list[0].p.z = 0.0 + center.z;
      
      
      for (i=1; i<number_particles; i++) {
         
         if ((i%k) == 0)
         {
            particle_list[i].p.x = particle_list[i-k].p.x + center.x;
            //printf("i = %d p.x = %lg\n",i,particle_list[i].p.x);
            particle_list[i].p.y = particle_list[i-1].p.y + distance + center.y;
            //printf("i = %d p.y = %lg\n\n",i,particle_list[i].p.y);
            particle_list[i].p.z = 0.0 + center.z; 
         }
         else
         {
            particle_list[i].p.x = particle_list[i-1].p.x + distance + center.x;
            //printf("i = %d p.x = %lg\n",i,particle_list[i].p.x);
            particle_list[i].p.y = particle_list[i-1].p.y + center.y;
            //printf("i = %d p.y = %lg\n\n",i,particle_list[i].p.y);
            particle_list[i].p.z = 0.0 + center.z;
         }
         
         
      }
      fp=fopen("grid2D_x.txt","w");
      gp=fopen("grid2D_y.txt","w");
      for(i=0;i<number_particles;i++)
      {
         fprintf(fp, "%lg\n", particle_list[i].p.x);
         fprintf(gp, "%lg\n", particle_list[i].p.y); 
      }
      fclose(fp);
      fclose(gp);
      
      
  for (i=0; i<number_particles; i++) {
     
	  if ( (i%2) == 0 )
        particle_list[i].q = 1.0;
     else
        particle_list[i].q = -1.0;
     
     
     particle_list[i].a = 1.0e-3;
     particle_list[i].b = 1.0e-6;
     
     force_list[i].f.x = 0.0;
     force_list[i].f.y = 0.0;
     force_list[i].f.z = 0.0;
     force_list[i].v = 0.0;
     
     LJ_list[i].f.x = 0.0;
     LJ_list[i].f.y = 0.0;
     LJ_list[i].f.z = 0.0;
     LJ_list[i].v = 0.0;
  } /* for i */
  
  /*
   *  send particles out to slaves and wait for results
   *  repeat for multiple iterations
   */
  
  for (i=0; i<iteration; i++) {
     
     PMTAforce(number_particles, particle_list, force_list, LJ_list);
     
     
  } /* for i */
  
    /*
     *  clean up and kill off slaves
     */
  
  PMTAexit();
   }
   fclose(np);
   
   exit(0);
   return 0;
} /* main */

