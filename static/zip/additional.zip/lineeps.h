double epsilon( double random , double x );
int lineeps_main( );