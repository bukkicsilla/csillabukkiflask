/****************************************************************
*
*  dpmta_config.h - global compile-time flags
*
*  w. t. rankin
* 
*  these are the compiler preprocessing flags that control
*  the configuration of the DPMTA executables
*
*  Copyright (c) 1999 Duke University
*  All rights reserved
*
*  RCS info: $Id: dpmta_config.h,v 3.4 2001/02/10 03:54:28 wrankin Exp $
*/


#ifndef _DPMTA_CONFIG_H_
#define _DPMTA_CONFIG_H_

/* uncomment the following lines to enable the specificf feature */

/*
 *  the timing and data dump facilities should only be used
 *  by the developers.  they are for testing purposes only and
 *  should not be used in production code.
 *
 *  TIMEPERF    - include performance timing code
 *  TIMESYNC    - include barriers to synchronize slave starts.
 *  DATADUMP    - test programs dump particle and force
 *                information to output files.
 *  SIZECHECK   - prints out the current size of the DPMTA memory
 *                images.  works for SERIAL case only.
 *  DEBUG       - causes each DPMTA process to dump data structure
 *                information.  this is for development purposes
 *                and should not be used by applications.
 *  DEBUG2      - causes DPMTA to dump the multipole data.
 *  DUMPILIST   - dumps the interaction list to /tmp/ilist*
 */

#define TIMEPERF
/* #define TIMESYNC */
/* #define DATADUMP */
/* #define SIZECHECK */
/* #define DEBUG */
/* #define DEBUG2 */
/* #define DUMPILIST */
//#define VISUALC


/*
 *  COMP_LJ     - include the code to compute Lennard-Jones force and
 *                potentials
 */

/* #define COMP_LJ */


/*
 *  VIRIAL      - include code to compute the virial tensor.  this is
 *               experimental code and should not normally be compiled
 *               into production binaries.
 *  OLDVIRIAL   - include code to compute the virial tensor.  this is
 *               the older and less accurate virial computation.
 */

/* #define VIRIAL */
/* #define OLDVIRIAL */


/*
 *  PBC_WRAP    - particles outside the box boundaries get wrapped
 *                around onto the other side of the box.  Should only
 *                be used if you intend to use PBC.
 *                this does not work with -DPIPED code.
 */

/* #define PBC_WRAP */


/*
 *  SORTILIST   - sorts the order of the multipole interaction lists
 *                in attempt to increase accuacy.  best *not* to use.
 *                some more research may need to go into optimizing the
 *                interaction list access patters for better cache 
 *                performance.
 */

/* #define SORTILIST */


/*
 *  HLIST       - use M2L transfer matrices.
 *  PARCONV     - use parental conversion during the generation
 *                of the interaction list.
 *  CHILDCONV   - use child conversion during the generation of the
 *                interaction lists.
 *  USE_FMM     - the interaction list generated uses the FMM
 *                interaction sets as specified by greengard.
 *  FMM_SEP     - cell separation distance for FMM (2 or 1)
 *
 */

#define SERIAL

#define HLIST
#define PARCONV
/* #define CHILDCONV */
/* #define USE_FMM */
/* #define FMM_SEP 2 */


/*
 *  MACROSCOPIC - include code that calculates the macroscopic assemblies.
 *  PMACRO      - include parallel macroscopic generation code (must also
 *                define MACROSCOPIC above for this to work).  This will
 *                not work (of course) in the serial version.
 */

#define MACROSCOPIC
#define PMACRO


/*
 *  PIPED       - compile in code to allow parallel-piped simulation
 *                cells.  this code involves a significant performance
 *                hit, so it is not recommended unless you really
 *                need parallel-piped regions.  The code also needs 
 *                some severe re-writing.
 */

/* #define PIPED */


/*
 *  HILBERT     - use Hilbert ordering for dividing up cell ownership.
 *                this should result in better data division with
 *                a slight cost in serial performance.
 *  ROWCOL      - use Row/Column ordering for dividing up cell
 *                ownership.  This is provided for comparison and
 *                test purposes only and should not normally be used.
 *                Performance *will* suck.
 *  SCURVE      - use S-curve ordering for dividing up cell
 *                ownership.  this ordering resembles row-column, but
 *                is spatially continuous (like hilbert).  it is provided 
 *                for comparison and test purposes only and should not
 *                normally be used.  performance *will* suck.
 */

/* #define HILBERT */
/* #define ROWCOL */
/* #define SCURVE */


/*
 *  GRAVITATION - reverse the force vectors so that like charges
 *               (mass) attract instead of repel.  dont even think about
 *               any of the other force models (virial, LJ, etc) working
 *               with this.  essentially, i reversed the force vectors.
 */

/* #define GRAVITATION */


/*
 *  LOADBAL     - include code to perform load balancing.   User must
 *               specify the additional -DBALANCE[1-4].  User should
 *               also use -DHILBERT for efficient partitioning.
 */

/* #define LOADBAL */
/* #define BALANCE1 */
/* #define BALANCE2 */
/* #define BALANCE3 */
/* #define BALANCE4 */

#endif
