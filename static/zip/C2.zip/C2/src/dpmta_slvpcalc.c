/* 
*  dpmta_slvpcalc.c - routines to perform the single and double direct
*     particle interactions.
*
*  w. t. rankin
*
*  Copyright (c) 1994 Duke University
*  All rights reserved
*
*
*  originally, these were part of the dpmta_slvcalc.c (version 2.3) module
*  but were pulled out separately since the particle-particle computations
*  are independant of whatever multipole calculations we are running.
*
*/

static char rcsid[] = "$Id: dpmta_slvpcalc.c,v 3.4 2001/02/10 03:54:28 wrankin Exp $";



/* include files */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "dpmta_config.h"        /* dpmta configuration */
#include "dpmta_cell.h"
#include "dpmta_slvglobals.h"


/*
 * external prototyping
 */

#include "dpmta_slvmkil.h"
#include "dpmta_distmisc.h"
#include "dpmta_distpart.h"

/*
 * prototyping of functions internal to module
 *
 */

void Cell_Calc_Self( int, int );
void Cell_Calc_DDirect( int, int, int, int, Vector * );
void Cell_Calc_SDirect( int, int, int, int, Vector * );

/*
 * globals used for LJ scaling, if needed
 */

#ifdef COMP_LJ
static double LJscale; 
#endif

/****************************************************************
*
*  this procedure will perform the both the single and double
*  direct interactions for each of the cells that the processor
*  owns.  it cycles through each of the cells owned by the
*  processor and for each cell, computes the direct interactions
*  between the particles in that cell and the particles in the
*  cells listed in the cells direct interaction list.
*
*  if both the cells are owned by the same processor, then the
*  particles in both cells are updated at the same time.
*  otherwise, only the force results in the local call are
*  updated.
* 
*/

void Slave_Direct_Calc()
{
   int i,j;         /* loop counters */
   int id;
   int level;
   int rcell;       /* remote cell id */
   int posn;
   int sep;         /* cell separation vector */
   int ovfl;        /* overflow boundary flag */


#ifdef COMP_LJ
   /* update LJ scaling factor */
   LJscale = 1.0 / Dpmta_MaxCellLen;
   LJscale = LJscale * LJscale * LJscale;
   LJscale *= LJscale;
#endif

   level = Dpmta_NumLevels - 1;

   /* cycle through all cells at bottom level */
   for ( i=Dpmta_Sindex[level]; i<=Dpmta_Eindex[level]; i++) {

      id = index2cell(i,level);
      
      /* determin cell position within parent cell */
      posn = id & 0x07;

      for ( j=0; j<Dpmta_Intlist[posn].dcnt; j++ ) {
         sep = Dpmta_Intlist[posn].dlist[j];
         if ( Cell2Cell(level,id,sep,&rcell,&ovfl) ) {

	    /* check for remote cell not allocated */
            if ( Dpmta_CellTbl[level][rcell] == NULL ) {
               fprintf(stderr,"ERROR: cell %d/%d not allocated\n",
		       level,rcell);
               exit(-1);
            } /* if Dpmta_CellTbl */

	    /*
	    *  check to see if we own this cell and the cell is located
	    *  within the boundary of the unit cell.  if so, then
	    *  we can perform double direct interactions.
	    *  we only do so when the remote cell is at a higher cell
	    *  index. this is to prevent doing the same pair of
	    *  particles twice.
	    */

#ifndef SERIAL
            if ( Dpmta_Pid == getslvpid(level,rcell) ) {
#endif
 	       if ( rcell > id ) {
                  Cell_Calc_DDirect(level,id,level,rcell,
				    &(Dpmta_Hlist[posn].dlist_vec[j]));
	       } /* if rcell and ovfl */
#ifndef SERIAL
	    } /* if pid */

	    /*
	    *  otherwise, perform single-direct calculations
	    */

	    else {
	       Cell_Calc_SDirect(level,id,level,rcell,
				 &(Dpmta_Hlist[posn].dlist_vec[j]));
	    } /* else not pid */
#endif

	 } /* if Cell2cell */
      } /* for j */
   } /* for i */

   /*
   * in a futile attempt to improve accuracy, do not compute inter-cell
   * potentials until after all extra-cell calculations are done.
   */

   for ( i=Dpmta_Sindex[level]; i<=Dpmta_Eindex[level]; i++) {
      id = index2cell(i,level);
      Cell_Calc_Self(level,id);
   } /* for i */

} /* Slave_Direct_Calc() */


/****************************************************************
*
*  this procedure will perform the direct force calculations for
*  each particle within a cell interacting with all the other
*  particles within that same cell.
*
*/

void Cell_Calc_Self( int level, int cell) 
{
   int i,j;
   int nparts;
   double dx,dy,dz;
   double wtq;
   double ir, ir2;
   double ir_q, ir3_q;
   double f_x, f_y, f_z;
   ParticlePtr cell_particles, cpi, cpj;
   PartInfoPtr cell_forces, cfi, cfj;

#ifdef COMP_LJ
   double wta, wtb;
   double ir6, ir6_a, ir8_a;
   double ir12_b, ir14_b;
   double pot, ir_lj;
   PartInfoPtr cell_f_lj;
#endif

   cell_particles = Dpmta_CellTbl[level][cell]->plist;
   cell_forces = Dpmta_CellTbl[level][cell]->mdata->flist;
   nparts = Dpmta_CellTbl[level][cell]->n;
#ifdef COMP_LJ
   cell_f_lj = Dpmta_CellTbl[level][cell]->mdata->f_lj;
#endif

   cpi = cell_particles;
   cfi = cell_forces;

   for ( i=0; i < nparts-1; i++) {

      cpj = cpi;
      cfj = cfi;

      for ( j=i+1; j < nparts; j++) {

	 cpj++;
	 cfj++;

         wtq = cpi->q * cpj->q;

	 /* dx points from local to remote */
         dx = cpj->p.x - cpi->p.x;
         dy = cpj->p.y - cpi->p.y;
         dz = cpj->p.z - cpi->p.z;

         ir2 = 1.0/(dx*dx + dy*dy + dz*dz);
         ir = sqrt(ir2);
         ir_q = wtq * ir;
         ir3_q = ir_q * ir2;
	 f_x = ir3_q * dx;
	 f_y = ir3_q * dy;
	 f_z = ir3_q * dz;

         cfi->v += ir_q;
#ifdef GRAVITATION
         cfi->f.x += f_x;
         cfi->f.y += f_y;
         cfi->f.z += f_z;
#else
         cfi->f.x -= f_x;
         cfi->f.y -= f_y;
         cfi->f.z -= f_z;
#endif

         cfj->v += ir_q;
#ifdef GRAVITATION
         cfj->f.x -= f_x;
         cfj->f.y -= f_y;
         cfj->f.z -= f_z;
#else
         cfj->f.x += f_x;
         cfj->f.y += f_y;
         cfj->f.z += f_z;
#endif

#if defined VIRIAL || defined OLDVIRIAL
         Dpmta_Vpot += ir_q;
         Dpmta_Vf.x -= f_x * dx;
         Dpmta_Vf.y -= f_y * dy;
         Dpmta_Vf.z -= f_z * dz;
#endif



#ifdef COMP_LJ

	 /*
	  *  note that the 1/r^6 is always an attractive force
	  *  so the signs are reversed from the colomb above.
	  *  the 1/r^12 is repulsive, so the signs are the same.
	  */

         wta = cpi->a * cpj->a;
         wtb = cpi->b * cpj->b;

	 ir6 = ir2 * ir2 * ir2;
         ir6_a = ir6 * wta;
	 ir8_a = ir6_a * ir2;
	 ir12_b = ir6 * ir6 * wtb;
	 ir14_b = ir12_b * ir2;

	 pot = (ir12_b * LJscale) - ir6_a;
         cell_f_lj[j].v += pot;
         cell_f_lj[i].v += pot;

	 ir_lj = 6.0 * ( (2.0 * ir14_b * LJscale) - ir8_a);
	 f_x = ir_lj * dx;
	 f_y = ir_lj * dy;
	 f_z = ir_lj * dz;
         cell_f_lj[j].f.x += f_x;
         cell_f_lj[i].f.x -= f_x;
         cell_f_lj[j].f.y += f_y;
         cell_f_lj[i].f.y -= f_y;
         cell_f_lj[j].f.z += f_z;
         cell_f_lj[i].f.z -= f_z;

#if defined VIRIAL || defined OLDVIRIAL
         Dpmta_Vpot_LJ += pot;
         Dpmta_Vf_LJ.x -= f_x * dx;
         Dpmta_Vf_LJ.y -= f_y * dy;
         Dpmta_Vf_LJ.z -= f_z * dz;
#endif

#endif

      } /* for j */

      cpi++;
      cfi++;

   } /* for i */
   
} /* Cell_Calc_Self */


/****************************************************************
*
*  Cell_Calc_DDirect() -
*
*  this procedure will perform the direct force calculations for
*  each particle within the target cell interacting with all the
*  other particles within the remote cell.  the contents of the
*  remote cell are updated.
*
*/

void Cell_Calc_DDirect(
   int tlevel,     /* target level */
   int tcell,      /* target cell */
   int rlevel,     /* remote level */
   int rcell,      /* remote cell */
   Vector *sep)    /* cell separation vector */

{
   int i,j;
   int tparts, rparts;
   double dx,dy,dz;
   double wtq;
   double ir, ir2;
   double ir_q, ir3_q;
   double f_x, f_y, f_z;
   double px, py, pz;
   double v, fx, fy, fz;
   ParticlePtr rcell_parts, tcp, rcp;
   PartInfoPtr rcell_forces, tcf, rcf;

#ifdef COMP_LJ
   double wta, wtb;
   double ir6, ir6_a, ir8_a;
   double ir12_b, ir14_b;
   double pot, ir_lj;
   PartInfoPtr tcell_f_lj, rcell_f_lj;
#endif

   tcf = Dpmta_CellTbl[tlevel][tcell]->mdata->flist;
   tcp = Dpmta_CellTbl[tlevel][tcell]->plist;

   rcell_parts = Dpmta_CellTbl[rlevel][rcell]->plist;
   rcell_forces = Dpmta_CellTbl[rlevel][rcell]->mdata->flist;

#ifdef COMP_LJ
   tcell_f_lj = Dpmta_CellTbl[tlevel][tcell]->mdata->f_lj;
   rcell_f_lj = Dpmta_CellTbl[rlevel][rcell]->mdata->f_lj;
#endif

   tparts = Dpmta_CellTbl[tlevel][tcell]->n;
   rparts = Dpmta_CellTbl[rlevel][rcell]->n;

   for ( i=0; i < tparts; i++) {

      px = sep->x - tcp->p.x;
      py = sep->y - tcp->p.y;
      pz = sep->z - tcp->p.z;

      v = tcf->v;
      fx = tcf->f.x;
      fy = tcf->f.y;
      fz = tcf->f.z;

      rcp = rcell_parts;
      rcf = rcell_forces;

      for ( j=0; j < rparts; j++) {

        wtq = tcp->q * rcp->q;

	 /* dx points from local to remote */
         dx = rcp->p.x + px;
         dy = rcp->p.y + py;
         dz = rcp->p.z + pz;

         ir2 = 1.0/(dx*dx + dy*dy + dz*dz);
         ir = sqrt(ir2);
         ir_q = wtq * ir;
         ir3_q = ir_q * ir2;
	 f_x = ir3_q * dx;
	 f_y = ir3_q * dy;
	 f_z = ir3_q * dz;

         v += ir_q;
#ifdef GRAVITATION
         fx += f_x;
         fy += f_y;
         fz += f_z;
#else
         fx -= f_x;
         fy -= f_y;
         fz -= f_z;
#endif

         rcf->v += ir_q;
#ifdef GRAVITATION
         rcf->f.x -= f_x;
         rcf->f.y -= f_y;
         rcf->f.z -= f_z;
#else
         rcf->f.x += f_x;
         rcf->f.y += f_y;
         rcf->f.z += f_z;
#endif

#if defined VIRIAL || defined OLDVIRIAL
         Dpmta_Vpot += ir_q;
         Dpmta_Vf.x -= f_x * dx;
         Dpmta_Vf.y -= f_y * dy;
         Dpmta_Vf.z -= f_z * dz;
#endif

#ifdef COMP_LJ

	 /*
	  *  note that the 1/r^6 is always an attractive force
	  *  so the signs are reversed from the colomb above.
	  *  the 1/r^12 is repulsive, so the signs are the same.
	  */

         wta = tcp->a * rcp->a;
         wtb = tcp->b * rcp->b;

	 ir6 = ir2 * ir2 * ir2;
         ir6_a = ir6 * wta;
	 ir8_a = ir6_a * ir2;
	 ir12_b = ir6 * ir6 * wtb;
	 ir14_b = ir12_b * ir2;

	 pot = (ir12_b * LJscale) - ir6_a;
         rcell_f_lj[j].v += pot;
         tcell_f_lj[i].v += pot;

	 ir_lj = 6.0 * ( (2.0 * ir14_b * LJscale) - ir8_a);
	 f_x = ir_lj * dx;
	 f_y = ir_lj * dy;
	 f_z = ir_lj * dz;
         tcell_f_lj[i].f.x -= f_x;
         tcell_f_lj[i].f.y -= f_y;
         tcell_f_lj[i].f.z -= f_z;
         rcell_f_lj[j].f.y += f_y;
         rcell_f_lj[j].f.x += f_x;
         rcell_f_lj[j].f.z += f_z;

#if defined VIRIAL || defined OLDVIRIAL
         Dpmta_Vpot_LJ += pot;
         Dpmta_Vf_LJ.x -= f_x * dx;
         Dpmta_Vf_LJ.y -= f_y * dy;
         Dpmta_Vf_LJ.z -= f_z * dz;
#endif

#endif

	 rcp++;
	 rcf++;

      } /* for j */

      tcf->v = v;
      tcf->f.x = fx;
      tcf->f.y = fy;
      tcf->f.z = fz;

      tcp++;
      tcf++;

   } /* for i */

} /* Cell_Calc_DDirect */



/****************************************************************
*
*  Cell_Calc_SDirect( ) -
*
*  this procedure will perform the direct force calculations for each
*  particle within the target cell interacting with all the other
*  particles within the remote cell.  the contents of the remote cell
*  are not updated.
* */

void Cell_Calc_SDirect(
   int tlevel,     /* target level */
   int tcell,      /* target cell */
   int rlevel,     /* remote level */
   int rcell,      /* remote cell */
   Vector *sep)    /* cell separation vector */

{
   int i,j;
   int tparts, rparts;
   double dx,dy,dz;
   double wtq;
   double ir, ir2;
   double ir_q, ir3_q;
   double f_x, f_y, f_z;
   double px, py, pz;
   double v, fx, fy, fz;
   ParticlePtr rcell_parts, tcp, rcp;
   PartInfoPtr tcf;

#ifdef COMP_LJ
   double wta, wtb;
   double ir6, ir6_a, ir8_a;
   double ir12_b, ir14_b;
   double pot, ir_lj;
   PartInfoPtr tcell_f_lj;
#endif

   tcf = Dpmta_CellTbl[tlevel][tcell]->mdata->flist;
   tcp = Dpmta_CellTbl[tlevel][tcell]->plist;

   rcell_parts = Dpmta_CellTbl[rlevel][rcell]->plist;

#ifdef COMP_LJ
   tcell_f_lj = Dpmta_CellTbl[tlevel][tcell]->mdata->f_lj;
#endif

   tparts = Dpmta_CellTbl[tlevel][tcell]->n;
   rparts = Dpmta_CellTbl[rlevel][rcell]->n;

   for ( i=0; i < tparts; i++) {

      px = sep->x - tcp->p.x;
      py = sep->y - tcp->p.y;
      pz = sep->z - tcp->p.z;

      v = tcf->v;
      fx = tcf->f.x;
      fy = tcf->f.y;
      fz = tcf->f.z;

      rcp = rcell_parts;

      for ( j=0; j < rparts; j++) {

         wtq = tcp->q * rcp->q;

	 /* dx points from local to remote */
         dx = rcp->p.x + px;
         dy = rcp->p.y + py;
         dz = rcp->p.z + pz;

         ir2 = 1.0/(dx*dx + dy*dy + dz*dz);
	 ir = sqrt(ir2);
         ir_q = wtq * ir;
         ir3_q = ir_q * ir2;
	 f_x = ir3_q * dx;
	 f_y = ir3_q * dy;
	 f_z = ir3_q * dz;

         v += ir_q;
#ifdef GRAVITATION
         fx += f_x;
         fy += f_y;
         fz += f_z;
#else
         fx -= f_x;
         fy -= f_y;
         fz -= f_z;
#endif 

#if defined VIRIAL || defined OLDVIRIAL
         Dpmta_Vpot += ir_q * 0.5;
         Dpmta_Vf.x -= f_x * dx * 0.5;
         Dpmta_Vf.y -= f_y * dy * 0.5;
         Dpmta_Vf.z -= f_z * dz * 0.5;
#endif

#ifdef COMP_LJ

	 /*
	  *  note that the 1/r^6 is always an attractive force
	  *  so the signs are reversed from the colomb above.
	  *  the 1/r^12 is repulsive, so the signs are the same.
	  */

         wta = tcp->a * rcp->a;
         wtb = tcp->b * rcp->b;

	 ir6 = ir2 * ir2 * ir2;
         ir6_a = ir6 * wta;
	 ir8_a = ir6_a * ir2;
	 ir12_b = ir6 * ir6 * wtb;
	 ir14_b = ir12_b * ir2;

	 pot = (ir12_b * LJscale) - ir6_a;
         tcell_f_lj[i].v += pot;

	 ir_lj = 6.0 * ( (2.0 * ir14_b * LJscale) - ir8_a);
	 f_x = ir_lj * dx;
	 f_y = ir_lj * dy;
	 f_z = ir_lj * dz;
         tcell_f_lj[i].f.x -= f_x;
         tcell_f_lj[i].f.y -= f_y;
         tcell_f_lj[i].f.z -= f_z;

#if defined VIRIAL || defined OLDVIRIAL
         Dpmta_Vpot_LJ += pot * 0.5;
         Dpmta_Vf_LJ.x -= f_x * dx * 0.5;
         Dpmta_Vf_LJ.y -= f_y * dy * 0.5;
         Dpmta_Vf_LJ.z -= f_z * dz * 0.5;
#endif
#endif

	 rcp++;

      } /* for j */

      tcf->v = v;
      tcf->f.x = fx;
      tcf->f.y = fy;
      tcf->f.z = fz;

      tcp++;
      tcf++;

   } /* for i */
   
} /* Cell_Calc_SDirect() */


/****************************************************************
 *
 *  Dump_Particles() dump contents of all the cells owned by
 *    this processor.
 *
 */

void Dump_Particles()
{
   int i,j;         /* loop counters */
   int id;
   int level;
   int nparts;

   FILE *ofile;
   char fname[80];

   ParticlePtr pptr;
   int *idptr;


   sprintf(fname,"/tmp/pdump.proc%d",Dpmta_Pid);
   ofile = fopen(fname,"w");
   if ( ofile == NULL ) {
	 fprintf(stderr,"ERROR: cannot open dump file %s \n", fname);
	 exit(-1);
   }

   level = Dpmta_NumLevels - 1;

   /* cycle through all cells at bottom level */
   for ( i=Dpmta_Sindex[level]; i<=Dpmta_Eindex[level]; i++) {

      id = index2cell(i,level);

      /* check for  cell not allocated */

      if ( Dpmta_CellTbl[level][id] == NULL ) {
	 fprintf(stderr,"ERROR: cell %d/%d not allocated\n",
		 level,id);
	 exit(-1);
      } /* if Dpmta_CellTbl */

      if ( Dpmta_CellTbl[level][id]->mdata == NULL ) {
	 fprintf(stderr,"ERROR: cell->mdata %d/%d not allocated\n",
		 level,id);
	 exit(-1);
      } /* if Dpmta_CellTbl */

      nparts = Dpmta_CellTbl[level][id]->n;
      pptr = Dpmta_CellTbl[level][id]->plist;
      idptr = Dpmta_CellTbl[level][id]->mdata->part_id;

      for ( j=0; j<nparts; j++ ) {
	 fprintf(ofile, "%d %f %f %f %f\n", idptr[j],
		 pptr[j].q, pptr[j].p.x, pptr[j].p.y, pptr[j].p.z);
      } /* for j */

   } /* for i */

   fclose(ofile);

} /* Dump_Particles() */

