/* 
*  dpmta_slvcompute.c - routine to perform actuall DPMTA processing
*
*  w. t. rankin, w. elliott
*
*  Copyright (c) 1995 Duke University
*  All rights reserved
*
*  this routine implements the actaul DPMTA processing.
*  it was pulled out of the original dpmta_slave.c main() routine
*  for the purpose of t3d integration.
*
*/

static char rcsid[] = "$Id: dpmta_slvcompute.c,v 3.5 2000/04/04 02:38:06 wrankin Exp $";


/* include files */

#include <stdio.h>
#ifndef WIN32
#include <unistd.h>
#endif

#include "dpmta_config.h"        /* dpmta configuration */
#include "dpmta_cell.h"          /* data type definitions */
#include "dpmta_slvglobals.h"    /* global variable declarations */


/*
*  external prototypes
*/

#include "dpmta_distmisc.h"
#include "dpmta_distpart.h"
#ifdef LOADBAL
#include "dpmta_distload.h"
#endif
#include "dpmta_slvmkcell.h"
#include "dpmta_slvmkil.h"
#include "dpmta_slvmkhl.h"
#include "dpmta_slvmcalc.h"
#include "dpmta_slvpcalc.h"
#include "dpmta_slvscale.h"
#ifndef SERIAL
#include "dpmta_slvcomm.h"
#include "dpmta_slvmkiil.h"
#endif
#ifdef TIMEPERF
#include "dpmta_timer.h"
#endif


/****************************************************************
*
*  Slave_Init() - initialize and allocate the global data structures
*    used by DPMTA directly as well as initialization of other
*    procedures.
*
*  this routine should be called once right after the global DPMTA
*  variables have been set.
*
*/

void Slave_Init()
{

   /*
   *  misc setups that need to be done first
   */

#ifndef SERIAL
   Dist_Init( Dpmta_NumLevels );
   Partition_Init( Dpmta_NumLevels, Dpmta_Nproc );
   Comm_Init();
#endif
   
   /*
   *  compute MPE constants used later - this must be called before
   *  allocation of multipole stuff
   */

   MultipoleSetup();

   /*
   *  allocate cell table and interaction lists
   */

   Alloc_Cell_Index();
   Alloc_Cell_Table();

   Make_Cell_Index();
   Make_Cell_Local();

   Init_Ilist();

   Init_Hlist();

#ifndef SERIAL
   Init_Inv_Ilist();
#endif

} /* Slave_Init() */


/****************************************************************
*
*  Slave_Repartition() - re-allocate the global data structures
*    used by DPMTA in the case that the processor partition 
*    boudaries have changed.  This functionality is normally only
*    used by the load balancing code.
*
*/

void Slave_Repartition()
{

#ifndef SERIAL

   /*
   *  reconfiguration routines.
   */

   Make_Cell_Index();
   Make_Cell_Local();
   Make_Cell_Ilist();
   Make_Cell_Centers();
   Make_Inv_Ilist();

#endif

   
} /* Slave_Repartition() */


/****************************************************************
*
*  Slave_Start() - perform any needed initializations needed
*    at the beginning of a DPMTA iteration, including any reallocation
*    of buffers and data structures.
*
*/

void Slave_Start()
{

#if defined VIRIAL || defined OLDVIRIAL
   Dpmta_Vpot = 0.0;
   Dpmta_Vf.x = 0.0;
   Dpmta_Vf.y = 0.0;
   Dpmta_Vf.z = 0.0;
#ifdef COMP_LJ
   Dpmta_Vpot_LJ = 0.0;
   Dpmta_Vf_LJ.x = 0.0;
   Dpmta_Vf_LJ.y = 0.0;
   Dpmta_Vf_LJ.z = 0.0;
#endif
#endif

   if (Dpmta_Resize==TRUE) {

      /*
       *  compute interaction lists and place in table.
       *  this procedure will also allocate the cell table entries for
       *  the interaction information.
       * 
       *  allocate all remote cells from the information provided in 
       *  the interaction lists.  also allocate the mpe transfer matrices
       */

      Make_Ilist();
#ifdef DUMPILIST
      Dump_Ilist();
#endif

      Make_Hlist();

#ifndef SERIAL      
      Make_Cell_Ilist();

      Make_Inv_Ilist();
#endif
      
      MultipoleResize();

      Dpmta_Resize = FALSE;

   } /* if Dpmta_Resize */

#ifdef TIMEPERF
   Store_CPU_Time(TIME_CPU_RESIZE);
#endif

} /* Slave_Start */


/****************************************************************
*
*  Slave_Compute() - perform all multipole computations
*
*  this routine performs all multipole comutations on the
*  particle data for a single dpmta iteration.
*
*/

void Slave_Compute()
{
    /*
    *  based on inverse interaction lists, distribute particle
    *  cell information to all other processors
    */

#ifdef TIMEPERF
   Start_E_Time(TIME_DUMMY);
#endif
      
#ifndef SERIAL
   Slave_Send_SDirect();
#endif

#ifdef TIMEPERF
   Store_E_Time(TIME_DUMMY,TIME_E_SENDPART);
#endif

   /*
   *  perform the upward pass
   *
   *  each slave will process the multipole expansion for the cells
   *  that it owns.  if the higher level cell is owned by another slave,
   *  (based upon the slaved pid) then this slave will pass the multipole
   *  expansions to the appropriate parent.
   */

#ifdef TIMEPERF
   /* begin timing step 1 and 2 */
   Start_CPU_Time();
#endif

   Slave_Mpole_Exp();

#ifdef TIMEPERF
   Store_CPU_Time(TIME_CPU_UPWARD);
#endif


   /*
   *  collect the particle information from the other processors
   *  and place the information in the local cell table.  note that
   *  we only receive nproc-1 messages.
   */

#ifdef TIMEPERF
   Start_E_Time(TIME_DUMMY);
#endif
      
#ifndef SERIAL
   Slave_Recv_SDirect();
#endif

#ifdef TIMEPERF
   Store_E_Time(TIME_DUMMY,TIME_E_RECVPART);
   Start_E_Time(TIME_DUMMY);
#endif

   /*
   *  based on the inverse interaction list, distribute mpe
   *  cell information to all other processors
   */

#ifndef SERIAL
   Slave_Send_Multipole();
#endif

#ifdef TIMEPERF
   Store_E_Time(TIME_DUMMY,TIME_E_SENDMPE);
#endif


   /*
   *  since we have all the local and remote particle information,
   *  do all the direct particle interaction calculations
   *  while we are waiting for the multipole data to 
   *  arrive.
   */

#ifdef LOADBAL
   Start_LoadBal();
#endif

#ifdef TIMEPERF
   /* begin timing direct calculations */
   Start_CPU_Time();
#endif
   Slave_Direct_Calc();

#ifdef TIMEPERF
   /* end time for direct calculations */
   Store_CPU_Time(TIME_CPU_DIRECT);
#endif

#ifdef LOADBAL
   Pause_LoadBal();
#endif


   /*
   *  collect the mpe data from the other processors
   */

#ifdef TIMEPERF
   Start_E_Time(TIME_DUMMY);
#endif
	    
#ifndef SERIAL
   Slave_Recv_Multipole();
#endif

#ifdef TIMEPERF
   Store_E_Time(TIME_DUMMY,TIME_E_RECVMPE);
#endif


   /*
   *  compute the mpe-particle interactions.  this is also known as
   *  the downward mpe pass.  after all the local expansions have
   *  been computed, then compute the particle forces based upon
   *  the local expansion.
   */

#ifdef LOADBAL
   Resume_LoadBal();
#endif

#ifdef TIMEPERF
   /* Time downward pass */
   Start_CPU_Time();
#endif
   Slave_MPE_Calc();

#ifdef TIMEPERF
   /* end time for direct calculations */
   Store_CPU_Time(TIME_CPU_DOWNWARD);
#endif

   Slave_MPE_Force();

#ifdef TIMEPERF
   /* end time for direct calculations */
   Store_CPU_Time(TIME_CPU_FORCE);
#endif

#ifdef LOADBAL
   Stop_LoadBal();
#endif
   
} /* Slave_Compute() */


/****************************************************************
*
*  Slave_Cleanup() - cleans up the contents of the 
*     the cell table at the end of the force calculations.
*
*  this procedure cleans up the cell table data structures at the 
*  end of one iteration, after the force data has been returned to
*  the calling process and is no longer needed by the slave process.
*  this is done in preparation for the next iteration.
*
*  cleanup is performed by cycling through all cells and setting the
*  particle counts to zero and the multipole valid flags (if any)
*  to false.
*
*  since we use realloc() on the particle/force arrays at each iteration,
*  there is no need to implicitly free() them after each iteration.
*
*/

void Slave_Cleanup()
{

   int i;
   int num_cells;


   num_cells = Dpmta_LevelLocate[Dpmta_NumLevels];

   for (i=0; i<num_cells; i++) {

      if ( Dpmta_CellTbl[0][i] != NULL ) {

         Dpmta_CellTbl[0][i]->mvalid = FALSE;
         Dpmta_CellTbl[0][i]->n = 0;
         Dpmta_CellTbl[0][i]->n2 = 0;

         if (Dpmta_CellTbl[0][i]->mdata != NULL ) {
            Dpmta_CellTbl[0][i]->mdata->lvalid = FALSE;
	 } /* if mdata != NULL */

      } /* if CellTbl[0][i] != NULL */

   } /* for i */

} /* Slave_Cleanup */


/****************************************************************
*
*  Slave_Delete() - free up all global data structures created in
*    Slave_Init() call.
*
*/

void Slave_Delete()
{

   /* free dynamic structures created by the multipole library */
   MultipoleCleanup();
   
   /* free the cell table structures */
   Delete_Cell_Table();
#ifndef SERIAL
   Delete_Cell_Index();
#endif

   /* free up the interaction lists */
   Delete_Ilist();
   Delete_Hlist();

#ifndef SERIAL   
   /* free up the inverse interaction lists */
   Delete_Inv_Ilist();
#endif
   
   /* free up other data structures */
#ifndef SERIAL
   Dist_Delete( Dpmta_NumLevels );
   Partition_Delete( Dpmta_NumLevels, Dpmta_Nproc );
   Comm_Delete();
#endif

#ifdef LOADBAL
   Delete_LoadBal();
#endif  

} /* Slave_Delete */
