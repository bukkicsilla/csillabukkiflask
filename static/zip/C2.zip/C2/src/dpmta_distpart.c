/* 
*  dpmta_distpart.c - routines to perform mapping for partitioning problem
*    across processors
*
*  these routines are used by both the master and slave processes.  thus
*  they cannot access any global data structures.  most of these
*  functions were taken from dpmta_slvmisc.c
*
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*/

static char rcsid[] = "$Id: dpmta_distpart.c,v 3.2 1999/12/24 18:03:44 wrankin Exp $";

/*
 * revision history:
 *
 * $Log: dpmta_distpart.c,v $
 * Revision 3.2  1999/12/24 18:03:44  wrankin
 * all compile time directives are now contained in the dpmta_config.h
 *   header file instead of being passed via make.
 *
 * Revision 3.1  1999/05/17 19:03:10  wrankin
 * Added support for Load Balancing
 *
 * Revision 3.0  1999/04/01 16:45:02  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.1  1998/12/01 20:59:32  wrankin
 * enhanced dynamic allocation of cells
 * cleanup of code.
 *
 *
 */

/* include files */
#include <stdlib.h>
#include <stdio.h>

/* dpmta configuration */
#include "dpmta_config.h"

#include "dpmta_distmisc.h"

/* internal prototypes */

/* local global data structures */

static int Nprocs;             /* number of processors */
static int Nlevels;            /* number of levels in tree */
static int **Sindex;           /* index of first cell a proc owns */
static int **Eindex;           /* index of last cell a proc owns */
static int *CellPid;           /* stores who wons a given cell */


/****************************************************************
*
*  Partition_Init() - allocate and initialize internal data structures
*
*/

void Partition_Init( int numlevels, int numprocs )
{
   int i,j;
   int ncells;

   /* store for internal user later */
   Nprocs = numprocs;
   Nlevels = numlevels;

   /* alloc the start and end cell arrays based upon processor */
   Sindex = (int **)malloc(numprocs*sizeof(int *));
   if ( Sindex == (int **)NULL ) {
      fprintf(stderr,"ERROR: malloc failed\n");
      exit(-1);
   }
   for ( i=0; i<numprocs; i++ ) {
      Sindex[i] = (int *)malloc(numlevels*sizeof(int));
      if ( Sindex[i] == (int *)NULL ) {
	 fprintf(stderr,"ERROR: malloc failed\n");
	 exit(-1); 
      }
   }

   Eindex = (int **)malloc(numprocs*sizeof(int *));
   if ( Eindex == (int **)NULL ) {
      fprintf(stderr,"ERROR: malloc failed\n");
      exit(-1);
   }
   for ( i=0; i<numprocs; i++ ) {
      Eindex[i] = (int *)malloc(numlevels*sizeof(int));
      if ( Eindex[i] == (int *)NULL ) {
	 fprintf(stderr,"ERROR: malloc failed\n");
	 exit(-1); 
      }
   }

   ncells = (0x1) << (3*(numlevels-1));
   CellPid = (int *)malloc(ncells*sizeof(int));
   if ( CellPid == (int *)NULL ) {
      fprintf(stderr,"ERROR: malloc failed\n");
      exit(-1);
   }

   /* set up the initial date distribution */

   /*
    * the initial distribution is based upon the even decomposition 
    * of the leaf nodes among the processors.  higher levels are based upon
    * ownership of the number-0 child.
    */

   /* 
    * not that we assume that there are more leaf nodes than processors
    * bottom level of the tree.  if not then this algorithm will fail
    * misserably.
    */

   /* her is the default even distribution */
   i = numlevels - 1;
   for ( j=0; j<numprocs; j++ ) {
      Sindex[j][i] = (j * (0x1 << (3*i)) + (numprocs-1)) / numprocs;
   } /* for j */



   /* fill in the other levels */
   for ( i=(numlevels-2); i>=0; i-- ) {
      for ( j=0; j<numprocs; j++ ) {

	 if ( Sindex[j][i+1] < 0 ) {
	    Sindex[j][i] = -1;
	 }
	 else {
	    if ( (Sindex[j][i+1] & 0x7) == 0 ) {
	       Sindex[j][i] = Sindex[j][i+1] >> 3;
	    }
	    else {
	       Sindex[j][i] = ( Sindex[j][i+1] >> 3 ) + 1;
	    }
	 }
      } /* for j */
   } /* for i */

   /* compute the end indexes */
   for ( i=0; i<numlevels; i++ ) {
      for ( j=0; j<(numprocs-1); j++ ) {
	 Eindex[j][i] = Sindex[j+1][i] - 1;
      }
      Eindex[numprocs-1][i] = (0x1 << (3*i)) - 1;
   } /* for i */
    
   /* compute any places where processors don't own cells */
   for ( i=0; i<numlevels; i++ ) {
      for ( j=0; j<numprocs; j++ ) {
	 if ( Sindex[j][i] > Eindex[j][i] ) {
	    Sindex[j][i] = -1;
	    Eindex[j][i] = -1;
	 } /* if */
      } /* for j */
   } /* for i */

   for ( i=0; i<numprocs; i++ ) {
      if ( Sindex[i][numlevels-1] > -1 ) {
	 for ( j=Sindex[i][numlevels-1]; j<=Eindex[i][numlevels-1]; j++ ) {
	    CellPid[j] = i;
	 }
      }
   }
   
} /* Partition_Init() */


/****************************************************************
*
* Partition_Update() - update contents of partition arrays
*   upon a new leaf node distribution.  the array new_index[]
*   contains the new starting cells for each processor.
*/

void Partition_Update( int *new_index )
{

   int i,j;

   /* her is the default even distribution */
   i = Nlevels - 1;
   for ( j=0; j<Nprocs; j++ ) {
      Sindex[j][i] = new_index[j];
   } /* for j */

   /* fill in the other levels */
   for ( i=(Nlevels-2); i>=0; i-- ) {
      for ( j=0; j<Nprocs; j++ ) {

	 if ( Sindex[j][i+1] < 0 ) {
	    Sindex[j][i] = -1;
	 }
	 else {
	    if ( (Sindex[j][i+1] & 0x7) == 0 ) {
	       Sindex[j][i] = Sindex[j][i+1] >> 3;
	    }
	    else {
	       Sindex[j][i] = ( Sindex[j][i+1] >> 3 ) + 1;
	    }
	 }
      } /* for j */
   } /* for i */

   /* compute the end indexes */
   for ( i=0; i<Nlevels; i++ ) {
      for ( j=0; j<(Nprocs-1); j++ ) {
	 Eindex[j][i] = Sindex[j+1][i] - 1;
      }
      Eindex[Nprocs-1][i] = (0x1 << (3*i)) - 1;
   } /* for i */
    
   /* compute any places where processors don't own cells */
   for ( i=0; i<Nlevels; i++ ) {
      for ( j=0; j<Nprocs; j++ ) {
	 if ( Sindex[j][i] > Eindex[j][i] ) {
	    Sindex[j][i] = -1;
	    Eindex[j][i] = -1;
	 } /* if */
      } /* for j */
   } /* for i */

   for ( i=0; i<Nprocs; i++ ) {
      if ( Sindex[i][Nlevels-1] > -1 ) {
	 for ( j=Sindex[i][Nlevels-1]; j<=Eindex[i][Nlevels-1]; j++ ) {
	    CellPid[j] = i;
	 }
      }
   }

} /* Partition_Update() */


/****************************************************************
*
*  Partition_ListIndex() - dump current bottom level start index
*    to an output array.
*
*  the calling routine is resposible for making sure the
*  outlist array is sufficient size.
*
*/

void Partition_ListIndex( int *outlist )
{
   int i;

   for ( i=0; i<Nprocs; i++ ) {
      outlist[i] = Sindex[i][Nlevels-1];
   } /* for i */

} /* Partition_ListIndex() */


/****************************************************************
*
*  Partition_Delete() - free up internal data structures
*
*/

void Partition_Delete()
{
   int i;

   for ( i=0; i<Nprocs; i++ ) {
      free(Sindex[i]);
      free(Eindex[i]);
   } /* for i */
   free(Sindex);
   free(Eindex);
   free(CellPid);

} /* Partition_Delete() */


/****************************************************************
 *
 *  the following routines map the problem/tree space onto the
 *  processor allocation space.   as far as the calling procedures
 *  are aware, processor allocation is represented by a a mapping
 *  of cells onto a contiguous section of a linear array.
 *
 *  the calling program can make no assumptions as to the
 *  method of mapping for the individual cell structures.
 *
 */


/****************************************************************
*
*  getslvpid() - returns the pid for the slave that owns
*    a given cell
*
*    ownership of a cell is goverened by the fact that the
*    whomever owns the #0 child of a group of cells also owns
*    corresponding parent cell of that group.
*
*    therefor, to determin the pid for a given cell means that we
*    must determin the ownership of the #0 child descendant of
*    that cell propagated down to the lowest level of the tree.
*
*    
*/

int getslvpid(int level, int cell)
{
   int id;

   id = cell2index(cell,level);
   return ( CellPid[id << ( 3 * ( Nlevels - level - 1))] );

   /* return ( (Nprocs * id) / (0x01 <<(3*level)) ); */
   
} /* getslvpid() */


/****************************************************************
*
*  getslvpid_indx() - returns the pid for the slave that owns
*    a given index.
*
*    note that for row/col indexing, we should really take this back
*    to a cell index, map the cell index onto the bottom level cell,
*    take the index, and then compute the processor that owns that
*    index.  but that is too much of a pain for a section of code that
*    we will never use.
*
*/

int getslvpid_indx(int level, int id)
{

   /* return ( (Nprocs * id) / (0x01 <<(3*level)) ); */
   return ( CellPid[id << ( 3 * ( Nlevels - level - 1))] );

}


/*****************************************************************
*
*  getsindex() - returns the first cell that a specific pid owns for a
*  given level.
*
*/

int getsindex( int pid, int level )
{

   return Sindex[pid][level];

} /* getsindex() */


/*****************************************************************
*
*  geteindex() - returns the last cell that a specific pid owns for a
*  given level.
*
*/

int geteindex( int pid, int level )
{

   return Eindex[pid][level];
   
} /* geteindex */


