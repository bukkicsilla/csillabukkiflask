/* 
*  dpmta_distmisc.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_distpart.h,v 3.2 1999/12/24 17:55:50 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_distpart.h,v $
 * Revision 3.2  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.1  1999/05/17 19:03:11  wrankin
 * Added support for Load Balancing
 *
 * Revision 3.0  1999/04/01 16:45:02  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.1  1998/12/01 20:59:33  wrankin
 * enhanced dynamic allocation of cells
 * cleanup of code.
 *
 *
 */

#ifndef _DPMTA_DISTPART_H_
#define _DPMTA_DISTPART_H_

/*
 * dpmta_distpart.c
 */

void Partition_Init( int, int );
void Partition_Update( int * );
void Partition_ListIndex( int * );
void Partition_Delete();

int geteindex( int, int );
int getsindex( int, int );
int getslvpid( int, int );
int getslvpid_indx( int, int );


#endif
