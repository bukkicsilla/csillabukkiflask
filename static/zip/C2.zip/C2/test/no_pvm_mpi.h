int no_pvm_mpi_main();
