/*
 *  comm_prims.c - communication primitives using local buffering
 *    scheme.  this is meant to provide a generic messaging interface
 *    that can be implemented using a variety of different message
 *    passing packages.
 *
 *    in reality - this is supposed to allow almost any messaging 
 *    system to look similar to the PVM3 API.
 *
 *  w. t. rankin
 *
 *  Copyright (c) 2000 Bill Rankin
 *  All Rights Reserved
 *
 *  there are two real ideas implemented here.  the first is
 *  to abstract the concept of "processor ID" so that it is 
 *  represented by a simple [0-(n-1)] index.  communication to
 *  different processors within the group is always done using 
 *  this index.
 *
 *  another, seperate, concept is the abstraction of the PVM
 *  message buffering system so that alternative buffering strategies
 *  can be implemented w/o changing the API.  the calling
 *  application specifies how many send and receive buffers are
 *  needed for its communication needs.  these buffers are indexed
 *  as [0-(b-1)].  it is important that the buffer index should not
 *  be confused with the processor index.  often, for simplicities
 *  sake, the processor index is used to refer to the specific 
 *  buffer index, but this isn't always the case, nor is it 
 *  required.
 *
 */

static char RCSid[] = "$Id: comm_prims.c,v 1.2 2001/01/19 01:40:06 wrankin Exp $";


/* #define USEPVMBUFF */

#include <stdio.h>
#include <string.h>

#ifdef USE_PVM
#include "pvm3.h"
#endif

#ifdef USE_MPI
#include "mpi.h"
#endif

#include "comm.h"
#include "comm_buffer.h"

/*
 * here are my local statics
 */

static int CommNproc;
static int CommPid;
static int CommLastSendBuf;   /* ID of last send buffer */
static int CommLastRecvBuf;   /* ID of last recv buffer */

static int CommNumSendBuf;
static int CommNumRecvBuf;

#ifdef USEPVMBUFF
static int *CommSendBuf;
static int *CommRecvBuf;
#else
static CommBufPtr *CommSendBuf;
static CommBufPtr *CommRecvBuf;
#endif

#ifdef USE_PVM
static int *CommTids;         /* pvm tips to map local proc id */
#endif

#ifdef USE_MPI
/*
 * these structures are to handle the allocation and 
 * free-ing of the request objects used in the non-blocking
 * sends.  apparently, the LAM version of MPI doesn't like
 * us freeing them immediately after calling the sends 
 * because MPI_Finalize() uses requestors to decide when all
 * communication has been complete.
 *
 * these structures will allow us to free up requestors
 * only when we call Comm_Send() or new_message() using the same
 * output buffer that had been recently sent.
 *
 * note that this puts the burden of proper buffer reuse on the
 * user.  Perhaps we should investigate letting the user explicitly
 * call a wait function before each send?  or do we include this
 * in the send by default.
 *
 */

static MPI_Request **CommSendBufReq;
static int          *CommSendBufReqNum;

#endif


/*
 * indicate the number of total procs
 * initialize internal data structures and set up 
 * communications.
 *
 * this is assuming MIMD and embedded - can we make this
 * re-entrant so as to allow for multiple communication
 * contexts?  perhaps use some sort of context structure?
 *
 * this structure would contain the arrays of processors
 * that are communicating, as well as the arrays of send
 * and receive buffers that are used to communicate.
 *
 * this would be similar to an MPI context, or a pvm
 * tid array.
 *
 * maybe later...
 *
 */

void comm_init( int nprocs )
{ 

   int i;
   int info;

   /*
    * save the number of processors locally
    */

   CommNproc = nprocs;

#ifdef USE_PVM
   /* 
    * everyone join a group, and then barrier to make
    * sure that everyone finishes
    */

   CommPid = pvm_joingroup( "PmtaCommGroup" );
   info = pvm_barrier( "PmtaCommGroup", nprocs ); 

   /*
    * determin the ids of the other processors.
    */

   CommTids = (int *)malloc(nprocs*sizeof(int));
   if ( CommTids == NULL ) {
      fprintf(stderr, "Error: malloc of CommTids failed\n");
      exit(-1);
   }

   for ( i=0; i<nprocs; i++ ) {
      CommTids[i] = pvm_gettid( "PmtaCommGroup", i );
      if ( CommTids[i] < 0 ) {
	 fprintf(stderr, "Error: gettid(%d) returned %d\n", i, CommTids[i] );
	 exit(-1);
      }
   }
#endif

#ifdef USE_MPI
   MPI_Comm_rank(MPI_COMM_WORLD,&CommPid);
#endif

   /*
    * null out send and receive buffer arrays.
    * they are initialized later
    */

   CommSendBuf = NULL;
   CommRecvBuf = NULL;

   /* initialize last buffer pointers */

   CommLastSendBuf = 0;
   CommLastRecvBuf = 0;

} /* comm_init */


/* 
 * comm_delete() - destructor.  free up all allocated structures
 *   we should also free up the comm buffers wit this.
 */

void comm_delete() {

   int i;

   /*
    * free up all structure allocated by comm_init()
    */

#ifdef USE_PVM 

   free(CommTids);

#endif

   /*
    * need to free up any individual send/recv buffers
    * allocated in comm_mkbuffs()
    */

#ifdef USEPVMBUFF
   if ( CommSendBuf != NULL ) 
      free(CommSendBuf);
   if ( CommRecvBuf != NULL ) 
      free(CommRecvBuf);

#else
   
   if ( CommSendBuf != NULL ) {
      for ( i=0; i<CommNumSendBuf; i++ ) {
	 if ( CommSendBuf[i] != NULL ) {
	    comm_buf_delete(CommSendBuf[i]);
	 }
      } 
      free(CommSendBuf);
   }

   if ( CommRecvBuf != NULL ) {
      for ( i=0; i<CommNumRecvBuf; i++ ) {
	 if ( CommRecvBuf[i] != NULL ) {
	    comm_buf_delete(CommRecvBuf[i]);
	 }
      } 
      free(CommRecvBuf);
   }

#endif

#ifdef USE_MPI

   /* free send buffer request objects */
   if ( CommSendBufReq != NULL ) {
      for ( i=0; i<CommNumSendBuf; i++ ) {
	 if ( CommSendBufReq[i] != NULL ) {
	    free( CommSendBufReq[i] );
	 }
      }
      free( CommSendBufReq );
   }

   if ( CommSendBufReqNum != NULL ) {
      free( CommSendBufReqNum );
   }

#endif

}


/*
 * comm_mypid() - returns the process id of the current process.
 */

int comm_mypid() {

   return CommPid;

}


/*
 * comm_mkbuffs( )- create the send and receive buffers needed
 *
 */

void comm_mkbuffs( int numsbuf, int numrbuf ) {

   int i, j;   /* loop counters */

   /* error checking */

   if ( numsbuf < 1 ) {
      fprintf(stderr, "Error: must allocate at least one send buff\n");
      exit(-1);
   }
   if ( numrbuf < 1 ) {
      fprintf(stderr, "Error: must allocate at least one recv buff\n");
      exit(-1);
   }

#ifdef USEPVMBUFF
   CommSendBuf = (int *)malloc(numsbuf*sizeof(int));
   if ( CommSendBuf == NULL ) {
      fprintf(stderr, "Error: malloc of CommSendBuf failed\n");
      exit(-1);
   }
   CommNumSendBuf = numsbuf;

   CommRecvBuf = (int *)malloc(numrbuf*sizeof(int));
   if ( CommRecvBuf == NULL ) {
      fprintf(stderr, "Error: malloc of CommRecvBuf failed\n");
      exit(-1);
   }
   CommNumRecvBuf = numrbuf;

   /* a bufferid of 0 is "no buffer" in pvm */
   for ( i=0; i<numsbuf; i++ ) {
      CommSendBuf[i] = 0;
   }
   for ( i=0; i<numrbuf; i++ ) {
      CommRecvBuf[i] = 0;
   }

#else
   CommSendBuf = (CommBufPtr *)malloc(numsbuf*sizeof(CommBufPtr));
   if ( CommSendBuf == NULL ) {
      fprintf(stderr, "Error: malloc of CommSendBuf failed\n");
      exit(-1);
   }
   for ( i=0; i<numsbuf; i++ ) {
      CommSendBuf[i] = comm_buf_create(1,1);
      if ( CommSendBuf[i] == NULL ) {
	 fprintf(stderr, "Error: malloc of CommSendBuf failed\n");
	 exit(-1);
      }
   }
   CommNumSendBuf = numsbuf;

   CommRecvBuf = (CommBufPtr *)malloc(numrbuf*sizeof(CommBufPtr));
   if ( CommRecvBuf == NULL ) {
      fprintf(stderr, "Error: malloc of CommRecvBuf failed\n");
      exit(-1);
   }
   for ( i=0; i<numrbuf; i++ ) {
      CommRecvBuf[i] = comm_buf_create(1,1);
      if ( CommRecvBuf[i] == NULL ) {
	 fprintf(stderr, "Error: malloc of CommRecvBuf failed\n");
	 exit(-1);
      }
   }
   CommNumRecvBuf = numrbuf;
#endif

#ifdef USE_MPI
   /* allocate send buffer request objects */

   CommSendBufReq = (MPI_Request **)malloc(numsbuf*sizeof(MPI_Request *));
   if ( CommSendBufReq == NULL ) {
      fprintf(stderr, "Error: malloc of CommSendBufReq failed\n");
      exit(-1);
   }
   for ( i=0; i<numsbuf; i++ ) {
      CommSendBufReq[i] = (MPI_Request *)malloc(3*sizeof(MPI_Request));
      if ( CommSendBufReq[i] == NULL ) {
	 fprintf(stderr, "Error: malloc of CommSendBuf failed\n");
	 exit(-1);
      }
   }
   CommSendBufReqNum = (int *)malloc(numsbuf*sizeof(int));
   if ( CommSendBufReqNum == NULL ) {
      fprintf(stderr, "Error: malloc of CommSendBufReqNum failed\n");
      exit(-1);
   }

   /* initialize values */
   for ( i=0; i<numsbuf; i++ ) {
      CommSendBufReqNum[i] = 0;
      for ( j=0; j<3; j++ ) {
	 /* doesn't look like we need initializing */
      }
   }	 
#endif

}


/*
 * comm_newmsg() - start a new message in the specified send buffer
 *
 */

void comm_newmsg( int buf ) {

#ifdef USE_MPI
   int nreqs;
   MPI_Request *reqs;
#endif

   if ( buf < 0 ) {
      fprintf(stderr,"Error: must specify a send buffer \n");
      return;
   }

   /*
    * need to add code here to make sure that for the 
    * MPI case, the old message in this buffer has been sent.
    * we should probably put a check/field in the buffer structure
    * to track the sent/newmsg status of the buffer and thus not
    * allow users to pack data in a buffer that has already been 
    * sent (but not received)
    */
#ifdef USE_MPI
   /*
    * before using this buffer, we need to make sure that 
    * we wait for any outstanding send requests that may
    *  be using this buffer.
    * 
    */

   nreqs = CommSendBufReqNum[buf];
   reqs = CommSendBufReq[buf];
   if ( nreqs > 0 ) {
      MPI_Waitall(nreqs,reqs,MPI_STATUS_IGNORE);
   }
   CommSendBufReqNum[buf] = 0;

#endif


#ifdef USEPVMBUFF
   CommSendBuf[buf] = pvm_mkbuf(PvmDataDefault);
   pvm_setsbuf(CommSendBuf[buf]);
   CommLastSendBuf = buf;

#else

   CommLastSendBuf = buf;
   comm_buf_clear( CommSendBuf[buf] );

#endif

}

/* 
 * comm_pkint() - pack integer data into the specified send buffer
 *   if buffer id is -1, then use the last buffer.
 */

void comm_pkint( int buf, int *ibuf, int nint ) {

#ifdef USEPVMBUFF
   if ( buf >= 0 ) {
      if ( buf != CommLastSendBuf ) {
	 pvm_setsbuf(CommSendBuf[buf]);
	 CommLastSendBuf = buf;
      }
   }

   pvm_pkint( ibuf, nint, 1 );
#else
   if ( buf < 0 ) {
      buf = CommLastSendBuf;
   }
   else {
      CommLastSendBuf = buf;
   }

   comm_buf_addint( CommSendBuf[buf], ibuf, nint );

#endif

}


/* 
 * comm_pkdbl() - pack double data into the specified send buffer
 *   if buffer id is -1, then use the last buffer.
 */

void comm_pkdbl( int buf, double *fbuf, int ndbl ) { 

#ifdef USEPVMBUFF
   if ( buf >= 0 ) {
      if ( buf != CommLastSendBuf ) {
	 pvm_setsbuf(CommSendBuf[buf]);
	 CommLastSendBuf = buf;
      }
   }

   pvm_pkdouble( fbuf, ndbl, 1 );

#else
   if ( buf < 0 ) {
      buf = CommLastSendBuf;
   }
   else {
      CommLastSendBuf = buf;
   }

   comm_buf_adddbl( CommSendBuf[buf], fbuf, ndbl );

#endif

}

/* 
 * comm_upkint() - unpack double data from the specified buffer
 *   if buffer id is -1, then use the last buffer.
 *
 * really, this needs more error checking to see if we run
 *   past the end of the buffer -- maybe later.
 */

void comm_upkint( int buf, int *ibuf, int nint ) {


#ifdef USEPVMBUFF
   if ( buf != -1 ) {
      if ( buf != CommLastRecvBuf ) {
	 pvm_setrbuf(CommRecvBuf[buf]);
	 CommLastRecvBuf = buf;
      }
   }
   pvm_upkint( ibuf, nint, 1 );

#else
   if ( buf < 0 ) {
      buf = CommLastRecvBuf;
   }
   else {
      CommLastRecvBuf = buf;
   }

   comm_buf_getint( CommRecvBuf[buf], ibuf, nint );

#endif

}


/* 
 * comm_upkdbl() - unpack double data from the specified buffer
 *   if buffer id is -1, then use the last buffer.
 *
 * really, this needs more error checking to see if we run
 *   past the end of the buffer -- maybe later.
 */

void comm_upkdbl( int buf, double *fbuf, int ndbl ) {


#ifdef USEPVMBUFF
   if ( buf != -1 ) {
      if ( buf != CommLastRecvBuf ) {
	 pvm_setrbuf(CommRecvBuf[buf]);
	 CommLastRecvBuf = buf;
      }
   }
   pvm_upkdouble( fbuf, ndbl, 1 );

#else
   if ( buf < 0 ) {
      buf = CommLastRecvBuf;
   }
   else {
      CommLastRecvBuf = buf;
   }

   comm_buf_getdbl( CommRecvBuf[buf], fbuf, ndbl );

#endif

}


/* 
 *  comm_send( ) - non-blocking send for the specified send buffer
 *  if buf id is -1, then use the last buffer id as the proc.
 *
 *  each pvm_send() does an implicit free() of the buffer, so a
 *  new buffer will need to be created before further data is packed
 *  into the buffer.
 *
 *  zero out the send buffer to indicate that there is no longer
 *  a valid buffer.  (Although I don't seem to do this in any case)
 *
 *  for the MPI implementation, immediate (non-blocking) sends are 
 *  used, with a waitall() to allow buffer data processing to complete.
 */

void comm_send( int buf, int proc, int msg ) {

#ifdef USE_PVM

#ifdef USEPVMBUFF

   if ( buf != -1 ) {
      if ( buf != CommLastSendBuf ) {
	 pvm_setsbuf( CommSendBuf[buf] );
	 CommSendBuf[buf] = 0;
      }
   }
   else {
      CommSendBuf[CommLastSendBuf] = 0;
   }

   pvm_send( CommTids[proc], msg );
   
#else

   CommBufPtr cbp;
   
   if ( buf < 0 ) {
      buf = CommLastSendBuf;
   }
   else {
      CommLastSendBuf = buf;
   }

   cbp = CommSendBuf[buf];

   pvm_psend( CommTids[proc], msg, &(cbp->icurr), 2, PVM_INT );
   if ( cbp->icurr > 0 ) {
      pvm_psend( CommTids[proc], msg, cbp->iarray, cbp->icurr, PVM_INT );
   }
   if ( cbp->fcurr > 0 ) {
      pvm_psend( CommTids[proc], msg, cbp->farray, cbp->fcurr, PVM_DOUBLE );
   }

#endif
#endif

#ifdef USE_MPI

   int         i;
   CommBufPtr  cbp;
   MPI_Request *reqs;
   MPI_Status  stats[3];
   
   if ( buf < 0 ) {
      buf = CommLastSendBuf;
   }
   else {
      CommLastSendBuf = buf;
   }

   cbp = CommSendBuf[buf];
   reqs = CommSendBufReq[buf];



   /* send the count followed by the two arrays */
   i = 0;
   MPI_Isend(&(cbp->icurr),2,MPI_INT,proc,msg,MPI_COMM_WORLD,&(reqs[i]));
   i++;
   /* MPI_Send(&(cbp->icurr),2,MPI_INT,proc,msg,MPI_COMM_WORLD); */
   if ( cbp->icurr > 0 ) {
      MPI_Isend(cbp->iarray,cbp->icurr,MPI_INT,proc,msg,MPI_COMM_WORLD,&(reqs[i]));
      i++;
      /* MPI_Send(cbp->iarray,cbp->icurr,MPI_INT,proc,msg,MPI_COMM_WORLD); */
   }
   if ( cbp->fcurr > 0 ) {
      MPI_Isend(cbp->farray,cbp->fcurr,MPI_DOUBLE,proc,msg,MPI_COMM_WORLD,&(reqs[i]));
      i++;
      /* MPI_Send(cbp->farray,cbp->fcurr,MPI_DOUBLE,proc,msg,MPI_COMM_WORLD); */
   }  
   CommSendBufReqNum[buf] = i;

#endif   

}


/* 
 *  comm_recv( ) - blocking receive for the current recv buffer
 *
 *  the pvm_recv() call itself allocates a new receive buffer.
 *  all we do is store this value so that we can swap between
 *  receive buffers later.
 *
 *  it would probably be good to return the processor ID from
 *  the received message, so the called knows which buffer the
 *  received message came from.
 *
 *  we can make this more efficient in MPI by using the MPI_Probe 
 *  command to determine the size of the sent buffers instead of 
 *  having to send the sizes seperately.
 *
 */

void comm_recv( int buf, int proc, int msg ) {

#ifdef USE_PVM
#ifdef USEPVMBUFF

   if ( buf < 0 ) {
      fprintf(stderr,"Error: must specify a receive buffer \n");
      return;
   }

   if ( proc == -1 )
      CommRecvBuf[buf] = pvm_recv( -1, msg );
   else
      CommRecvBuf[buf] = pvm_recv( CommTids[proc], msg );

#else
   static int nbuf[2];
   int tid, tag, cnt, bsz;
   CommBufPtr cbp;

   if ( buf < 0 ) {
      fprintf(stderr,"Error: must specify a receive buffer \n");
      return;
   }

   cbp = CommRecvBuf[buf];
   CommLastRecvBuf = buf;

   /* 
    * note that I am setting tid and msg from the return of
    * this recv() in case they were wildcards.
    */
   if ( proc == -1 )
      pvm_precv( -1, msg, nbuf, 2, PVM_INT, &tid, &tag, &cnt );
   else
      pvm_precv( CommTids[proc], msg, nbuf, 2, PVM_INT, &tid, &tag, &cnt );

   bsz = comm_buf_resize( cbp, nbuf[0], nbuf[1] );

   cbp->isize = nbuf[0];
   cbp->fsize = nbuf[1];

   if ( nbuf[0] > 0 )
      pvm_precv( tid, tag, cbp->iarray, nbuf[0], PVM_INT, &tid, &tag, &cnt );

   if ( nbuf[1] > 0 ) 
      pvm_precv( tid, tag, cbp->farray, nbuf[1], PVM_DOUBLE, &tid, &tag, &cnt );
   comm_buf_reset( cbp );

#endif
#endif


#ifdef USE_MPI

   static int nbuf[2];
   int rproc;

   CommBufPtr cbp;
   
   MPI_Status stat;

   if ( buf < 0 ) {
      fprintf(stderr,"Error: must specify a receive buffer \n");
      return;
   }

   cbp = CommRecvBuf[buf];
   CommLastRecvBuf = buf;

   if ( proc == -1 )
      MPI_Recv(nbuf,2,MPI_INT,MPI_ANY_SOURCE,msg,MPI_COMM_WORLD,&stat);
   else
      MPI_Recv(nbuf,2,MPI_INT,proc,msg,MPI_COMM_WORLD,&stat);

   rproc = stat.MPI_SOURCE;

   comm_buf_resize( cbp, nbuf[0], nbuf[1] );
   
   cbp->isize = nbuf[0];
   cbp->fsize = nbuf[1];

   if ( nbuf[0] > 0 )
      MPI_Recv( cbp->iarray, nbuf[0], MPI_INT,rproc,msg,MPI_COMM_WORLD,&stat );
   if ( nbuf[1] > 0 )
      MPI_Recv( cbp->farray, nbuf[1], MPI_DOUBLE,rproc,msg,MPI_COMM_WORLD,&stat );

   comm_buf_reset( cbp );


#endif

}  /* comm_recv() */


/*
 * immediate pack and sends - no buffering needed.
 */

/* NOT IMPLEMENTED YET */
void comm_pkint_send( int proc, int msg, int nint, int *ibuf ) { }
void comm_pkdbl_send( int proc, int msg, int ndbl, double *fbuf ) { }

/*
 * immediate recv and unpacks - no buffering needed.
 */

/* NOT IMPLEMENTED YET */
void comm_recv_upkint( int proc, int msg, int nint, int *ibuf ) { }
void comm_recv_upkdbl( int proc, int msg, int ndbl, double *fbuf ) { }


/*
 * debugging tools
 */

void comm_dump_send_buf( int buf )
{

   comm_buf_dump(CommSendBuf[buf]);

} /* comm_dump_buf */


void comm_dump_recv_buf( int buf )
{

   comm_buf_dump(CommRecvBuf[buf]);

} /* comm_dump_buf */
