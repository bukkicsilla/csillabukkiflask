/*
 *  test program for Macroscopic potential
 *
 *  w. t. rankin
 *
 *  9/1/95
 *
 */

static char RCSid[] = "$Id: ffttest.c,v 1.1 1999/12/24 17:34:09 wrankin Exp $";

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mpe.h"

#define MAXP 256

static Mtype LocalAccum;

main(int argc, char **argv)
{

  int     i,j,k,l,m,n;
  int     x,y,z;
  int     p, fblk, np;
  Real    q1[MAXP], q2[MAXP];
  Real    pot, pout[MAXP];
  Real    dx,dy,dz,d2;
  Vector  v, vp1[MAXP], vp2[MAXP];
  Vector  f, fout[MAXP];
  Mtype   M1, M2, M3, M4;
  Mtype   T1, T2;
  Mtype   L1, L2, L3, L4;

  FILE *fp;

  if ( argc != 3 ) {
     fprintf(stderr,"Usage: %s <mp> <nparts>\n",argv[0]);
     exit(-1);
  }
  
  p = atoi(argv[1]);
  np = atoi(argv[2]);

  fblk = 4;

  /* separation vector */
  v.x = 2.0;
  v.y = 2.0;
  v.z = 1.0;

  /* initialize arrays and alloc multipoles */
  Cinit(p);
  CinitF(p,fblk);
/*   CallocFrev(&LocalAccum,Dpmta_Mp,Dpmta_FftBlock); */
/*   CMclearFrev(LocalAccum,Dpmta_Mp,Dpmta_FftBlock); */

/*   MpeSize = CsizeF(Dpmta_Mp); */

  CallocF(&M1,p,fblk);
  CallocF(&M2,p,fblk);
  CallocFrev(&T1,p,fblk);
  CallocFrevS(&T2,p,fblk);
  Calloc(&L1,p);
  Calloc(&L2,p);

  /* create a set of random particles */

  for ( i=0; i<np; i++) {
    vp1[i].x = drand48() - 0.5;
    vp1[i].y = drand48() - 0.5;
    vp1[i].z = drand48() - 0.5;
    q1[i] = 10.0 * (Real)(((i%2)*2)-1);
  }

  /* evaluation particles */
  for ( i=0; i<np; i++) {
    vp2[i].x = drand48() - 0.5;
    vp2[i].y = drand48() - 0.5;
    vp2[i].z = drand48() - 0.5;
    q2[i] = 10 * (Real)(((i%2)*2)-1);
  }

  /* add eight particles to a multipole */
  CMclearF(M1,p);
  for ( i=0; i<np; i++ ) {
    AddMultipoleC(M1,p,q1[i],vp1[i]);
  }

  /* warp it */
  Warp_M2L(M1,M2,p,fblk);

  /* compute the transfer matrix. */
  CMclearFshort(T2,p,fblk);
  copyG(T2,p,v);
  Warp_Short(T2,p,fblk);    
     
  /* shift it to a local accum and IFFT*/
  CMclearFrev(T1,p,fblk);
  M2L_C_Fshort(M2,T1,T2,p,fblk);
  /* M2L_C_F(M2,T1,p,fblk, v); */
  Unwarp_M2L(T1,L2,p,fblk);

  M2L_C(M1,L1,p,v);
  
  /*
   * now check the potentials and forces at distant regions
   */

  for ( i=0; i<np; i++ ) {
     Force_C(L1,p,q2[i],vp2[i],&(pout[i]),&(fout[i]));
  }

  /* dump the results */
  fp = fopen("mpole.out","w");
  for ( i=0; i<np; i++ ) {
    fprintf(fp,"%20.16f %20.16f %20.16f %20.16f\n",
	    fout[i].x,fout[i].y,fout[i].z,pout[i]);
  }
  fclose(fp);


  /*
   * now check the potentials and forces at distant regions
   */

  for ( i=0; i<np; i++ ) {
     Force_C(L2,p,q2[i],vp2[i],&(pout[i]),&(fout[i]));
  }

  /* dump the results */
  fp = fopen("mpolefft.out","w");
  for ( i=0; i<np; i++ ) {
    fprintf(fp,"%20.16f %20.16f %20.16f %20.16f\n",
	    fout[i].x,fout[i].y,fout[i].z,pout[i]);
  }
  fclose(fp);


  /* now lets comput the direct and dump to file */

  for ( i=0; i<np; i++ ) {
    pout[i] = 0.0;
    fout[i].x = 0.0;
    fout[i].y = 0.0;
    fout[i].z = 0.0;
  }

  for ( i=0; i<np; i++ ) {
    for ( j=0; j<np; j++ ) { 
      dx = vp1[j].x - vp2[i].x - v.x;
      dy = vp1[j].y - vp2[i].y - v.y;
      dz = vp1[j].z - vp2[i].z - v.z;
      d2 =  dx*dx + dy*dy + dz*dz;
      pot = q1[j]*q2[i] / sqrt(d2);
      pout[i] += pot;
      fout[i].x -= pot * dx / d2;
      fout[i].y -= pot * dy / d2;
      fout[i].z -= pot * dz / d2;
    }
  }

  /* dump the results */
  fp = fopen("direct.out","w");
  for ( i=0; i<np; i++ ) {
    fprintf(fp,"%20.16f %20.16f %20.16f %20.16f\n",
	    fout[i].x,fout[i].y,fout[i].z,pout[i]);
  }
  fclose(fp);
  
} /* main */
