/* 
*  mpe_proto.h - prototypes for Multipole library internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1998 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the internal
*  (non exported) functions.
*
*/

/*
 * RCS Id:
 *
 * $Id: mpe_proto.h,v 1.2 1999/08/04 20:18:10 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: mpe_proto.h,v $
 * Revision 1.2  1999/08/04 20:18:10  wrankin
 * removed all of the calls to log() from the main loops.
 *
 * Revision 1.1  1998/12/01 16:13:52  wrankin
 * general cleanup of code:
 *  - changed procedure return type to void where appropriate
 *  - added internal prototype declarations
 *  - removed unused variables
 *
 *
 */


/*
 * mpe_fft.c
 */

void row_fft( Real *, int );
void row_ifft( Real *, int );
void col_fft( Real *, int, int, int * );
void col_ifft( Real *, int, int, int * );
void col_fftS( Real *, int, int, int * );
void col_ifftS( Real *, int, int, int * );
void fftv( Real *, unsigned long, int, int );
void ffth( Real *, int );
void iffth( Real *, int );
void four1( Real *, unsigned long, int );

/*
 * mpe_misc.c
 */

void Cart2Sph( Vector, SphVector *);
