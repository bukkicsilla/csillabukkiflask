/* 
*  dpmta_distmisc.c - misc routines to perform mapping between data and
*    distributed processed id.
*
*  these routines are used by both the master and slave processes.  thus
*  they cannot access any global data structures.  most of these
*  functions were taken from dpmta_slvmisc.c
*
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*/

static char rcsid[] = "$Id: dpmta_distmisc.c,v 3.2 1999/12/24 18:03:44 wrankin Exp $";

/*
 * revision history:
 *
 * $Log: dpmta_distmisc.c,v $
 * Revision 3.2  1999/12/24 18:03:44  wrankin
 * all compile time directives are now contained in the dpmta_config.h
 *   header file instead of being passed via make.
 *
 * Revision 3.1  1999/06/14 21:20:40  wrankin
 * added test code for scurve data indexing
 *
 * Revision 3.0  1999/04/01 16:45:00  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.6  1998/12/01 20:59:29  wrankin
 * enhanced dynamic allocation of cells
 * cleanup of code.
 *
 * Revision 2.5  1998/08/04 15:16:51  wrankin
 * stupid fix for row/col addressing code
 *
 * Revision 2.4  1998/06/30 17:29:53  wrankin
 * new improved hilbert generation code
 *
 * Revision 2.3  1998/04/29 18:36:21  wrankin
 * fixed code that creates RLcell counter - now works with row/col index
 *
 * Revision 2.2  1998/04/01 20:08:04  wrankin
 * added support for HILBERT ordering
 * general cleanup of code structure (more OOP if you will)
 *
 * Revision 2.1  1997/09/29 20:24:52  wrankin
 * fixed problem with invalid (empty) multipoles during upward pass.
 * cell indexing by processor was inconsistant between master/slave.
 *
 *
 */

/* include files */
#include <stdlib.h>
#include <stdio.h>

/* dpmta configuration */
#include "dpmta_config.h"

/* internal prototypes */

void init_hilbert( int );
void delete_hilbert( );

void hil2mort( int, int ** );
void mort2hil( int, int ** );
int mort2hil_s( int, int );
int hil2mort_s( int, int );

void inittrans( int (*)[3] );
void copytrans( int (*)[3], int (*)[3] );
void comptrans( int, int (*)[3] );
void compitrans( int, int (*)[3] );
int applytrans( int (*)[3], int );
int mkgray( int, int );
int mkigray( int, int );

int cart2mort( int*, int );
void mort2cart( int, int, int* );

int rco2mort( int, int );
int mort2rco( int, int );

#ifdef SCURVE
int sco2mort( int, int );
int mort2sco( int, int );
#endif


/* local global data structures */

static int Nlevels;

static int **I2C_Array;
static int **C2I_Array;

static int (*T)[3][3];


/****************************************************************
*
*  Dist_Init() - allocate and initialize internal data structures
*
*/

void Dist_Init( int numlevels )
{

   int i;
   int numcells;
#if defined ROWCOL || defined SCURVE
   int j;
#endif

   /* save this value for de-allocation later */
   Nlevels = numlevels;

   /*
    *  this section allocates the cell<->index lookup table depending
    *  on the ordering strategy (hilbert, morton, rowcol)
    */
   
#ifdef HILBERT
   /* allocate arrays for hilbert transforms */
   init_hilbert(numlevels);
#endif
   
   /* allocate arrays for mapping hilbert to morton */
   I2C_Array = (int **)malloc(numlevels*sizeof(int *));
   if ( I2C_Array == (int **)NULL ) {
      fprintf(stderr,"ERROR: Dist_Init() - malloc failed\n");
      exit(-1);
   }

   for ( i=0; i<numlevels; i++ ) {
      numcells = 0x1<<(3*i);
      I2C_Array[i] = (int *)malloc(numcells*sizeof(int));
      if ( I2C_Array[i] == (int *)NULL ) {
	 fprintf(stderr,"ERROR: Dist_Init() - malloc failed\n");
	 exit(-1);
      }
   } /* for i */
   
   C2I_Array = (int **)malloc(numlevels*sizeof(int *));
   if ( C2I_Array == (int **)NULL ) {
      fprintf(stderr,"ERROR: Dist_Init() - malloc failed\n");
      exit(-1);
   }

   for ( i=0; i<numlevels; i++ ) {
      numcells = 0x1<<(3*i);
      C2I_Array[i] = (int *)malloc(numcells*sizeof(int));
      if ( C2I_Array[i] == (int *)NULL ) {
	 fprintf(stderr,"ERROR: Dist_Init() - malloc failed\n");
	 exit(-1);
      }
   } /* for i */


   /*
    * this section will allocate the start/end-cell arrays
    * used to partition the cell table among the processors
    */


#ifdef HILBERT
   hil2mort( numlevels, I2C_Array );
   mort2hil( numlevels, C2I_Array );
#endif

#ifdef ROWCOL
   for ( i=0; i<numlevels; i++ ) {
      numcells = 0x1<<(i*3);
      for ( j=0; j<numcells; j++ ) {
	 I2C_Array[i][j] = rco2mort(j,i);
	 C2I_Array[i][j] = mort2rco(j,i);
      } /* for j */
   } /* for i */
#endif

#ifdef SCURVE
   for ( i=0; i<numlevels; i++ ) {
      numcells = 0x1<<(i*3);
      for ( j=0; j<numcells; j++ ) {
	 I2C_Array[i][j] = sco2mort(j,i);
	 C2I_Array[i][j] = mort2sco(j,i);
      } /* for j */
   } /* for i */
#endif

   
} /* Dist_Init() */


/****************************************************************
*
*  Dist_Delete() - free up internal data structures
*
*/

void Dist_Delete()
{
   int i;


#ifdef HILBERT
   /* delete arrays for hilbert transforms */
   delete_hilbert();
#endif
   
   /* free lookup table arrays */
   for ( i=0; i<Nlevels; i++ ) {
      free(I2C_Array[i]);
      free(C2I_Array[i]);
   } /* for i */
   free(I2C_Array);
   free(C2I_Array);
   
} /* Dist_Delete() */


/****************************************************************
*
*  the following routines are used in indexing the cell table
*  structure.  therefor, all the inputs and outputs are for
*  Morton ordering.
*/

/****************************************************************
*
*  returns the parent cell id for any given cell
*/

int getparent( int cellid )
{
   return (cellid >> 3);
} /* get parent */


/****************************************************************
*
*  returns the lowest indexed child cell id for any given cell
*/

int getfirstchild( int cellid )
{
   return (cellid << 3);
} /* get first child */


/*****************************************************************
*
*  returns the cell id for a given index
*
*/

int index2cell( int index, int level )
{
   
#if defined HILBERT || defined ROWCOL || defined SCURVE
   return I2C_Array[level][index];
#else
   return index;
#endif

} /* index2cell */


/*****************************************************************
*
*  returns the index for a given cell id.
*
*/

int cell2index( int cellid, int level )
{

#if defined HILBERT || defined ROWCOL || defined SCURVE
   return C2I_Array[level][cellid];
#else
   return cellid;
#endif
   
} /* cell2index */


/****************************************************************
*
*  the following routines implement the translation between
*  Hilbert and Morton encoding schemes.  they should never be
*  called by any external routines.
*
*/

/****************************************************************
 *
 * init_hilbert() - initialize array of 3x3 transfer matrices.
 *
 * okay, so we alloc everything in one swell-foop and
 * then use an ugly recast to make it believe that we are
 * dealing with a solid array of nx3x3.
 *
 * i spent all afternoon getting the casting to work.
 *
 * deal with it.
 *
 */


void init_hilbert( int nlevels ) 
{
   T = (int (*)[3][3])malloc((nlevels+1)*3*3*sizeof(int));
}


/****************************************************************
 *
 * delete_hilbert() - free up data structures
 *
 */

void delete_hilbert()
{
   free(T);
}


/****************************************************************
 *
 *  hil2mort() - convert hilbert ordering to morton coord.
 *
 *  this procedure load the array mort[] with the morton
 *  index for all corresponding hilbert indices.
 *
 *  each level of the array, indexed from 0->(nlevels-1)
 *  contains 8^n entries, where 'n' is the index.
 *
 */


void hil2mort( int nlevels, int **mort )
{

   int level;
   int index;
   int child;
   int bottom;
   int imask, cmask;
   int gray, result, morton;
   
   /* punt when we ascend to level 0 */
   level = 1;

   /* fill array from 0->(nlevels-1) */
   bottom = nlevels - 1;

   /* we never actually fill the zero level */
   mort[0][0] = 0;
   
   /* push child=0 */
   index = 0;
   child = 0;
   cmask = 0x07;
   imask = ~cmask;

   /* hold the final result in morton */
   morton = 0;

   inittrans( T[1] );
      
   while ( level > 0 ) {

      
      /* change to gray code */

      gray = mkgray( child, 3 );
      
      /* apply transform */

      result = applytrans( T[level], gray );

      /* compute new transfor */
      copytrans( T[level], T[level+1] );
      comptrans( gray, T[level+1] );

      
      if ( level == bottom ) {

	 if (child < 8) {

	    morton = (morton&imask)|(result&cmask);

	    mort[level][index] = morton;

	    child++;
	    index = (index&imask)|(child&cmask);

	 } /* child < 8 */
	 
	 else {

	    morton >>= 3;

	    level--;
	    index >>= 3;
	    child = index & cmask;
	    child++;

	 } /* last child */

      }
      else { /* not bottom */

	 if (child < 8) {

	    morton = (morton&imask)|(result&cmask);
	    index = (index&imask) | (child&cmask);

	    mort[level][index] = morton;

	    morton <<= 3;
	    index <<= 3;

	    child = 0;
	    level++;

	 } /* child < 8 */

	 else { 

	    morton >>= 3;

	    level--;
	    index >>= 3;
	    child = index & cmask;
	    child++;

	 } /* else last child */

      } /* if not bottom */

   } /* while level */
	 
} /* hil2mort() */


/****************************************************************
*
*  hil2mort_s() - convert a single hilbert index to  the corresponsding
*     morton coordinate.
*
*  parameters -
*    hil - input hilber number
*    level - number of levesl of decomposition
*
*  returns -
*    morton order number
*
*/


int hil2mort_s( int hil, int level )
{
   
   int mask1;
   int mort1, mort2;
   int curr;
   int t[3][3];
   int width;


   /*
    * initialize xform matrix
    */

   inittrans( t );
   
   /*
    * grab the next top [3] bits
    */

   width = 3 * ( level - 1 );
   mask1 = ( 0x1 << 3 ) - 1;
   mort2 = 0;

   while ( width >= 0 ) {

      /*
       * grab the next three bits working from the msb down.
       */
      
      curr = (hil >> width) & mask1;

      /*
       * convert current to grey code
       */

      mort1 = mkgray( curr, 3 );

      /*
      * apply xform matrix to curr (grey code) and
      * save
      */

      mort2 = (mort2<<3) | applytrans( t, mort1 );

      /*
      *  based upon position in curr, modify xform
      *  matrix.  dont need to do it if width==0.
      */
      
      if ( width > 0 ) {
	 comptrans( mort1, t );
      } /* if width */
   
      width -= 3;

   } /* while */

   return mort2;

} /* hil2mort_s */


/****************************************************************
 *
 *  mort2hil() - convert morton coord to hilbert index
 *
 *  this procedure load the array hil[] with the hilbert
 *  index for all corresponding morton coordinate.
 *
 *  each level of the array, indexed from 0->(nlevels-1)
 *  contains 8^n entries, where 'n' is the index.
 *
 */


void mort2hil( int nlevels, int **hil )
{

   int level;
   int index;
   int child;
   int bottom;
   int imask, cmask;
   int gray, result, hilbert;
   
   /* punt when we ascend to level 0*/
   level = 1;

   /* fill array from 0->(nlevels-1) */
   bottom = nlevels - 1;

   /* we never actually fill the zero level */
   hil[0][0] = 0;
   
   /* push child=0 */
   index = 0;
   child = 0;
   cmask = 0x07;
   imask = ~cmask;

   /* hold the final result in hilbert */
   hilbert = 0;

   inittrans( T[1] );
      
   while ( level > 0 ) {

      /* apply transform */
      gray = applytrans( T[level], child );

      /* change to gray code */
      result = mkigray( gray, 3 );
      
      /* compute new transfor */
      copytrans( T[level], T[level+1] );
      compitrans( result, T[level+1] );

      if ( level == bottom ) {

	 if (child < 8) {

	    hilbert = (hilbert&imask)|(result&cmask);

	    hil[level][index] = hilbert;

	    child++;
	    index = (index&imask)|(child&cmask);

	 } /* child < 8 */
	 
	 else {

	    hilbert >>= 3;

	    level--;
	    index >>= 3;
	    child = index & cmask;
	    child++;

	 } /* last child */

      }
      else { /* not bottom */

	 if (child < 8) {

	    hilbert = (hilbert&imask)|(result&cmask);
	    index = (index&imask) | (child&cmask);

	    hil[level][index] = hilbert;

	    hilbert <<= 3;
	    index <<= 3;

	    child = 0;
	    level++;

	 } /* child < 8 */

	 else { 

	    hilbert >>= 3;

	    level--;
	    index >>= 3;
	    child = index & cmask;
	    child++;

	 } /* else last child */

      } /* if not bottom */

   } /* while level */
	 
} /* mort2hil() */


/****************************************************************
*
*  mort2hil_s() - converts a single morton coordinate to the
*    corresponsding hilbert index
*
*  parameters -
*    mort - input morton coordinate
*    level - number of levels of decomposition
*
*  returns -
*    hilbert index cooresponding to the morton number
*
*
*/

int mort2hil_s( int mort, int level )
{
   int mask1;
   int hil1, hil2, hil3;
   int curr;
   int t[3][3];
   int width;

   /*
    * initialize xform matrix
    */

   inittrans( t );

   /*
    * grab the next top [3] bits
    */

   width = 3 * ( level - 1 );
   mask1 = ( 0x1 << 3 ) - 1;
   hil3 = 0;
   
   while ( width >= 0 ) {

      curr = (mort >> width) & mask1;

      /* apply xform matrix to curr (morton) */

      hil1 = applytrans( t, curr );
      
      /* convert recent dimension to an inverse grey code */
      
      hil2 = mkigray( hil1, 3 );
      
      /* accumulate new sub-coordinate in result */

      hil3 = (hil3 << 3) | hil2;
      
      /*
      * based upon position in curr, modify xform
      * matrix by multiplying it by the next incremental
      * transform dependant upon the current relative location
      * within the subcell.
      */

      if ( width > 0 ) {
	compitrans( hil2, t );
      } /* if width */
      
      width -= 3;

   }  /* while */

   return hil3;

} /* mort2hil_s */




/****************************************************************
 *
 * internal hilbert procedures - these routines support the hilbert
 *   generation code listed above.
 */

/****************************************************************
 *
 * inittrans() - initialize transfer matrix.
 *
 */

void inittrans( int t[][3] )
{
   int i,j;

   for ( i=0; i<3; i++ ) {
      for ( j=0; j<3; j++ ) {
	 if ( i == j )
	    t[i][j] = 1;
	 else
	    t[i][j] = 0;
      }
   }

} /* inittrans() */


/****************************************************************
 *
 *  copytrans() - copy transform matrix t1->t2.
 *
 */

void copytrans( int t1[][3], int t2[][3] )
{
   int i,j;

   for ( i=0; i<3; i++ ) {
      for ( j=0; j<3; j++ ) {
	 t2[i][j] = t1[i][j];
      }
   }

} /* copytrans() */


   
								 
/*****************************************************************
 *
 * comptrans() - compute transform matrix for hil2mort, apply result
 *    to matrix t1[][]
 *
 * based upon position in index, modify xform
 * matrix by multiplying it by the next incremental
 * transform dependant upon the current relative location
 * within the subcell.
 *
 * aka. we started with a morton coordinate, and converted it to an
 * inverse grey code to get  the corresponding  hilbert
 * coordinate within the sub-cell.  the resulting subcell is
 * rotated depending upon its position within the larger cell.
 *
 */

void comptrans( int index, int t1[][3] )
{

   int tmp;

   switch (index) {

   case 0x00:
     /* reflect around the x = z plane */
     tmp = t1[0][0];
     t1[0][0] = t1[0][2];
     t1[0][2] = tmp;
     tmp = t1[1][0];
     t1[1][0] = t1[1][2];
     t1[1][2] = tmp;
     tmp = t1[2][0];
     t1[2][0] = t1[2][2];
     t1[2][2] = tmp;
     break;

   case 0x01:
   case 0x03:
     /*
	     * reflect around x=z plane,
	     * followed by reflection around x=y
	     */
     tmp = t1[0][1];
     t1[0][1] = t1[0][0];
     t1[0][0] = t1[0][2];
     t1[0][2] = tmp;
     tmp = t1[1][1];
     t1[1][1] = t1[1][0];
     t1[1][0] = t1[1][2];
     t1[1][2] = tmp;
     tmp = t1[2][1];
     t1[2][1] = t1[2][0];
     t1[2][0] = t1[2][2];
     t1[2][2] = tmp;
     break;
	 
   case 0x02:
   case 0x06:
     /* reflect around the x=-y plane*/
     tmp = t1[0][0] ^ 0x2;
     t1[0][0] = t1[0][1] ^ 0x2;
     t1[0][1] = tmp;
     tmp = t1[1][0] ^ 0x2;
     t1[1][0] = t1[1][1] ^ 0x2;
     t1[1][1] = tmp;
     tmp = t1[2][0] ^ 0x2;
     t1[2][0] = t1[2][1] ^ 0x2;
     t1[2][1] = tmp;
     break;

   case 0x05:
   case 0x07:
     /*
      * inversion of 0x03 around y=-z
      * followed by reflection around x=-z
      */
     tmp = t1[0][2] ^ 0x2;
     t1[0][2] = t1[0][1] ^ 0x2;
     t1[0][1] = t1[0][0];
     t1[0][0] = tmp;
     tmp = t1[1][2] ^ 0x2;
     t1[1][2] = t1[1][1] ^ 0x2;
     t1[1][1] = t1[1][0];
     t1[1][0] = tmp;
     tmp = t1[2][2] ^ 0x2;
     t1[2][2] = t1[2][1] ^ 0x2;
     t1[2][1] = t1[2][0];
     t1[2][0] = tmp;
     break;
	      
   case 0x04:
     /* inversion of 0x00 around x=-x, z=-z */
     tmp = t1[0][0] ^ 0x2;
     t1[0][0] = t1[0][2] ^ 0x2;
     t1[0][2] = tmp;
     tmp = t1[1][0] ^ 0x2;
     t1[1][0] = t1[1][2] ^ 0x2;
     t1[1][2] = tmp;
     tmp = t1[2][0] ^ 0x2;
     t1[2][0] = t1[2][2] ^ 0x2;
     t1[2][2] = tmp;
     break;

   } /* switch index */

} /* comptrans() */


/*****************************************************************
 *
 *  compitrans() - compute transform matrix for mort2hil,
 *     apply result to matrix t1[][]
 *
 *  based upon position in index, modify xform
 *  matrix by multiplying it by the next incremental
 *  transform dependant upon the current relative location
 *  within the subcell.
 *
 *  this is essentially the application of the transposed matrix
 *  from the comptrans() function.
 *
 */

void compitrans( int index, int t[][3] )
{

   int tmp;

   switch (index) {

   case 0x00:
     /* reflect around the x = z plane */
     tmp = t[0][0];
     t[0][0] = t[2][0];
     t[2][0] = tmp;
     tmp = t[0][1];
     t[0][1] = t[2][1];
     t[2][1] = tmp;
     tmp = t[0][2];
     t[0][2] = t[2][2];
     t[2][2] = tmp;
     break;

   case 0x01:
   case 0x02:
     /* reflect around y=z plane */
     tmp = t[1][0];
     t[1][0] = t[0][0];
     t[0][0] = t[2][0];
     t[2][0] = tmp;
     tmp = t[1][1];
     t[1][1] = t[0][1];
     t[0][1] = t[2][1];
     t[2][1] = tmp;
     tmp = t[1][2];
     t[1][2] = t[0][2];
     t[0][2] = t[2][2];
     t[2][2] = tmp;
     break;
	 
   case 0x03:
   case 0x04:
     /* reflect around the x=-y plane*/
     tmp = t[0][0] ^ 0x2;
     t[0][0] = t[1][0] ^ 0x2;
     t[1][0] = tmp;
     tmp = t[0][1] ^ 0x2;
     t[0][1] = t[1][1] ^ 0x2;
     t[1][1] = tmp;
     tmp = t[0][2] ^ 0x2;
     t[0][2] = t[1][2] ^ 0x2;
     t[1][2] = tmp;
     break;

   case 0x05:
   case 0x06:
     /* inversion of 0x03 around y=-y, z=-z */
     tmp = t[2][0] ^ 0x2;
     t[2][0] = t[1][0] ^ 0x2;
     t[1][0] = t[0][0];
     t[0][0] = tmp;
     tmp = t[2][1] ^ 0x2;
     t[2][1] = t[1][1] ^ 0x2;
     t[1][1] = t[0][1];
     t[0][1] = tmp;
     tmp = t[2][2] ^ 0x2;
     t[2][2] = t[1][2] ^ 0x2;
     t[1][2] = t[0][2];
     t[0][2] = tmp;
     break;
	      
   case 0x07:
     /* inversion of 0x00 around x=-x, z=-z */
     tmp = t[0][0] ^ 0x2;
     t[0][0] = t[2][0] ^ 0x2;
     t[2][0] = tmp;
     tmp = t[0][1] ^ 0x2;
     t[0][1] = t[2][1] ^ 0x2;
     t[2][1] = tmp;
     tmp = t[0][2] ^ 0x2;
     t[0][2] = t[2][2] ^ 0x2;
     t[2][2] = tmp;
     break;

   } /* switch index */
   
} /* compitrans() */


/****************************************************************
 *
 * applytrans() - apply transform t[] to code and return results
 *
 */

int applytrans( int t[][3], int code )
{
   int i,j;
   int cur[3];
   int tmp;
   int res;

   res = 0;

   tmp = code;
   for ( i=0; i<3; i++ ) {
      cur[i] = tmp & 0x1;
      tmp >>= 0x1;
   }

   for ( i=2; i>=0; i-- ) {
      tmp = 0;
      for ( j=2; j>=0; j-- ) {
	 tmp |=  ((cur[j] & t[i][j]) ^ ((t[i][j]>>1) & t[i][j]));
      } /* for j */
      res = (res << 1) | tmp;
   } /* for i */

   return res;

} /* applytrans() */


/*****************************************************************
 *
 * mkgray() - convert and index to a gray code
 *
 */

int mkgray( int index, int len ) 
{

   int mask;
   int m;

   m = index;
   mask = 0x1 << len;
   while ( mask > 1 ) {
      if ( mask & index ) {
	 m ^= (mask >> 1);
      }
      mask >>= 1;
   }
   return m;

} /* mkgray() */


/*****************************************************************
 *
 * mkigray() - convert a gray code back to an index
 *
 */

int mkigray( int index, int len ) 
{

   int mask;
   int m;

   m = index;
   mask = 0x1 << len;
   while ( mask > 1 ) {
      if ( mask & m ) {
	 m ^= (mask >> 1);
      }
      mask >>= 1;
   }
   return m;

} /* mkigray() */



/****************************************************************
*
*  the following routines implement the translation between
*  cartesian coordinates and  Morton encoding schemes. 
*  they should never be called directly by any external routines.
*
*/

/**************************************************************** 
* 
*  mort2cart - translate morton ordered sequence into a 3-d cartesian
*  coordinate
*
*/

void mort2cart( int mort, int width, int* cart )
{

   int i;
   int x,y,z;
   int mask;

   x = 0;
   y = 0;
   z = 0;

   mask = 0x1;

   for ( i=0; i<width; i++ ) {
      x |= (mask & mort);
      mort >>= 1;
      y |= (mask & mort);
      mort >>= 1;
      z |= (mask & mort);
      mask <<= 1;
   } /* for i */

   cart[0] = x;
   cart[1] = y;
   cart[2] = z;

} /* mort2cart() */

/**************************************************************** 
* 
*  cart2mort - translate 3d cartesian coordinates to a morton
*   ordered sequence 
*
*/

int cart2mort( int *cart, int width ) {

   int i;
   int x,y,z;
   int mask;
   int mort;

   x = cart[0];
   y = cart[1];
   z = cart[2];

   mort = 0;
   mask = 0x1;
   y <<= 1;
   z <<= 2;
   for ( i=0; i<width; i++ ) {
      mort |= x & mask;
      mask <<= 1;
      mort |= y & mask;
      mask <<= 1;
      mort |= z & mask;
      mask <<= 1;
      x <<= 2;
      y <<= 2;
      z <<= 2;
   } /* for i */

   return ( mort );

} /* cart2mort() */


#ifdef ROWCOL

/****************************************************************
*
*  the following routines implement the translation between
*  row/column coordinates and  Morton encoding schemes. 
*  they should never be called directly by any external routines.
*
*/

/****************************************************************
*
*  rco2mort() - translate from row/col ordering to morton
*    ordering (aka. intereaved bits)
*
*    ie - zzzzyyyyxxxx -> zyxzyxzyxzyx
*
*/

int rco2mort( int rco, int width ) {

   int i;
   int x,y,z;
   int mask;
   int mort;

   mask = ( 0x1 << width ) - 1;
   x = rco & mask;
   rco >>= width;
   y = rco & mask;
   rco >>= width;
   z = rco & mask;

   mask = 0x1;
   mort = 0;

   y <<= 1;
   z <<= 2;
   for ( i=0; i<width; i++ ) {
      mort |= x & mask;
      mask <<= 1;
      mort |= y & mask;
      mask <<= 1;
      mort |= z & mask;
      mask <<= 1;
      x <<= 2;
      y <<= 2;
      z <<= 2;
   } /* for i */

   return ( mort );

} /* rco2mort() */


/****************************************************************
*
*  mort2rco() - maps morton ordered index ro row-colume
*
*    ie - zyxzyxzyxzyx -> zzzzyyyyxxxx
*
*/

int mort2rco( int mort, int width ) {

   int i;
   int x,y,z;
   int mask;
   int rco;

   x = 0;
   y = 0;
   z = 0;

   mask = 0x1;

   for ( i=0; i<width; i++ ) {
      x |= (mask & mort);
      mort >>= 1;
      y |= (mask & mort);
      mort >>= 1;
      z |= (mask & mort);
      mask <<= 1;
   } /* for i */

   mask = (0x1 << width) - 1;
   rco = z & mask;
   rco <<= width;
   rco |= y & mask;
   rco <<= width;
   rco |= x & mask;

   return (rco);

} /* mort2rco() */

#endif /* ROWCOL */


#ifdef SCURVE

/****************************************************************
*
*  the following routines implement the translation between
*  scurve coordinates and  Morton encoding schemes. 
*  they should never be called directly by any external routines.
*
*/

/****************************************************************
*
*  sco2mort() - translate from row/col ordering to morton
*    ordering (aka. intereaved bits)
*
*    ie - (zzzz)(yyyy)(xxxx) -> zyxzyxzyxzyx
*
*/

int sco2mort( int sco, int width ) {

   int i;
   int x,y,z;
   int mask;
   int mort;

   /* chop up index into [x' y' z'] */

   mask = ( 0x1 << width ) - 1;
   x = sco & mask;
   sco >>= width;
   y = sco & mask;
   sco >>= width;
   z = sco & mask;

   /* move coordinates back to cartesian space */

   if ( z%2 == 1 )
      y = mask - y;
   if ( y%2 == 1 )
      x = mask - x;

   /* convert cartesian to morton */

   mask = 0x1;
   mort = 0;

   y <<= 1;
   z <<= 2;
   for ( i=0; i<width; i++ ) {
      mort |= x & mask;
      mask <<= 1;
      mort |= y & mask;
      mask <<= 1;
      mort |= z & mask;
      mask <<= 1;
      x <<= 2;
      y <<= 2;
      z <<= 2;
   } /* for i */

   return ( mort );

} /* rco2mort() */


/****************************************************************
*
*  mort2sco() - maps morton ordered index to scurve ordered.
*
*    ie - zyxzyxzyxzyx -> (zzzz)(yyyy)(xxxx)
*
*/

int mort2sco( int mort, int width ) {

   int i;
   int x,y,z;
   int mask;
   int sco;

   x = 0;
   y = 0;
   z = 0;

   mask = 0x1;

   for ( i=0; i<width; i++ ) {
      x |= (mask & mort);
      mort >>= 1;
      y |= (mask & mort);
      mort >>= 1;
      z |= (mask & mort);
      mask <<= 1;
   } /* for i */

   /* at this point, x, y and z are cartesian */

   mask = (0x1 << width) - 1;

   if ( y%2 == 1 )
      x = mask - x;
   if ( z%2 == 1 )
      y = mask - y;

   sco = z & mask;
   sco <<= width;
   sco |= y & mask;
   sco <<= width;
   sco |= x & mask;

   return (sco);

} /* mort2sco() */

#endif /* SCURVE */
