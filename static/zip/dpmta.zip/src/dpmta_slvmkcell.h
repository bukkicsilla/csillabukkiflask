/* 
*  dpmta_slvmkcell.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_slvmkcell.h,v 3.1 1999/12/24 17:55:50 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_slvmkcell.h,v $
 * Revision 3.1  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.0  1999/04/01 16:45:30  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.3  1998/12/01 20:59:42  wrankin
 * enhanced dynamic allocation of cells
 * cleanup of code.
 *
 * Revision 2.2  1997/11/12 13:49:56  wrankin
 * updates to communications routines and general cleanup of code in prep
 *   for introducing load balancing functionality in hte near future
 *
 * Revision 2.1  1997/11/07 16:49:38  wrankin
 * massive cleanup of code.
 *  - ansi-fication and inclusion of prototypes
 *  - removed unused variables
 *  - all (except the test) code compiles with minimal warnings under gcc.
 *
 *
 */

#ifndef _DPMTA_SLVMKCELL_H_
#define _DPMTA_SLVMKCELL_H_

void Alloc_Cell_Table();
void Alloc_Cell_Index();
void Make_Cell_Local();
void Make_Cell_Ilist();
void Make_Cell_Index();
void Make_Cell_Centers();
void Delete_Cell_Table();
void Delete_Cell_Index();


#endif
