/*
*  dpmta_slvcomm -  routines to send and receive multipole information
*     between slaves, send and receive particle information between 
*     slaves and send and receive interaction and particle
*     information to and from the master process.
*
*  w. t. rankin
*
*  Copyright (c) 1994 Duke University
*  All rights reserved
*
*/

static char rcsid[] = "$Id: dpmta_slvcomm.c,v 3.5 2000/04/04 02:38:06 wrankin Exp $";


/* include files */
#include <stdlib.h>
#include <stdio.h>
#include "dpmta_config.h"        /* dpmta configuration */
#include "dpmta_cell.h"
#include "dpmta_slvglobals.h"

#include "comm.h"
#include "dpmta_message.h"

#ifdef TIMEPERF
#include "dpmta_timer.h"
#endif

/* external prototypes */

#include "dpmta_distmisc.h"
#include "dpmta_distpart.h"
#include "dpmta_slvscale.h"
#ifdef LOADBAL
#include "dpmta_distload.h"
#endif

/* gotta include this because of the return definitions */
#include "dpmta_slvcomm.h"



/*
 * some prototypes for functions internal to this module
 */

void Recv_Part1();
void Recv_Part2();
void Send_Master_Results();
void Send_Slave_Results();


/*
 * message terminator.
*/

static int         Msg_Term = -1;


/****************************************************************
*								 
*  Comm_Init() - Initialize local communications buffers and data
*
*/

void Comm_Init()
{

}

/****************************************************************
*								 
*  Comm_Delete() - free up local communications buffers
*
*/

void Comm_Delete()
{

}

/****************************************************************
*
*  Recv_Start_Iter() - receive messages at the start of a
*    processing iteration.
*
*  this procedure will receive messages from the master process and
*  will process the data appropriately.
*
*/

int Recv_Start_Iter()
{

   int rtn_flag = 0;
   int nrecv = 0;
   int msg_type;

   while ( nrecv < Dpmta_Nproc ) {

      /* receive a message
       * - make sure you receive only messages from 
       *   the master and not messages from another
       *   slave who has already made it to their
       *   particle redistribution phase.
       */

      comm_recv(0,-1,MSG_START);

      /* comm_dump_recv_buf(0); */

      comm_upkint(0,&(msg_type),1);

      /* determin what type of message it is */
      switch ( msg_type ) {

      case MSG_PART1:
	 Recv_Part1();
	 break;

      case MSG_PART2:
	 Recv_Part2();
	 rtn_flag = RECV_PART;
	 nrecv++;
	 break;

#ifdef BLUGGA  /* shouldn't need to do this */
#ifdef LOADBAL
      case MSG_LBAL3:
	 Recv_LoadBal_Index();
	 rtn_flag = RECV_LOADBAL;
	 nrecv = Dpmta_Nproc;
	 break;
#endif
#endif
	 
      case MSG_EXIT:
	 rtn_flag = RECV_EXIT;
	 nrecv++;
	 break;

      default:
	 fprintf(stderr,"Pid[%d]: Error: Unknown message type [%d]\n",
		 Dpmta_Pid, msg_type);
	 exit(-1);
	 break;

      } /* case */

   } /* while */

   return rtn_flag;

} /* Recv_Start_Iter() */


/****************************************************************
*
*  Recv_Part1() - receive particles from application
*
*  this procedure will receive the initial particle information
*  from the one or more calling processes and realloc the cell
*  table if needed.
*
*  the message format:
* 
*  MSG_PART1:
*    0)   int        - message type
*    1)   int        - cell resize flag
*    1.1) real[3][3] - length of cell edges (if needed)
*    1.1) real[3]    - position of cell center (if needed)
*    2)   int        - the number of cells
*    2.1) int        - the starting cell id
*    3)   int[]      - number of particles per cell
*
*
*/

void Recv_Part1()
{

   int i;                       /* loop counters */

   int num_cells;               /* number of cells in message */
   int cell_id;                 /* cell identifier */
   int index;                   /* cell identifier */
   int num_parts;               /* message particle number */
   int level;                   /* bottom level of tree */
   int src_proc;                /* processor id of sending proc */

   CellPtr cell_tmp;            /* temp cell table pointer */
   ParticlePtr part_tmp;        /* temporary pointer to list of particles */
   PartInfoPtr flist_tmp;       /* temporary pointer to force vector */
   int *idlist_tmp;             /* temporary pointer to id vector */
   int *pidlist_tmp;            /* temporary pointer to pid vector */


   level = Dpmta_NumLevels - 1;

   comm_upkint(0,&src_proc,1);

#ifdef BLUGGA
  /* ifndef EMBEDDED */
   /*
    * unpack the unit cell size and check if we need
    * to resize.  if we are an embedded application (MIMD),
    * then we do not need to pass this information.  we
    * do not need to perform the resize call until after
    * all the processors have replied.
    */

   comm_upkint(0,&(Dpmta_Resize),1);
   if ( Dpmta_Resize ) {
      comm_upkdbl(0,&(Dpmta_CellVector1.x),3);
      comm_upkdbl(0,&(Dpmta_CellVector2.x),3);
      comm_upkdbl(0,&(Dpmta_CellVector3.x),3);
      comm_upkdbl(0,&(Dpmta_CellCenter.x),3);

#ifdef PIPED
      Dpmta_CV1Mag = Vec_Mag(&Dpmta_CellVector1);
      Dpmta_CV2Mag = Vec_Mag(&Dpmta_CellVector2);
      Dpmta_CV3Mag = Vec_Mag(&Dpmta_CellVector3);
#endif
      Dpmta_MaxCellLen = Max_CellLength();
   }
#endif

   /*
    * unpack the cell size counters and determine if each
    * cell particle array is large enough to hold everything.
    */

   comm_upkint(0,&num_cells,1);
   comm_upkint(0,&index,1);

   for ( i=0; i<num_cells; i++ ) {

      /*
       *  check to see if we have allocated a cell here and bail out
       *  if we have not.  later, we should replace this with a call
       *  that will create a cell if one is needed.
       */

      /*
       * translate from a cell index (possibly hilbert or morton
       * ordering) to a cell_id (morton).
       */

      cell_id = index2cell(index,Dpmta_NumLevels-1);
	 
      cell_tmp = Dpmta_CellTbl[level][cell_id];

      if ( cell_tmp == NULL ) {
	 fprintf(stderr,"proc[%d] - cell[%d] not alloc\n",Dpmta_Pid,cell_id);
	 exit(-1);
      }
      if ( cell_tmp->mdata == NULL ) {
	 fprintf(stderr,"proc[%d] - cell[%d]->mdata not alloc\n",
		 Dpmta_Pid,cell_id);
	 exit(-1);
      }


      comm_upkint(0,&num_parts,1);

      /* keep track of old number of parts for indexing */
      num_parts += cell_tmp->n2;
      cell_tmp->n2 = num_parts;

      if ( num_parts > cell_tmp->psize ) {

	 part_tmp = cell_tmp->plist;
	 part_tmp = (ParticlePtr)realloc(part_tmp, (num_parts)*sizeof(Particle));
	 if ( part_tmp == NULL ) {
	    fprintf(stderr,"ERROR: Recv_Particles() - alloc failed\n");
	    exit(-1);
	 }
	 cell_tmp->plist = part_tmp;

	 idlist_tmp = cell_tmp->mdata->part_id;
	 idlist_tmp = (int *)realloc(idlist_tmp, (num_parts)*sizeof(int));
	 if ( idlist_tmp == NULL ) {
	    fprintf(stderr,"ERROR: Recv_Particles() - alloc failed\n");
	    exit(-1);
	 }
	 cell_tmp->mdata->part_id = idlist_tmp;

	 pidlist_tmp = cell_tmp->mdata->proc_id;
	 pidlist_tmp = (int *)realloc(pidlist_tmp, (num_parts)*sizeof(int));
	 if ( pidlist_tmp == NULL ) {
	    fprintf(stderr,"ERROR: Recv_Particles() - alloc failed\n");
	    exit(-1);
	 }
	 cell_tmp->mdata->proc_id = pidlist_tmp;

	 flist_tmp = cell_tmp->mdata->flist;
	 flist_tmp = (PartInfoPtr)realloc(flist_tmp,
					  (num_parts)*sizeof(PartInfo));
	 if ( flist_tmp == NULL ) {
	    fprintf(stderr,"ERROR: Recv_Particles() - alloc failed\n");
	    exit(-1);
	 }
	 cell_tmp->mdata->flist = flist_tmp;

#ifdef COMP_LJ
	 flist_tmp = cell_tmp->mdata->f_lj;
	 flist_tmp = (PartInfoPtr)realloc(flist_tmp,
					  (num_parts)*sizeof(PartInfo));
	 if ( flist_tmp == NULL ) {
	    fprintf(stderr,"ERROR: Recv_Particles() - alloc failed\n");
	    exit(-1);
	 }
	 cell_tmp->mdata->f_lj = flist_tmp;
#endif

	 cell_tmp->psize = num_parts;
      } /* if num_parts */

      /* access the next cell */
      index++;

   } /* for i */

} /* Recv_Part1() */



/****************************************************************
*
*  Recv_Part2() - receive particle data from application
*
*  this procedure will receive the particle information from the
*  one or more slave processes and load the values into its cell
*  table.
*
*  the message format:
* 
*  MSG_PART2:
*    0)   int        - procnum
*    1)   int        - cell id for first cell
*    2)   int        - particle id
*    3)   real[]     - array of particle data
*    4+)  misc       - repeat 1-3 for each particle
*    n)   int        - message terminator
*
*/

void Recv_Part2()
{
   int i,j;                     /* loop counters */

   int cell_id;                 /* cell identifier */
   int sindex, eindex;          /* starting cell identifier */
   int num_parts;               /* message particle number */
   int src_proc;                /* processor id of sending proc */
   int level;                   /* bottom level of tree */

   CellPtr cell_tmp;            /* temp cell table pointer */
   PartInfoPtr flist_tmp;       /* temporary pointer to force vector */
   int *idlist_tmp;             /* temporary pointer to id vector */
   int *pidlist_tmp;            /* temporary pointer to pid vector */
   double *dbl_tmp;             /* temp pointer to particle data */


   level = Dpmta_NumLevels - 1;

   comm_upkint(0,&src_proc,1);

   /*
    * now unpack eack particle one at a time
    * into the appropriate cell
    */

   comm_upkint(0,&cell_id,1);

   while ( cell_id != Msg_Term ) {

      cell_tmp = Dpmta_CellTbl[level][cell_id];

      num_parts = cell_tmp->n;

      dbl_tmp = &(cell_tmp->plist[num_parts].p.x);
      idlist_tmp = &(cell_tmp->mdata->part_id[num_parts]);
      pidlist_tmp = &(cell_tmp->mdata->proc_id[num_parts]);

      /* unpack data into arrays */
      comm_upkint(0,idlist_tmp,1);
      *pidlist_tmp = src_proc;
#ifdef COMP_LJ
      comm_upkdbl(0,dbl_tmp,6);
#else
      comm_upkdbl(0,dbl_tmp,4);
#endif

      cell_tmp->n += 1;

      comm_upkint(0,&cell_id,1);

   } /* while cell_id */

   
   /*
    *  now that we have reached the end of the receive loop
    *  we need to initialize the various data arrays and
    *  set the cell size if we did a resize
    */

   sindex = Dpmta_Sindex[level];
   eindex = Dpmta_Eindex[level];

   for ( i=sindex; i<=eindex; i++ ) {

      /*
       * translate from a hilbert index to a cell_id
       */

      cell_id = index2cell(i,level);
      
      cell_tmp = Dpmta_CellTbl[level][cell_id];

      num_parts = cell_tmp->n;

      /* zero out force array */
      flist_tmp = cell_tmp->mdata->flist;
      for ( j=0; j<num_parts; j++ ) {
	 flist_tmp->f.x = 0.0;
	 flist_tmp->f.y = 0.0;
	 flist_tmp->f.z = 0.0;
	 flist_tmp->v = 0.0;
	 flist_tmp++;
      } /* for j */

#ifdef COMP_LJ
      flist_tmp = cell_tmp->mdata->f_lj;
      for ( j=0; j<num_parts; j++ ) {
	 flist_tmp->f.x = 0.0;
	 flist_tmp->f.y = 0.0;
	 flist_tmp->f.z = 0.0;
	 flist_tmp->v = 0.0;
	 flist_tmp++;
      } /* for j */
#endif

   } /* for i */

} /* Recv_Part2() */



/****************************************************************
*
*  Send_Results() - send complete results to original source.
*
*  message format:
*     0) real[]  - virial data (if needed)
*     1) int     - particle id number
*     2) real[]  - array of force data for particle
*     3+) repeat 1-2 for each cell
*     n) int     - message terminator
*
*/

void Send_Results()
{

   int i,j;
   int id;
   int proc_num;
   int level;

   /*
    *  create the message buffers.
    */

   for (i=0; i<Dpmta_Nproc; i++ ) {
      comm_newmsg(i);
   }


   /* pack the header information */
   
#if defined VIRIAL || defined OLDVIRIAL
   for ( i=0; i<Dpmta_Nproc; i++ ) {

      comm_pkdbl(i,&Dpmta_Vpot,1);
      comm_pkdbl(i,(double *)(&Dpmta_Vf),3);
#ifdef COMP_LJ
      comm_pkdbl(i,&Dpmta_Vpot_LJ,1);
      comm_pkdbl(i,(double *)(&Dpmta_Vf_LJ),3);
#endif
   } /* for i */
#endif
   
   level = Dpmta_NumLevels - 1;
   
   for ( i=Dpmta_Sindex[level]; i<=Dpmta_Eindex[level]; i++ ) {
      id = index2cell(i,level);
      for ( j=0; j<(Dpmta_CellTbl[level][id]->n); j++ ) {
	 proc_num = Dpmta_CellTbl[level][id]->mdata->proc_id[j];
	 comm_pkint(proc_num,&(Dpmta_CellTbl[level][id]->mdata->part_id[j]),1);
	 comm_pkdbl(proc_num,&(Dpmta_CellTbl[level][id]->mdata->flist[j].f.x),4);
#ifdef COMP_LJ
	 comm_pkdbl(proc_num,&(Dpmta_CellTbl[level][id]->mdata->f_lj[j].f.x),4);
#endif
      }  /* for j */
   } /* for i */

   /* terminate and send messages */

   for ( i=0; i<Dpmta_Nproc; i++ ) {
      comm_pkint(i,&(Msg_Term),1);
      comm_send(i,i,MSG_RESLT);
   } /* for i */

} /* Send_Results() */




/****************************************************************
*
*  Send_Mpe_to_Parent(level) - Send MPE to Pid
* 
*  sends the all mpe for this level to the pids that own them.
*
*   
*/

void Send_Mpe_to_Parent( int level )
{
   int i,j,k,l;
   int id;
   int tpid;
   int bufnum;
   int *id_ptr;
   int *v_ptr;
   double *mpe_ptr;

   CellPtr cell_ptr;
   
   /* we do not need to send MPEs too far up the tree */
   if ( level < Dpmta_DownPassStart ) {
      return;
   }

   for ( i=0; i<Dpmta_Power8[level-1]; i++ ) {
      if ( (i<Dpmta_Sindex[level-1]) || (i>Dpmta_Eindex[level-1]) ) {
	 id = index2cell(i,level-1);	    
	 j = getfirstchild(id);

	 for ( k=j; k<j+8; k++ ) {
	    l = getslvpid(level,k);
	    if ( l == Dpmta_Pid ) {
	       tpid = getslvpid_indx(level-1,i);
	       bufnum = Dpmta_Nproc + tpid;

	       comm_newmsg(bufnum);

	       /* compute old-fashioned cellid */
	       cell_ptr = Dpmta_CellTbl[level-1][id];
	       id_ptr = &(cell_ptr->id);
	       comm_pkint(bufnum,id_ptr,1);
	       v_ptr = &(cell_ptr->mvalid);
	       comm_pkint(bufnum,v_ptr,1);

	       if ( (*v_ptr) == TRUE ) {

		  mpe_ptr = &(cell_ptr->m[0][0].x);
		  comm_pkdbl(bufnum,mpe_ptr,Dpmta_MpeSize*2);

#ifdef COMP_LJ
		  mpe_ptr = &(cell_ptr->m_lj[0][0][0].x);
		  comm_pkdbl(bufnum,mpe_ptr,Dpmta_MpeSize_LJ*2);
#endif
	       } /* if v_ptr */
	       
	       comm_send(bufnum,tpid, MSG_M2P);

	       /* bail out of for loop */
	       k = j + 8;

	    } /* if l */
	 } /* for k */
      } /* if i */
   } /* for i */

} /* Send_Mpe_to_Parent */


/****************************************************************
*
*  Receive MPE from Child
* 
*  pid with parental responsibilities receives partial shifted
*  mpe from another processor(s) and adds it to the current mpe.
*  Same setup as send MPE.
*/

void Recv_Mpe_from_Child( int level )
{
   int i;
   int cellid_tmp;
   int valid;
   int bufnum;
   double *mpe_temp;

   for (i=0; i<Dpmta_RMcell[level]; i++) {

      /*
      *  receive a message and place the mpe in temporary (global)
      *  storage.  then add the mpe data to the specified cell's mpe.
      */
      bufnum = Dpmta_Nproc + i ;

      comm_recv(bufnum,-1, MSG_M2P);
      comm_upkint(bufnum,&cellid_tmp,1);
      comm_upkint(bufnum,&valid,1);

      if ( valid == TRUE ) {
	 mpe_temp = &(Dpmta_Temp_Mpe[0][0].x);
	 comm_upkdbl(bufnum,mpe_temp,Dpmta_MpeSize*2);

#ifdef COMP_LJ
	 mpe_temp = &(Dpmta_Temp_Mpe_LJ[0][0][0].x);
	 comm_upkdbl(bufnum,mpe_temp,Dpmta_MpeSize_LJ*2);
#endif

	 /*
	  *  add child multipole into existing parent
	  */

	 if (Dpmta_FFT)
	    CMsumF(Dpmta_Temp_Mpe,Dpmta_CellTbl[0][cellid_tmp]->m,
		   Dpmta_Mp);
	 else
	    CMsum(Dpmta_Temp_Mpe,Dpmta_CellTbl[0][cellid_tmp]->m,Dpmta_Mp);

#ifdef COMP_LJ
	 LJMsum(Dpmta_Temp_Mpe_LJ,Dpmta_CellTbl[0][cellid_tmp]->m_lj,
		Dpmta_Mp_LJ);
#endif
      } /* if valid */

      Dpmta_CellTbl[0][cellid_tmp]->mvalid = valid;


   } /* for i */
} /* Recv_Mpe_from_Child */

    
/****************************************************************
*
*  Send_Lcl_to_Child - Send Local Expansion of Parent to all children
*  
*  Pid without parental responsibilities receives local expansion.
*  (Child will shift the expansion).
*
*  so, in any case, all we have to do is to send the local expansion
*  from a single cell down to each of this slaves children
*
*  note also that we do not use a broadcast for messages to multiple 
*  cells, which we should probably do.
*/

void Send_Lcl_to_Child( int level )
{
   int i, j, k;
   int id;
   int tpid[8];
   int ccell;
   int send_flag;
   int bufnum;
   int *v_ptr;
   int *id_ptr;
   double *lcl_ptr;

   CellPtr cell_ptr;


   /* kind of a needless check, but just for the halibut */

   if (( Dpmta_Sindex[level] != -1 ) && ( level < Dpmta_NumLevels-1 )) {
      for ( i=Dpmta_Sindex[level]; i<=Dpmta_Eindex[level]; i++ ) {

	 id = index2cell(i,level);

	 cell_ptr = Dpmta_CellTbl[level][id];
	 
         /*
         *  for each slave, send a message containing the local expansion
         */

         ccell = getfirstchild(id);

         for ( j=0; j<8; j++ ) {
	    tpid[j] = getslvpid(level+1,ccell+j);

            if ( tpid[j] != Dpmta_Pid ) {

	       /* check to see if we have already sent this? */
	       send_flag = TRUE;
	       for ( k=0; k<j; k++ ) {
		  if ( tpid[j] == tpid[k] ) {
		     send_flag = FALSE;
		     k = j;
		  }
	       }

	       if ( send_flag == TRUE ) {
 	  	  bufnum = Dpmta_Nproc + tpid[j];
		  comm_newmsg(bufnum);

		  id_ptr = &(cell_ptr->id);
		  comm_pkint(bufnum,id_ptr,1);

		  v_ptr = &(cell_ptr->mdata->lvalid);
		  comm_pkint(bufnum,v_ptr,1);

		  if ( (*v_ptr) == TRUE ) {

		     lcl_ptr = &(cell_ptr->mdata->l[0][0].x);
		     comm_pkdbl(bufnum,lcl_ptr,Dpmta_LclSize*2);

#ifdef COMP_LJ
		     lcl_ptr = &(cell_ptr->mdata->l_lj[0][0][0].x);
		     comm_pkdbl(bufnum,lcl_ptr,Dpmta_LclSize_LJ*2);
#endif
		  } /* if v_ptr */

		  comm_send(bufnum,tpid[j],MSG_L2C);

	       } /* if k */
	    } /* if dpmta_pid */
         } /* for j */
      } /* for i */
   } /* in Dpmta_Sindex */

} /* Send_Lcl_to_Child */
    

/****************************************************************
* 
*  Rcv_Lcl_from_Parent - Receive local expansion(s) from parent(s)
* 
*  Pid with parental responsibilities sends local expansion of parent
*  to pids holding children.  The number of local expansion that we
*  will receive has been precomputed and stored in Dpmta_RLcell[].
*
*  Note that the local expansion that we are receiving is complete
*  with all M2L's already included.  Therefor we can just overwrite
*  the existing local expansion in the cell.
*
*/

void Recv_Lcl_from_Parent( int level )
{
   int i;
   int cell_id;
   int bufnum;
   int *v_ptr;
   double *lcl_ptr;

   for ( i=0; i<Dpmta_RLcell[level]; i++ ) {
      bufnum = Dpmta_Nproc + i;
      comm_recv(bufnum,-1,MSG_L2C);
      comm_upkint(bufnum,&cell_id,1);

      v_ptr = &(Dpmta_CellTbl[0][cell_id]->mdata->lvalid);
      comm_upkint(bufnum,v_ptr,1);

      if ( (*v_ptr) == TRUE ) {

	 lcl_ptr = &(Dpmta_CellTbl[0][cell_id]->mdata->l[0][0].x);
	 comm_upkdbl(bufnum,lcl_ptr,Dpmta_LclSize*2);

#ifdef COMP_LJ
	 lcl_ptr = &(Dpmta_CellTbl[0][cell_id]->mdata->l_lj[0][0][0].x);
	 comm_upkdbl(bufnum,lcl_ptr,Dpmta_LclSize_LJ*2);
#endif
      } /* if v_ptr */
   } /* for i */
} /* Recv_Lcl_from_Parent */


/****************************************************************
*
*  this procedure will receive the particle information from the
*  other DPMTA slave processes and load the values into it's cell
*  table.  these particles will be used to compute the single direct
*  particle interactions.
*
*  the slave will (re)allocate additional space for the particle list
*  if it is needed and update the contents of the slaves cell table.
*
*  the message format:
*    1) int - number of cells
*    2) int - cell id for first cell
*    3) int - number of particles in cell
*    4) int[] - array of particle data for cell
*   5+) repeat 2-4 for each cell
*
*/

void Slave_Recv_SDirect()
{

   int i;                       /* loop counters */

   int cell_id;                 /* cell identifier */
   int num_parts;               /* message particle number */

   ParticlePtr part_tmp;        /* temporary pointer to list of particles */


   for (i=1; i<Dpmta_Nproc; i++) {
      comm_recv(0,-1, MSG_PDIST);

      comm_upkint(0,&cell_id,1);

      while ( cell_id != Msg_Term ) {

         /*
         *  check to see if we have allocated a cell here and bail out
         *  if we have not.  later, we should replace this with a call
         *  that will create a cell if one is needed.
         */

         if (Dpmta_CellTbl[0][cell_id] == NULL ) {
            fprintf(stderr,"Error: Slave_Recv_Part() - cell %d not alloc\n",
               cell_id);
            exit(-1);
	 }

         /*
         *  here is where we need to check psize against the number 
         *  of particles in the list and realloc is it is not large
         *  enough.  since we are receiving all of out particles from
         *  a single source (the slave that owns this cell) we don't
         *  have to worry about preserving any existing data.
         */

         comm_upkint(0,&num_parts,1);
         Dpmta_CellTbl[0][cell_id]->n = num_parts;

         if ( num_parts > Dpmta_CellTbl[0][cell_id]->psize ) {
            part_tmp = Dpmta_CellTbl[0][cell_id]->plist;
            part_tmp = (ParticlePtr)realloc(part_tmp,
                          num_parts*sizeof(Particle));
            Dpmta_CellTbl[0][cell_id]->plist = part_tmp;
            Dpmta_CellTbl[0][cell_id]->psize = num_parts;
	 }

         if ( num_parts > 0 ) {
            part_tmp = &(Dpmta_CellTbl[0][cell_id]->plist[0]);
#ifdef COMP_LJ
            comm_upkdbl(0,(double *)part_tmp,num_parts*6);
#else
            comm_upkdbl(0,(double *)part_tmp,num_parts*4);
#endif
	 }

	 /* grab next cell */
	 comm_upkint(0,&cell_id,1);

      } /* while cell_id */
   } /* for i */

} /* Slave_Recv_Sdirect */



/****************************************************************
*
*  Slave_Send_SDirect() -
*
*  this procedure will cycle through the other processors and
*  pack/send a message to each one that contains the particle 
*  lists needed by the target processor, as defined in the inverse 
*  interaction list.
*
*  message format:
*
*    1) int - number of cells
*    2) int - cell id of first cell
*    3) int - number of particles in first cell
*    4) particle[] - array of particle data, size determined from (2)
*   5+) repeat (2-4) for each cell in (1)
*
*/

void Slave_Send_SDirect()
{

   int i, j;                    /* loop counters, what else? */
   int cell_id;                 /* temp var used to hold cell id */
   int num_cells;               /* temp ver to hold number of cells */
   int num_parts;               /* temp ver to hold particle number */
   int proc_id;                 /* id of where to send message */

   CellPtr cell_ptr;            /* temp cell pointer */
   

   for (i=1; i<Dpmta_Nproc; i++) {
      proc_id = ( Dpmta_Pid + i ) % Dpmta_Nproc;

      comm_newmsg(proc_id);

      num_cells = Dpmta_IIlist.dlen[proc_id];

      /* cycle through each cell for that processor */
      for (j=0; j<num_cells; j++) {

         cell_id = Dpmta_IIlist.dlist[proc_id][j];
	 cell_ptr =  Dpmta_CellTbl[0][cell_id];         
         num_parts = cell_ptr->n;         

         if ( num_parts > 0 ) {
	    comm_pkint(proc_id,&(cell_ptr->id),1);
	    comm_pkint(proc_id,&(cell_ptr->n),1);

#ifdef COMP_LJ
            comm_pkdbl(proc_id,(double *)(cell_ptr->plist),num_parts*6);
#else
	    comm_pkdbl(proc_id,(double *)(cell_ptr->plist),num_parts*4);
#endif
         }

      } /* for j */

      /* terminate message */
      comm_pkint(proc_id,&(Msg_Term),1);

      comm_send(proc_id,proc_id,MSG_PDIST);

   } /* for i */

} /* Slave_Send_SDirect */


/****************************************************************
*
*  Receive MPE Interaction List
*  Receive contents of mpe interaction list from all children
*
*  message format
*
*    1) int      - cell id of first cell
*    2) double[] - array of mpe data, size determined from (2)
*   3+) repeat (1-2) for each cell
*    4) int      - message termination flag
*
*/

void Slave_Recv_Multipole()
{

   int    i;                 /* loop counters */
   int    cell_id;           /* cell id index */
   double *mpe_ptr;          /* pointer to mpe data block */


   for ( i=1; i<Dpmta_Nproc; i++ ) {

      comm_recv(0, -1, MSG_MDIST);

      comm_upkint(0,&cell_id,1);

      while ( cell_id != Msg_Term ) {

         /*
         *  check to see if we have allocated a cell here and bail out
         *  if we have not.  later, we should replace this with a call
         *  that will create a cell if one is needed.
         */

         if (Dpmta_CellTbl[0][cell_id] == NULL ) {
            fprintf(stderr,"Error: Slave_Recv_Mpole() - cell %d not alloc\n",
               cell_id);
            exit(-1);
	 }

	 mpe_ptr = &(Dpmta_CellTbl[0][cell_id]->m[0][0].x);
	 comm_upkdbl(0,mpe_ptr,Dpmta_MpeSize*2);

#ifdef COMP_LJ
	 mpe_ptr = &(Dpmta_CellTbl[0][cell_id]->m_lj[0][0][0].x);
	 comm_upkdbl(0,mpe_ptr,Dpmta_MpeSize_LJ*2);
#endif

         Dpmta_CellTbl[0][cell_id]->mvalid = TRUE;

	 comm_upkint(0,&cell_id,1);

      } /* while cell_id */

   } /* for i */

} /* Slave_Recv_Multipole */


/****************************************************************
*
*  Send MPE Inverse Interaction List
* 
*  Send contents of mpe inverse interaction list to all other
*  processes. 
*
*  message format:
*
*    1) int      - cell id of first cell
*    2) double[] - array of mpe data, size determined from (2)
*   3+) repeat (1-2) for each cell
*    4) int      - message termination flag
*
*  note that since the Complex data type is twice the size of
*  a double, we are packing MpeSize*2 doubles in each message.
*
*  also, we only send the multipoles marked valid.
*  it is assumesd that the receiving processor will have 
*  marked all mpoles as invalid (as default) prior to this phase.
*
*/
 
void Slave_Send_Multipole()
{
   int rproc;             /* remote slave counter */
   int i, j;              /* loop counters */
   int cell_id;           /* cell id index */
   int num_cells;         /* number of cells in iilist */
   int valid;             /* valid multipole flag */

   CellPtr cell_ptr;      /* temp cell pointer */
   
   
   for (j=1; j<Dpmta_Nproc; j++) {
      rproc = ( Dpmta_Pid + j ) % Dpmta_Nproc;

      comm_newmsg(rproc);

      num_cells = Dpmta_IIlist.mlen[rproc];

      for ( i=0; i<num_cells; i++ ) {

         cell_id = Dpmta_IIlist.mlist[rproc][i];
	 cell_ptr = Dpmta_CellTbl[0][cell_id];
	 
	 valid = cell_ptr->mvalid;

	 if ( valid == TRUE ) {
	    comm_pkint(rproc,&(cell_ptr->id),1);
	    comm_pkdbl(rproc,&(cell_ptr->m[0][0].x),Dpmta_MpeSize*2);
#ifdef COMP_LJ
	    comm_pkdbl(rproc,&(cell_ptr->m_lj[0][0][0].x),Dpmta_MpeSize_LJ*2);
#endif
	 } /* valid */

      } /* for i */

      /* terminate and send message */
      comm_pkint(rproc,&(Msg_Term),1);

      comm_send(rproc, rproc, MSG_MDIST);

   } /* for rproc */
} /* Slave_Send_Multipole() */


