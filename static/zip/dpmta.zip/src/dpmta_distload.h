/* 
*  dpmta_distload.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1999 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_distload.h,v 3.3 1999/12/24 17:55:50 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_distload.h,v $
 * Revision 3.3  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.2  1999/05/17 19:03:10  wrankin
 * Added support for Load Balancing
 *
 * Revision 3.1  1999/04/01 17:26:09  wrankin
 * introducing load balancing code
 *
 *
 */

#ifndef _DPMTA_DISTLOAD_H_
#define _DPMTA_DISTLOAD_H_

/*
 * dpmta_distload.c
 */

void Init_LoadBal( int, int, int, int, double );
void Clear_LoadBal();
void Start_LoadBal();
void Pause_LoadBal();
void Resume_LoadBal();
void Stop_LoadBal();
void Recv_LoadBal();
void Send_LoadBal();
void Delete_LoadBal();


#endif
