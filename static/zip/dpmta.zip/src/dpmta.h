/*
*  dpmta.h - include file for DPMTA data structures and prototype
*    declarations
*
*  w. t. rankin
*
*  Copyright (c) 1994 Duke University
*  All rights reserved
*
*/


#ifndef _DPMTA_H_
#define _DPMTA_H_

/* in case we're interfacing with C++ */
#ifdef __cplusplus
extern "C" {
#endif


typedef struct pmtavector {
   double x;
   double y;
   double z;
   }  PmtaVector;

/*
*  this is the minimum amount of data required to describe a particle
*  if the LJ processing has not been compiled into DPMTA, then the
*  alpha and beta parameters may be left unset.
*/

typedef struct pmtaparticle {
   PmtaVector p;               /* particle position */
   double q;                   /* particle charge */
   double a,b;                 /* alpha and beta paramenters for LJ */
   } PmtaParticle;

typedef PmtaParticle *PmtaParticlePtr;


/*
*  this structure holds the force and potential energy results
*/

typedef struct pmtapartinfo {
   PmtaVector f;               /* force vector */
   double v;                   /* potential */
   } PmtaPartInfo;

typedef PmtaPartInfo *PmtaPartInfoPtr;


/*
*  this structure holds the execution/setup parameters
*/

typedef struct pmtainitdata {
   int nprocs;
   int nlevels;
   int mp;
   int mp_lj;
   int mp_vir;
   int fft;
   int fftblock;
   int pbc;
   int kterm;
   double theta;
   PmtaVector v1;
   PmtaVector v2;
   PmtaVector v3;
   PmtaVector cellctr;
   int calling_num;
   int *calling_tids;
   int loadstep;
   double loadweight;
} PmtaInitData;

typedef PmtaInitData *PmtaInitDataPtr;


/*
*  prototypes for interface routines
*/

int PMTAinit( PmtaInitDataPtr, int );

int PMTAregister();

int PMTAforce( int, PmtaParticlePtr, PmtaPartInfoPtr, PmtaPartInfoPtr );

int PMTAresize( PmtaVector *, PmtaVector *, PmtaVector* , PmtaVector* );

int PMTAvirial( double*, PmtaVector*, double*, PmtaVector* );

int PMTAexit();

#ifdef __cplusplus
}
#endif

#endif
