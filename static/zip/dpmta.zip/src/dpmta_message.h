/****************************************************************
*
*  dpmta_message.h - include file for parallel FMA declarations
*
*  Copyright (c) 1998 Duke University
*  All rights reserved
*
*/

/* $Id: dpmta_message.h,v 3.2 2000/04/04 02:38:06 wrankin Exp $
 *
 * revision history:
 *
 * $Log: dpmta_message.h,v $
 * Revision 3.2  2000/04/04 02:38:06  wrankin
 * updates to support generic communication library
 *   - all message buffering done by application
 *   - support for eventual MPI implementation
 *
 * Revision 3.1  1999/05/17 19:03:11  wrankin
 * Added support for Load Balancing
 *
 * Revision 3.0  1999/04/01 16:45:07  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.5  1998/11/10 20:20:01  wrankin
 * fixed message passing for MIMD case.
 *
 * Revision 2.4  1998/11/06 19:45:10  wrankin
 * fixed bad message distribution design for initial particle lists.
 *
 * Revision 2.3  1998/09/21 20:45:24  wrankin
 *   - implemented a gravitational option (like charges attract)
 *   - cleaned up more message passing and added a flag to check
 *     between the use of PVM 3.3 vs. PVM 3.4
 *   - src/dpmta_pvm.h has been replaced by dpmta_message.h and
 *     initial efforts have been made towards an MPI port.
 *   - most static array references have been replaced by dynamic
 *     allocation for portability.  no more hard coded array limits.
 *
 * Revision 2.2  1998/09/09 15:29:56  wrankin
 * improved message passing format
 * fixed timing allocation
 * added some more allocation checks
 * fixed serial compilation problems
 * removed old dpmta-pvm.h file for directory
 * CVS:----------------------------------------------------------------------
 *
 * Revision 2.1  1998/08/17 18:59:08  wrankin
 * added flags for specification of PVM/MPI libraries
 * renamed dpmta_pvm.h to dpmta_message.h and moved "pvm.h" ref
 * removed static array references and added mallocs.
 *
 *
 * Originally derived from dpmta_pvm.h version 2.11
 *
 */

#ifndef _DPMTA_MESSSAGE_H_
#define _DPMTA_MESSSAGE_H_


/* defines *****************/

/*
*  define message IDs 
*
*  all messages will be in the range 0x1000-0x10ff and
*  the calling application should not use these message id's
*  when running under PVM.
*
*/

#define MSG_INIT1 0x1001     /* dec: 4097 */
#define MSG_INIT2 0x1002     /* dec: 4098 */
#define MSG_INTR1 0x1011     /* dec: 4113 */
#define MSG_INTR2 0x1012     /* dec: 4114 */
#define MSG_INTR3 0x1013     /* dec: 4115 */
#define MSG_INTR4 0x1014     /* dec: 4116 */
#define MSG_START 0x1020     /* dec: 4128 */
#define MSG_PART1 0x1021     /* dec: 4129 */
#define MSG_PART2 0x1022     /* dec: 4130 */
#define MSG_LBAL1 0x1023     /* dec: 4131 */
#define MSG_LBAL2 0x1024     /* dec: 4132 */
#define MSG_LBAL3 0x1025     /* dec: 4133 */
#define MSG_PDIST 0x1031     /* dec: 4145 */
#define MSG_MDIST 0x1032     /* dec: 4146 */
#define MSG_MACRO 0x1033     /* dec: 4147 */
#define MSG_M2P   0x1041     /* dec: 4161 */
#define MSG_M2C   0x1042     /* dec: 4162 */
#define MSG_L2P   0x1043     /* dec: 4163 */
#define MSG_L2C   0x1044     /* dec: 4164 */
#define MSG_RESLT 0x1051     /* dec: 4177 */
#define MSG_TIME1 0x1061     /* dec: 4193 */
#define MSG_TIME2 0x1062     /* dec: 4194 */
#define MSG_EXIT  0x1071     /* dec: 4209 */

#endif
