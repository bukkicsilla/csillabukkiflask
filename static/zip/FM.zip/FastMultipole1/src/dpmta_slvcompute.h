/* 
*  dpmta_compute.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_slvcompute.h,v 3.2 1999/12/24 17:55:50 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_slvcompute.h,v $
 * Revision 3.2  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.1  1999/05/17 19:03:15  wrankin
 * Added support for Load Balancing
 *
 * Revision 3.0  1999/04/01 16:45:20  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.2  1998/03/10 22:22:04  wrankin
 * folded start/cleanup functionality into dpmta_slvcompute
 *
 * Revision 2.1  1997/11/07 16:49:25  wrankin
 * massive cleanup of code.
 *  - ansi-fication and inclusion of prototypes
 *  - removed unused variables
 *  - all (except the test) code compiles with minimal warnings under gcc.
 *
 *
 */

#ifndef _DPMTA_SLVCOMPUTE_H_
#define _DPMTA_SLVCOMPUTE_H_

void Slave_Init();
void Slave_Start();
void Slave_Repartition();
void Slave_Compute();
void Slave_Cleanup();
void Slave_Delete();


#endif
