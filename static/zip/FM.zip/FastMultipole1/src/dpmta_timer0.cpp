
#include "stdafx.h"

#using <mscorlib.dll>
#include <tchar.h>
using namespace System;

/*
*  dpmta_timer.c - procedures to collect and report timing information
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*/

static char rcsid[] = "$Id: dpmta_timer.c,v 3.4 2000/04/04 02:38:06 wrankin Exp $";

/*
 * Revision history:
 *
 * $Log: dpmta_timer.c,v $
 * Revision 3.4  2000/04/04 02:38:06  wrankin
 * updates to support generic communication library
 *   - all message buffering done by application
 *   - support for eventual MPI implementation
 *
 * Revision 3.3  1999/12/24 18:03:44  wrankin
 * all compile time directives are now contained in the dpmta_config.h
 *   header file instead of being passed via make.
 *
 * Revision 3.2  1999/06/04 17:45:11  wrankin
 * updates to support Win32 compilation
 *
 * Revision 3.1  1999/05/17 19:56:49  wrankin
 * additional cleanup for load balancing
 *
 * Revision 3.0  1999/04/01 16:45:41  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.15  1999/03/18 21:23:13  wrankin
 * clean up timing code.
 * added timing synchronization
 *
 * Revision 2.14  1999/01/11 21:48:24  wrankin
 * fixed MIMD processing error.
 * fixed SERIAL processing error.
 * general cleanup of initialization processing.
 *
 * Revision 2.13  1998/11/25 15:56:01  wrankin
 * added include files to declare malloc types
 *
 * Revision 2.12  1998/09/09 15:30:09  wrankin
 * improved message passing format
 * fixed timing allocation
 * added some more allocation checks
 * fixed serial compilation problems
 * removed old dpmta-pvm.h file for directory
 * CVS:----------------------------------------------------------------------
 *
 * Revision 2.11  1998/08/17 18:59:43  wrankin
 * added flags for specification of PVM/MPI libraries
 * renamed dpmta_pvm.h to dpmta_message.h and moved "pvm.h" ref
 * removed static array references and added mallocs.
 *
 * Revision 2.10  1998/08/04 15:20:32  wrankin
 * cleaned up timing code.
 *
 * Revision 2.9  1998/07/16 20:00:38  wrankin
 * cleaned up makefile and removed indents on preprocessor directives
 *
 * Revision 2.8  1998/07/15 21:11:09  wrankin
 * large overhaul to the timing code
 *
 * Revision 2.7  1998/01/05 13:42:01  wrankin
 * added more timing code.
 *
 * Revision 2.6  1997/11/07 16:54:25  wrankin
 * massive cleanup of code.
 *  - ansi-fication and inclusion of prototypes
 *  - removed unused variables
 *  - all (except the test) code compiles with minimal warnings under gcc.
 *
 * Revision 2.5  1997/04/10 17:26:15  wrankin
 * improved particle sorting algorithm from serial runs.
 * removed extraneous timing code frm within sort proc.
 *
 * Revision 2.4  1997/03/26  20:29:56  wrankin
 * cleaned up timing code outputs
 *
 * Revision 2.3  1997/03/12  20:15:18  wrankin
 * updates to timer codes
 *
 * Revision 2.2  1997/03/04  19:18:18  wrankin
 * updates to timing codes
 *
 * Revision 2.1  1997/02/26  20:43:34  wrankin
 * updated timing measurements and placed routines in single module
 *
 *
*/

/* include files */

#include <stdlib.h>
#include <stdio.h>

#if defined LINUX
#include <unistd.h>
#include <sys/times.h>
#include <sys/time.h>
#endif

#if defined WIN32 
#include <time.h>
#endif


#ifndef CLK_TCK
#define CLK_TCK 60
#endif


/* local includes */
#include "dpmta_config.h"        /* dpmta configuration */
#include "dpmta_timer.h"

#ifndef SERIAL
#include "../comm/comm.h"

#include "dpmta_message.h"
#endif

/*
 * this whole module is wrapped with an ifdef so it won't
 * get compiled in if we dont want timings.
 *
 */

#ifdef TIMEPERF

/*
*  some timing and profiling storage, if needed
*/

static int    mypid;                    /* pid of process (0=master) */
static int    nprocs;                   /* total number of processors */


#ifndef WIN32
static struct tms startbuf;             /* used for CPU timing */
#endif
static double cpucurr;                  /* holds curr timing */
static double myclkticks;               /* holds CLK_TCK setting */

static  timeval runstruct;        /* used in elapse timing */

static double **timings = NULL;         /* all processors timing data */
static double *times_arr = NULL;        /* timings for local processors */

//using namespace comm;

/****************************************************************
 *
 * Init_Times() - initialize timing timing data structures
 *
 *   parameters:
 *     int ms - master/slave flag 0=master, 1+=slave;
 *
 */

void Init_Times( int mp, int np )
{
   int i;

   mypid = mp;
   nprocs = np;

#if defined WIN32 
     myclkticks = (double)CLOCKS_PER_SEC;

   /* get clock ticks setting */
#else
     myclkticks = (double)sysconf(_SC_CLK_TCK);

  
#endif  
  

   times_arr = (double *)malloc(TIME_DATA_SZ*sizeof(double));
   if ( times_arr == (double *)NULL ) {
      fprintf(stderr,"Error: malloc failed fr timing arrays\n");
      exit(-1);
   }

   if ( mypid == 0 ) {
      timings = (double **)malloc(nprocs*sizeof(double *));
      if ( timings == (double **)NULL ) {
	 fprintf(stderr,"Error: malloc failed for timing arrays\n");
	 exit(-1);
      }
      for ( i=0; i<nprocs; i++ ) {
	 timings[i] = (double *)malloc(TIME_DATA_SZ*sizeof(double));
	 if ( timings[i] == (double *)NULL ) {
	    fprintf(stderr,"Error: malloc failed for timing arrays\n");
	    exit(-1);
	 }
      } /* for i */
   } /* if mypid */

} /* Init_Times() */


/****************************************************************
 *
 * Delete_Times() - destructor of timing data structures
 *
 *
 */

void Delete_Times() 
{

  /* do something!! (like free up datastructures?) */

}


/****************************************************************
 *
 * Clear_Times() - clear timing information prior to each set
 *   of measurements.
 *
 *   global parameters:
 *     int master - master/slave flag 0=master, 1=slave;
 *
 */

void Clear_Times()
{
   int i;

   for (i=0; i<TIME_DATA_SZ; i++) {
      times_arr[i] = 0.0;
   }

} /* Clear_Times() */


/****************************************************************
 *
 *  Start_E_Time(t1) - start an elapse time and store at t1.
 *
 */

void Start_E_Time( int t1 )
{

  // gettimeofday(&runstruct,0);
	times_arr[t1] = (double)runstruct.tv_sec
      + ((double)runstruct.tv_usec/1000000); 

} /* Start_E_Time() */


/****************************************************************
 *
 * Store_E_Time() - compute an elapse time from t1 and store at t2
 *   note that t1 and t2 can be the same.  This enables you to do a
 *   split time (ie. t1->t2, t1->t3)
 *
 */

void Store_E_Time( int t1, int t2 )
{
   double tmp;
   //gettimeofday(&runstruct,0);
   tmp = (double)runstruct.tv_sec
      + ((double)runstruct.tv_usec/1000000);
   times_arr[t2] = tmp - times_arr[t1];
}


/****************************************************************
 *
 *  Start_CPU_Time() - start a CPU timer, storing the tick in
 *    a static buffer.
 */

void Start_CPU_Time()
{

#ifndef WIN32
   times(&startbuf);
   cpucurr = (double)startbuf.tms_utime / myclkticks;
#else
   cpucurr = (double)clock() / myclkticks;
#endif
/*#if defined WIN32 
    cpucurr = (double)clock() / myclkticks;
#else
    times(&startbuf);
   cpucurr = (double)startbuf.tms_utime / myclkticks;
#endif*/
    

} /* Start_CPU_Time() */


/****************************************************************
 *
 * Store_CPU_Time() - compute the CPU time since the last call to
 *   Start_CPU_Time or Save_CPU_Time.  store the result in t1.
 *
 */

void Store_CPU_Time( int t1 )
{
   double tmp;

#ifndef WIN32
    times(&startbuf);
   tmp = (double)(startbuf.tms_utime) / myclkticks; 
#else
   tmp = (double)clock() / myclkticks;
#endif

/*#if defined WIN32 
    tmp = (double)clock() / myclkticks;
#else
     times(&startbuf);
   tmp = (double)(startbuf.tms_utime) / myclkticks;
#endif  */ 
   times_arr[t1] = tmp - cpucurr;
   cpucurr = tmp;
}


#ifndef SERIAL
/****************************************************************
*
*  Recv_Times() - receive processe timing information.
*
*/

void Recv_Times()
{
   int    i;                    /* loop counter */
   int    pid;                  /* processor id of slave */


   if ( mypid != 0 ) {
       return;
   }

   /* receive timing data */
   for (i=0; i<nprocs; i++) {
	   comm::comm_recv(0,i,MSG_TIME2);
	   comm::comm_upkint(0,&pid,1);
      comm::comm_upkdbl(0,timings[pid],TIME_DATA_SZ);
   }

}


/****************************************************************
 *
 *  Send_Times() - send timing results to master
 *  these are later picked up by the Recv_Times() 
 *
 */

void Send_Times()
{
   comm::comm_newmsg(0);
   comm::comm_pkint(0,&(mypid),1);
   comm::comm_pkdbl(0,times_arr,TIME_DATA_SZ);
   comm::comm_send(0,0,MSG_TIME2);

}

#endif /* !SERIAL */



/****************************************************************
 *
 *  Print_Common() - common output format for timing results
 *
 */

void Print_Times()
{
   int i;
   double sum;
   double etime, mintime, maxtime, avgtime;

   mintime = 0.0;
   maxtime = 0.0;
   avgtime = 0.0;

   fprintf(stderr, "Timing Information:\n");

   for ( i=0; i<nprocs; i++ ) {
#ifndef SERIAL
      fprintf(stderr, "\nPID %d\n", i);
#endif
      fprintf(stderr, "CPU Times:\n");
      fprintf(stderr, "  ");
      fprintf(stderr, "upward: %g  ", timings[i][TIME_CPU_UPWARD]);
      fprintf(stderr, "direct: %g  ", timings[i][TIME_CPU_DIRECT]);
      fprintf(stderr, "downward: %g  ", timings[i][TIME_CPU_DOWNWARD]);
      fprintf(stderr, "mpe force: %g  \n", timings[i][TIME_CPU_FORCE]);

      fprintf(stderr, "  ");
      fprintf(stderr, "sort: %g  ", timings[i][TIME_CPU_SORT]);
      fprintf(stderr, "scale: %g  ", timings[i][TIME_CPU_RESCALE]);
      fprintf(stderr, "resize: %g \n", timings[i][TIME_CPU_RESIZE]);

      fprintf(stderr, "  ");
      fprintf(stderr, "macro pre: %g  ", timings[i][TIME_CPU_MACPRE]);
      fprintf(stderr, "macro: %g \n", timings[i][TIME_CPU_MACRO]);

      sum = timings[i][TIME_CPU_DIRECT];
      sum += timings[i][TIME_CPU_DOWNWARD];
      sum += timings[i][TIME_CPU_FORCE];
      sum += timings[i][TIME_CPU_UPWARD];
      sum += timings[i][TIME_CPU_SORT];
      sum += timings[i][TIME_CPU_RESCALE];
      sum += timings[i][TIME_CPU_RESIZE];
      sum += timings[i][TIME_CPU_MACPRE];
      sum += timings[i][TIME_CPU_MACRO];
      fprintf(stderr, "  ");
      fprintf(stderr, "Total: %g \n", sum);

#ifndef SERIAL
      fprintf(stderr, "Elapse Times:\n");
      fprintf(stderr, "  ");
      fprintf(stderr, "Send_Init_Particles: %g  ", timings[i][TIME_E_SENDINIT]);
      fprintf(stderr, "Recv_Init_Particles: %g\n", timings[i][TIME_E_RECVINIT]);
      fprintf(stderr, "  ");
      fprintf(stderr, "Send_Particles: %g  ", timings[i][TIME_E_SENDPART]);
      fprintf(stderr, "Recv_Particles: %g\n", timings[i][TIME_E_RECVPART]);
      fprintf(stderr, "  ");
      fprintf(stderr, "Send_Multipoles: %g  ", timings[i][TIME_E_SENDMPE]);
      fprintf(stderr, "Recv_Multipoles: %g \n", timings[i][TIME_E_RECVMPE]);
      fprintf(stderr, "  ");
      fprintf(stderr, "Send_Results: %g \n", timings[i][TIME_E_SENDRES]);

      etime = timings[i][TIME_E_END];
      avgtime += etime;
      if ( maxtime < etime )
	 maxtime = etime;
      if ((mintime > etime) || (mintime == 0.0))
	 mintime = etime;
#endif

   } /* for i */

#ifndef SERIAL
   avgtime /= (double)nprocs;
   fprintf(stderr, "\n");
   fprintf(stderr, "Elapse Times = ");
   for ( i=0; i<nprocs; i++ ) {
      fprintf(stderr, "%g ",timings[i][TIME_E_END]);
   }
   fprintf(stderr, "\n");
   fprintf(stderr, "               ");
   fprintf(stderr,"%g %g %g (min,avg,max)(slave)\n\n",
	   mintime, avgtime, maxtime);

#endif

   fflush(stderr);

}



/****************************************************************
 *
 *  Send_Times() - send timing results to master
 *  these are later picked up by the Recv_Times() 
 *
 */

void Collect_Print_Times() {

#ifndef SERIAL
   Send_Times();

   /*
   *  if needed, receive the timing data from all the other processes
   */
   if ( mypid == 0 ) {
      Recv_Times();
      Print_Times();
   }

#else
   int i;

   /* instead of send/recv, copy the data over */
   for ( i=0; i<TIME_DATA_SZ; i++ ) {
     timings[0][i] = times_arr[i];
   }

   Print_Times();

#endif

}


#endif /* TIMEPERF */
