/* 
*  dpmta_slviter.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_slviter.h,v 3.1 2000/04/04 02:38:06 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_slviter.h,v $
 * Revision 3.1  2000/04/04 02:38:06  wrankin
 * updates to support generic communication library
 *   - all message buffering done by application
 *   - support for eventual MPI implementation
 *
 * Revision 3.1  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.0  1999/04/01 16:45:07  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.2  1998/08/04 15:14:14  wrankin
 * added seperate multipole term parameter for virial code
 *
 * Revision 2.1  1997/11/07 16:49:10  wrankin
 * massive cleanup of code.
 *  - ansi-fication and inclusion of prototypes
 *  - removed unused variables
 *  - all (except the test) code compiles with minimal warnings under gcc.
 *
 *
 */

#ifndef _DPMTA_SLVITER_H_
#define _DPMTA_SLVITER_H_


#include "dpmta.h"

/*
 * dpmta_slviter.c
 */

void Send_Base_Info( PmtaInitDataPtr );
void Recv_Base_Info();

void Delete_Local_Buffers();
void Init_Local_Buffers1();
void Send_Initial_Particles( int, PmtaParticlePtr, int, int *, int, int,
   PmtaVector *, PmtaVector *, PmtaVector *, PmtaVector *, int );
void Recv_Final_Results(int, PmtaPartInfoPtr,PmtaPartInfoPtr, int );

void Return_Virial( double *, PmtaVector *, double *, PmtaVector * );


#endif
