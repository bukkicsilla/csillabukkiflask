/* 
*  dpmta_distmisc.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_distmisc.h,v 3.1 1999/12/24 17:55:50 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_distmisc.h,v $
 * Revision 3.1  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.0  1999/04/01 16:45:01  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.3  1998/12/01 20:59:32  wrankin
 * enhanced dynamic allocation of cells
 * cleanup of code.
 *
 * Revision 2.2  1998/04/01 20:08:06  wrankin
 * added support for HILBERT ordering
 * general cleanup of code structure (more OOP if you will)
 *
 * Revision 2.1  1997/11/07 16:49:01  wrankin
 * massive cleanup of code.
 *  - ansi-fication and inclusion of prototypes
 *  - removed unused variables
 *  - all (except the test) code compiles with minimal warnings under gcc.
 *
 *
 */

#ifndef _DPMTA_DISTMISC_H_
#define _DPMTA_DISTMISC_H_

/*
 * dpmta_distmisc.c
 */

void Dist_Init( int );
void Dist_Delete();

int getfirstchild( int );
int getparent( int );
int index2cell( int, int );
int cell2index( int, int );

#endif
