/* 
*  dpmta_macro.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

/*
 * $Id: dpmta_slvmacro.h,v 3.2 2001/02/10 03:54:28 wrankin Exp $
 *
 * RCS History:
 *
 * $Log: dpmta_slvmacro.h,v $
 * Revision 3.2  2001/02/10 03:54:28  wrankin
 * additions to support new communications primitives
 *
 * Revision 3.1  1999/12/24 17:55:50  wrankin
 * wrapped declarations in #ifndef _FILE_H_ to prevent multiple includes.
 *
 * Revision 3.0  1999/04/01 16:45:23  wrankin
 * updates for DPMTA 3.0 - addition of load balancing code
 *
 * Revision 2.1  1997/11/07 16:49:31  wrankin
 * massive cleanup of code.
 *  - ansi-fication and inclusion of prototypes
 *  - removed unused variables
 *  - all (except the test) code compiles with minimal warnings under gcc.
 *
 *
 */

#ifndef _DPMTA_SLVMACRO_H_
#define _DPMTA_SLVMACRO_H_

void MacroCleanup();
void MacroCompute( Mtype, Mtype );
void MacroInit( int, int, int, Real, int, int, int );
void MacroPreComp( Vector, Vector, Vector, Real );


#endif
