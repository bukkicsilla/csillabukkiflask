
#include "stdafx.h"

#using <mscorlib.dll>
#include <tchar.h>

using namespace System;
/*
*  dpmta_distload.c - procedures to collect and report load balancing
*  information
*
*  w. t. rankin
*
*  Copyright (c) 1999 Duke University
*  All rights reserved
*
*/

static char rcsid[] = "$Id: dpmta_distload.c,v 3.4 1999/12/24 18:03:44 wrankin Exp $";

/*
 * Revision history:
 *
 * $Log: dpmta_distload.c,v $
 * Revision 3.4  1999/12/24 18:03:44  wrankin
 * all compile time directives are now contained in the dpmta_config.h
 *   header file instead of being passed via make.
 *
 * Revision 3.3  1999/05/17 19:56:47  wrankin
 * additional cleanup for load balancing
 *
 * Revision 3.2  1999/05/17 19:03:09  wrankin
 * Added support for Load Balancing
 *
 * Revision 3.1  1999/04/01 17:26:09  wrankin
 * introducing load balancing code
 *
 *
 */

/* include files */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#if defined LINUX
#include <unistd.h>
#include <sys/times.h>
#include <sys/time.h>
#endif

#if defined WIN32
#include <time.h>
#endif

/* dpmta configuration */
#include "dpmta_config.h"

/* messaging information */
#include "comm.h"
#include "dpmta_message.h"

/* external prototypes */
#include "dpmta_distpart.h"
#include "dpmta_slvcompute.h"

/*
 * this whole module is wrapped with an ifdef so it won't
 * get compiled in if we dont want load balancing
 *
 */

#ifdef LOADBAL

/* local includes and prototypes */

void make_loadbal( double *, int * );
void send_loadbal_times( double );
void recv_loadbal_times( double * );
void send_loadbal_index( int * );
void recv_loadbal_index( int * );


/*
*  some timing and profiling storage, if needed
*/

static int    MyPid;                /* pid of process  */
static int    Nprocs;               /* total number of slave processes */
static int    Update_Incr;          /* how often to update load */
static int    Curr_Incr;            /* what iteration we are on */
static double Alpha;                /* weighting parameter */
static int    Nlevels;              /* levels in tree decomposition */

static int    *Part_Index;          /* partition index array */
static int    *Tmp_Index;           /* temporary index */
static double *Timings;             /* slave timing data */

static struct timeval runstruct;    /* used in elapse timing */

static double times_start;          /* start time for load bal */
static double times_elapse;         /* end time for load bal */

static int    Iteration;            /* iteration counter */


/****************************************************************
 *
 * Init_LoadBal() - initialize timing timing data structures
 *
 *  parameters -
 *    mp - mypid
 *    np - number of processes
 *    incr - how ofter to perform load balancing
 *    nlev - number of levels of decomposition
 *    al - load balancing weighting coefficient
 */

void Init_LoadBal( int mp, int np, int incr, int nlev, double al )
{

   int i;
   
   MyPid = mp;
   Nprocs = np;
   Update_Incr = incr;
   Nlevels = nlev;
   Alpha = al;

   Iteration = 0;
   Curr_Incr = 0;

   if ( mp == 0 ) {

      Timings = (double *)malloc(np*sizeof(double));
      if ( Timings == (double *)NULL ) {
	 fprintf(stderr,"Error: malloc failed for timing array\n");
	 exit(-1);
      }
   
      for ( i=0; i<np; i++ ) {
	 Timings[i] = 0.0;
      }

   } /* mp == 0 */

   else {
      Timings = (double *)NULL;
   }

   Part_Index = (int *)malloc(np*sizeof(int));
   if ( Part_Index == (int *)NULL ) {
      fprintf(stderr,"Error: malloc failed for partition index array\n");
      exit(-1);
   }

   for ( i=0; i<np; i++ ) {
      Part_Index[i] = 0;
   }

   Tmp_Index = (int *)malloc(np*sizeof(int));
   if ( Tmp_Index == (int *)NULL ) {
      fprintf(stderr,"Error: malloc failed for temp index array\n");
      exit(-1);
   }

   /* reset the timer, just in case */
   times_elapse = 0.0;

} /* Init_LoadBal() */


/****************************************************************
 *
 * Clear_Times() - clear timing information prior to each set
 *   of measurements.
 *
 *   parameters:
 *     int ms - master/slave flag 0=master, 1=slave;
 *
 */

void Clear_LoadBal()
{

   int i;
   
   for ( i=0; i<Nprocs; i++ ) {
      Timings[i] = 0.0;
   }
   
} /* Clear_LoadBal() */


/****************************************************************
 *
 *  Start_LoadBal() - start an elapse time and store.
 *
 */

void Start_LoadBal()
{

   gettimeofday(&runstruct,0);
   times_start = (double)runstruct.tv_sec +
      ((double)runstruct.tv_usec/1000000);

} /* Start_LoadBal() */


/****************************************************************
 *
 * Pause_LoadBal() - compute an elapse time from times_start and 
 *   add it into the accumulator
 *
 */

void Pause_LoadBal()
{
   double ttmp;

   gettimeofday(&runstruct,0);
   ttmp = (double)runstruct.tv_sec +
      ((double)runstruct.tv_usec/1000000);

   times_elapse += ( ttmp - times_start );

} /* Pause_LoadBal() */

/****************************************************************
 *
 *  Resume_LoadBal() - restart an elapse time
 *
 */

void Resume_LoadBal()
{

   gettimeofday(&runstruct,0);
   times_start = (double)runstruct.tv_sec +
      ((double)runstruct.tv_usec/1000000);

} /* Resume_LoadBal() */


/****************************************************************
 *
 * Stop_LoadBal() - compute an elapse time from the current value
 *   of times_start.
 *
 */

void Stop_LoadBal()
{
   double ttmp;

   gettimeofday(&runstruct,0);
   ttmp = (double)runstruct.tv_sec +
      ((double)runstruct.tv_usec/1000000);

   times_elapse += ( ttmp - times_start );

} /* Stop_LoadBal() */

/****************************************************************
 *
 *  Send_LoadBal() - send timing results to master
 *  these are later picked up by the Recv_LoadBal() 
 *  only do this if we are on the proper cycle.
 *
 *  also reset the timing counter.
 *
 *  not that we reset the increment counter on the receive
 *  receive side (for MIMD).
 *
 */

void Send_LoadBal()
{

   if ( Update_Incr != 0 ) {
      Curr_Incr++;
      Iteration++;
      if ( Curr_Incr >= Update_Incr ) {
	 send_loadbal_times(times_elapse);
	 times_elapse = 0.0;
      } /* curr >= update */
   } /* update != 0 */

} /* Send_LoadBal() */


/****************************************************************
*
*  Recv_LoadBal() - receive and printout slave timing
*    information.  only do this if we are on the proper
*    cycle.
*
*/

void Recv_LoadBal()

{
   int    i;                    /* loop counter */

   /*
    * now we need to decide if we want to do load balancing
    * and send a message to each of the dpmta processes.
    *
    * if the update increment is equal to zero, then
    * we never fo load balancing.
    *
    * the curr-incr counter is incremented by the sending
    * side (for MIMD only).
    *
    */
   
   if ( Update_Incr != 0 ) {
      if ( Curr_Incr >= Update_Incr ) {
	 Curr_Incr = 0;

	 if ( MyPid == 0 ) {

	    /* collect all the timing information from everyone */
	    recv_loadbal_times(Timings);

	    /* get the contents of the current partition */
	    Partition_ListIndex(Part_Index);

	    fprintf(stderr,"%d Old Size: ", Iteration);
	    for ( i=1; i<Nprocs; i++ ) {
	       fprintf(stderr,"%d ",Part_Index[i]-Part_Index[i-1]);
	    }
	    fprintf(stderr,"%d ",(0x1<<(3*(Nlevels-1)))-Part_Index[Nprocs-1]);
	    fprintf(stderr,"\n");

	    /* create new partition set*/
	    make_loadbal(Timings,Part_Index);

	    fprintf(stderr,"%d New Size: ", Iteration);
	    for ( i=1; i<Nprocs; i++ ) {
	       fprintf(stderr,"%d ",Part_Index[i]-Part_Index[i-1]);
	    }
	    fprintf(stderr,"%d ",(0x1<<(3*(Nlevels-1)))-Part_Index[Nprocs-1]);
	    fprintf(stderr,"\n");

	 
	    /* somewhere in here we compute the new indices */
	    send_loadbal_index(Part_Index);

	 } /* MyPid = 0 */

	 /* receive the new data */
	 recv_loadbal_index(Part_Index);

	 /* okay, so rearrange things now */
	 Partition_Update(Part_Index);

	 /* reconfigure cell rtable and invers interaction lists */
	 Slave_Repartition();

      } /* Curr >= Update */

   } /* Update != 0 */

} /* Recv_LoadBal() */


/****************************************************************
 *
 *  Delete_LoadBal() - clean up and deallocate all dynamic
 *    structures.
 *
 */

void Delete_LoadBal()
{

   if ( MyPid == 0 ) {
      free(Timings);
   }

   free(Part_Index);
   free(Tmp_Index);

} /* Delete_LoadBal() */


/****************************************************************
 *
 *  all the following are internal to the module.
 *
 */

/****************************************************************
 *
 *  send_loadbal_times() - send timing results to master
 *  these are later picked up by the recv_loadbal_times() 
 *  only do this if we are on the proper cycle.
 *
 *  also reset the timing counter.
 *
 *  not that we reset the increment counter on the receive
 *  receive side (for MIMD).
 *
 */

void send_loadbal_times(double time)
{
   comm_newmsg(0);
   comm_pkint(0, &(MyPid), 1);
   comm_pkdbl(0, &(time), 1);
   comm_send(0, 0, MSG_LBAL2);

} /* send_loadbal_times() */


/****************************************************************
*
*  recv_loadbal_times() - receive slave timing information. 
*
*/

void recv_loadbal_times( double *times)

{
   int    i;                    /* loop counter */
   int    pid;                  /* processor id of slave */

   for (i=0; i<Nprocs; i++) {
      comm_recv(i,-1,MSG_LBAL2);
      comm_upkint(i,&pid,1);
      comm_upkdbl(i,&(times[pid]),1);
   } /* for i */

   fprintf(stderr,"%d Proc Time: ", Iteration);
   for (i=0; i<Nprocs; i++) {
      fprintf(stderr,"%g ",times[i]);
   }
   fprintf(stderr,"\n");

} /* recv_loadbal_times() */



/****************************************************************
 *
 *  send_loadbal_index() - send new index to all slaves
 *
 */

void send_loadbal_index( int *newindex )
{
   int i;
   
   for ( i=0; i<Nprocs; i++ ) {
      comm_newmsg(i);
      comm_pkint(i,&(MyPid),1);
      comm_pkint(i,newindex,Nprocs);
      comm_send(i,i,MSG_LBAL3);
   }

} /* send_loadbal_index() */


/****************************************************************
 *
 *  recv_loadbal_index() - receive new index 
 *
 */

void recv_loadbal_index( int *newindex )
{
   int pid;
   
   comm_recv(0,-1,MSG_LBAL3);
   comm_upkint(0,&pid,1);
   comm_upkint(0,newindex,Nprocs);

} /* recv_loadbal_index() */


/****************************************************************
 *
 *  make_loadbal() - load balance index based upon input from 
 *    timings.
 *
 *  input: 
 *    timings[] - array of timing values by processor
 *    pindex[] - starting index of processor domain.
 *
 *  updates:
 *    pindex[] - returns new values
 *
 */

void make_loadbal( double *timings, int *pindex )
{

   int i;
   double dtmp;
   int maxcell;

   maxcell = 0x1 << ( 3 * (Nlevels-1));

   /* compute the size of each partition */
   for ( i=1; i<Nprocs; i++ ) {
      Tmp_Index[i-1] = pindex[i] - pindex[i-1];
   }
   Tmp_Index[Nprocs-1] = maxcell - pindex[Nprocs-1];



#ifdef BALANCE1

   /*
    * incremental load balancing
    *
    * this algorithm shift the index boundaries based
    * upon the timing values for the two regions on
    * either side of the boundary.
    *
    */

   pindex[0] = 0;
   for ( i=1; i<Nprocs; i++ ) {
      dtmp = (int)((double)Tmp_Index[i-1] * (double)Tmp_Index[i] * 
		    (timings[i] - timings[i-1]) /
		    ( 2.0 *((double)Tmp_Index[i-1] * timings[i] +
			    (double)Tmp_Index[i] * timings[i-1])));
      pindex[i] += dtmp;
   }

#else
#ifdef BALANCE2

   /*
    * slow incremental balancing
    *
    * like the first case, but onle moves a single cell
    * at a time, instead of trying to figure out an optimum.
    *
    */

   pindex[0] = 0;
   for ( i=1; i<Nprocs; i++ ) {
      if ( timings[i-1] < timings[i] ) {
	 pindex[i]++;
      }
      else {
	 pindex[i]--;
      }
   }

#else
#ifdef BALANCE3

   /*
    * global optimization load balancing
    *
    * this algorithm readjusts the complete set of 
    * index boundaries based upon the timing values all
    * of the processors.
    *
    * perhaps we should also look at dampening this by
    * taking a weighted average between the new sizes and
    * the old sizes.  NOT IMPLEMENTED (we lie - see below).
    *
    */

   dtmp = 0.0;
   for ( i=0; i<Nprocs; i++ ) {
      dtmp += (double)Tmp_Index[i] / timings[i];
   }
   pindex[0] = 0;
   for ( i=1; i<Nprocs; i++ ) {
      pindex[i] = pindex[i-1] +
	 (double)(Tmp_Index[i-1]*maxcell) / (timings[i-1] * dtmp);
   }

#else /* DEFAULT */

   /*
    * global optimization load balancing with dampening.
    *
    * this algorithm readjusts the complete set of 
    * index boundaries based upon the timing values all
    * of the processors.
    *
    * we also look at dampening this by
    * taking a weighted average between the new sizes and
    * the old sizes.
    *
    */

   dtmp = 0.0;
   for ( i=0; i<Nprocs; i++ ) {
      dtmp += (double)Tmp_Index[i] / timings[i];
   }
   pindex[0] = 0;
   for ( i=1; i<Nprocs; i++ ) {
      pindex[i] = pindex[i-1] +
	 Alpha * (double)(Tmp_Index[i-1]*maxcell) / (timings[i-1] * dtmp) +
	 (1.0 - Alpha) * (double)(Tmp_Index[i-1]);

   }

#endif /* BALANCE3 */
#endif /* BALANCE2 */
#endif /* BALANCE1 */

} /* make_loadbal() */

#endif /* LOADBAL */
