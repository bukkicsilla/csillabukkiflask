/* 
*  dpmta_slvpcalc.h - prototypes for DPMTA internal functions
*
*  w. t. rankin
*
*  Copyright (c) 1997 Duke University
*  All rights reserved
*
*  this files contains the prototype definitions for the external
*  functions provided by the corresponding '.c' file.
*
*/

#ifndef _DPMTA_SLVPCALC_H_
#define _DPMTA_SLVPCALC_H_

void Slave_Direct_Calc();
void Dump_Particles();

#endif
