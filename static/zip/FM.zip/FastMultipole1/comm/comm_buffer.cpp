
#include "stdafx.h"

#using <mscorlib.dll>
#include <tchar.h>

using namespace System;

/*
 *  comm_buffer.c - buffer manipulation routines for communication
 *    library
 *
 *  w. t. rankin
 *
 *  Copyright (c) 2000 Bill Rankin
 *  All Rights Reserved
 *
 */

static char RCSid[] = "$Id: comm_buffer.c,v 1.2 2001/01/19 01:40:06 wrankin Exp $";

#include <stdlib.h>
#include <stdio.h>

#include "comm_buffer.h"


/* global constants */


/****************************************************************
 *
 *  comm_buf_create() - 
 *
 *  create a communications buffer, setting the initital
 *  array sizes to inum and fnum.
 *
 */

CommBufPtr comm_buf_create( int inum, int fnum )
{
   int stat;
   CommBufPtr cb;

   cb = (CommBufPtr)malloc(sizeof(CommBuf));
   if ( cb == (CommBufPtr)NULL ) {
      fprintf(stderr,"Error: failed to allocate CommBuf\n");
      return NULL;
   }

   cb->iarray = (int *)NULL;
   cb->imax = 0;
   cb->isize = 0;
   cb->icurr = 0;

   cb->farray = (double *)NULL;
   cb->fmax = 0;
   cb->fsize = 0;
   cb->fcurr = 0;

   if ((fnum > 0) || (inum > 0)) {
      stat = comm_buf_resize( cb, inum, fnum );
      if ( stat < inum+fnum ) {
	 fprintf(stderr,"Error: failed to alloc CommBuf array storage\n");
	 comm_buf_delete( cb );
	 return NULL;
      }
   }

   return cb;

} /* comm_buf_init() */


/****************************************************************
 *
 *  comm_buf_clear() -
 *
 *  clear the buffer arrays by setting their indices back to 0
 *  prepares the buffer for a new message.
 *
 */

void comm_buf_clear( CommBufPtr cb )
{

   cb->icurr = 0;
   cb->fcurr = 0;
   cb->isize = 0;
   cb->fsize = 0;

} /* comm_buf_clear() */


/****************************************************************
 *
 *  comm_buf_reset() -
 *
 *  resets the data pointers in the buffer arrays by setting 
 *  their indices back to 0.
 *  prepares the buffer to be unpacked.
 *
 */

void comm_buf_reset( CommBufPtr cb )
{

   cb->icurr = 0;
   cb->fcurr = 0;

} /* comm_buf_clear() */


/****************************************************************
 *
 *  comm_buf_resize() - allocate additional bufferspace (if
 *    needed.  allocations are rounded up to the next highest 
 *    block size.
 *
 *  input: buffer pointer, requested size of the new buffers.
 *    sending a size of 0 is legal since this routine will only
 *    grow the buffers and never shrink them.
 *
 *  returns: the number of additional elements allocated.
 *
 *  the exising contents of the buffer are maintained by the
 *  realloc call, which does a memcpy if the new buffer is
 *  larger than the old one.
 *
 */

int comm_buf_resize( CommBufPtr cb, int inum, int fnum )
{

   int rnum = 0;
   int nsize;

   if ( inum > cb->imax ) {
      nsize = ( (inum-1)/COMM_BLK_SIZE + 1 ) * COMM_BLK_SIZE;
      cb->iarray = (int *)realloc((void *)(cb->iarray), nsize*sizeof(int));
      if ( cb->iarray == (int *)NULL ) {
	 fprintf(stderr,"Error: failed to realloc bufferspace\n");
	 return -1;
      }
      rnum += ( nsize - cb->imax );
      cb->imax = nsize;
   }

   if ( fnum > cb->fmax ) {
      nsize = ( (fnum-1)/COMM_BLK_SIZE + 1 ) * COMM_BLK_SIZE;
      cb->farray = (double *)realloc((void *)(cb->farray), nsize*sizeof(double));
      if ( cb->farray == (double *)NULL ) {
	 fprintf(stderr,"Error: failed to realloc bufferspace\n");
	 return -1;
      }
      rnum += ( nsize - cb->fmax );
      cb->fmax = nsize;
   }

   return rnum;

} /* comm_buf_resize() */



/****************************************************************
 *
 *  comm_buf_addint() - append integer array onto buffer.
 *
 *  input: buffer pointer, number of elements, element array 
 *
 *  returns: the number of elements placed in buffer.
 *
 */

int comm_buf_addint( CommBufPtr cb, int *ibuff, int inum )
{

   int i;
   int stat;
   int *ip;

   if ( cb->icurr + inum > cb->imax ) {
      stat = comm_buf_resize( cb, cb->icurr+inum, 0 );
      if ( stat < 0 ) {
	 return stat;
      }
   }

   ip = &((cb->iarray)[cb->icurr]);
   /* memcpy( ip, ibuff, inum*sizeof(int) ); */
   for ( i=0; i<inum; i++ ) {
      ip[i] = ibuff[i];
   }

   cb->icurr += inum;
   cb->isize += inum;

   return inum;

} /* comm_buf_addint() */


/****************************************************************
 *
 *  comm_buf_adddbl() - append double array onto buffer.
 *
 *  input: buffer pointer, number of elements, element array 
 *
 *  returns: the number of elements placed in buffer.
 */

int comm_buf_adddbl( CommBufPtr cb, double *fbuff, int fnum )
{

   int i;
   int stat;
   double *fp;

   if ( cb->fcurr + fnum > cb->fmax ) {
      stat = comm_buf_resize( cb, 0, cb->fcurr+fnum );
      if ( stat < 0 ) {
	 return stat;
      }
   }

   fp = &((cb->farray)[cb->fcurr]);
   /* memcpy( fp, fbuff, fnum*sizeof(double) ); */
   for ( i=0; i<fnum; i++ ) {
      fp[i] = fbuff[i];
   }

   cb->fcurr += fnum;
   cb->fsize += fnum;

   return fnum;

} /* comm_buf_adddbl() */


/****************************************************************
 *
 *  comm_buf_getint() - copies buffer contents to integer array
 *
 *  input: buffer pointer, number of elements, element array 
 *
 *  returns: the number of elements placed in array.
 *
 */

int comm_buf_getint( CommBufPtr cb, int *ibuff, int inum )
{

   int i;
   int stat;
   int *ip;

   ip = &((cb->iarray)[cb->icurr]);

   if ( cb->icurr + inum > cb->imax ) {
      stat = cb->imax - cb->icurr;
      if ( stat > 0 ) {
	 /* memcpy( ibuff, ip, stat*sizeof(int) ); */
	 for ( i=0; i<stat; i++ ) {
	    ibuff[i] = ip[i];
	 }
      }
   }
   else {
      stat = inum;
      /* memcpy( ibuff, ip, stat*sizeof(int) ); */
      for ( i=0; i<stat; i++ ) {
	 ibuff[i] = ip[i];
      }
   }
   cb->icurr += stat;

   return stat;

} /* comm_buf_getint() */


/****************************************************************
 *
 *  comm_buf_getdbl() -  copies buffer contents to double array
 *
 *  input: buffer pointer, number of elements, element array 
 *
 *  returns: the number of elements placed in array.
 */

int comm_buf_getdbl( CommBufPtr cb, double *fbuff, int fnum )
{

   int i;
   int stat;
   double *fp;

   fp = &((cb->farray)[cb->fcurr]);

   if ( cb->fcurr + fnum > cb->fmax ) {
      stat = cb->fmax - cb->fcurr;
      if ( stat > 0 ) {
	 /* memcpy( fbuff, fp, stat*sizeof(double) ); */
	 for ( i=0; i<stat; i++ ) {
	    fbuff[i] = fp[i];
	 }
      }
   }
   else {
      stat = fnum;
      /* memcpy( fbuff, fp, stat*sizeof(double) ); */
      for ( i=0; i<stat; i++ ) {
	 fbuff[i] = fp[i];
      }
   }
   cb->fcurr += stat;

   return stat;

} /* comm_buf_getdbl() */


/****************************************************************
 *
 * comm_buf_delete() - free up structure associates with a 
 *   comm buffer.
 *
 */

void comm_buf_delete( CommBufPtr cb )
{

   if ( cb != (CommBufPtr)NULL ) {
      if ( cb->iarray != (int *)NULL ) {
	 free( cb->iarray );
      }
      
      if ( cb->farray != (double *)NULL ) {
	 free( cb->farray );
      }
   free( cb );
   }

} /* comm_buf_delete() */


/****************************************************************
 *
 * comm_buf_dump() - dumps current contents of buffer to stderr
 *
 */

void comm_buf_dump( CommBufPtr cbp )
{

   int i;

   fprintf(stderr,"Comm: nints=%d, ndbls=%d, ip=%d, fp=%d\n",
	   cbp->isize,cbp->fsize,cbp->icurr,cbp->fcurr);

   fprintf(stderr,"  Ints:");
   for (i=0; i<cbp->isize; i++) {
      fprintf(stderr," %d",cbp->iarray[i]);
   }
   fprintf(stderr,"\n");

   fprintf(stderr,"  Dbls:");
   for (i=0; i<cbp->fsize; i++) {
      fprintf(stderr," %g",cbp->farray[i]);
   }
   fprintf(stderr,"\n");

} /* comm_buf_dump() */
