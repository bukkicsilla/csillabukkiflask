/*
 *  comm_prims.c - communication primitives using local buffering
 *    scheme.  this is meant to provide a generic messaging interface
 *    that can be implemented using a variety of different message
 *    passing packages.
 *
 *    in reality - this is supposed to allow almost any messaging 
 *    system to look like PVM3.
 *
 *  w. t. rankin
 *
 *  Copyright (c) 2000 Duke University
 *  All Rights Reserved
 *
 * RCSid: $Id: comm.h,v 1.2 2001/01/19 01:40:06 wrankin Exp $
 *
 * RSC History:
 *
 * $Log: comm.h,v $
 * Revision 1.2  2001/01/19 01:40:06  wrankin
 * many changes.  code in general now works.
 *
 * Revision 1.1  2000/04/04 02:37:49  wrankin
 * updates to support generic communication library
 *   - all message buffering done by application
 *   - support for eventual MPI implementation
 *
 *
 */

#ifndef _COMM_H_
#define _COMM_H_



/*
 * indicate teh number of total procs, the number of send buffs,
 * and the number of receive buffers.
 *
 * this is assuming MIMD and embedded - can we make this
 * re-entrant so as to allow for multiple communication
 * contexts?  perhaps use some sort of context structure?
 *
 * this structure would contain the arrays of processors
 * that are communicating, as well as the arrays of send
 * and receive buffers that are used to communicate.
 *
 * this would be similar to an MPI context, or a pvm
 * tid array.
 *
 */

void comm_init( int nprocs );

void comm_delete();

int comm_mypid();

void comm_mkbuffs( int numsbuf, int numrbuf );

void comm_newmsg( int );

void comm_pkint( int buf, int *ibuf, int nint );
void comm_pkdbl( int buf, double *fbuf, int ndbl );

void comm_upkint( int buf, int *ibuf, int nint );
void comm_upkdbl( int buf, double *fbuf, int ndbl );

void comm_send( int buf, int proc, int msg );

void comm_recv( int buf, int proc, int msg );

/*
 * immediate pack and sends - no buffering needed.
 */

void comm_pkint_send( int proc, int msg, int nint, int *ibuf );
void comm_pkdbl_send( int proc, int msg, int ndbl, double *fbuf );

void comm_recv_upkint( int proc, int msg, int nint, int *ibuf );
void comm_recv_upkdbl( int proc, int msg, int ndbl, double *fbuf );

/*
 * debugging procedures
 */

void comm_dump_send_buf( int );
void comm_dump_recv_buf( int );

#endif
