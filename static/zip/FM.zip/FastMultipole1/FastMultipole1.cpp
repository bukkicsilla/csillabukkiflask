// This is the main project file for VC++ application project 
// generated using an Application Wizard.

#include "stdafx.h"

#using <mscorlib.dll>
#include <tchar.h>

using namespace System;
#include <math.h>
#include <iostream>
#include <stdio.h>
#include "ffttest.h"
#include "mpe_testC.h"
#include "mpe_testLJ.h"
#include "dpmta_test.h"


// This is the entry point for this application
int _tmain(int argc , char **argv){
    // TODO: Please replace the sample code below with your own.
    
 if (argc == 1){
  fprintf(stderr,"Usage: %s <testnumber>\n", argv[0] );
  printf("1.   fftest.cpp \n");
  printf("2.   mpe_testC.cpp \n");
  printf("3.   mpe_testLJ.cpp \n");
  printf("4.   dpmta_test.cpp \n"); 
  exit(-1);}

  
     if ( ( atoi( argv[1] ) == 1 ) && ( argc != 4)) {
      fprintf(stderr,"Usage: %s <test> <mp> <nparts>\n", argv[0] );
      exit(-1);
   }
   
 
   if ( ( atoi( argv[1] ) == 4 ) && ( argc != 10 ) ) {
      fprintf(stderr,
              "%s <test>  <#procs> <#lvls> <#parts> <fft> <mp> <theta> <iter> <pbc>\n",
              argv[0] );
      exit(-1);}
   
 
   
   
   
   if (   (  ( atoi( argv[1] ) == 2) || ( atoi( argv[1] ) == 3 ) || ( atoi( argv[1] ) == 11 )  )  &&  (argc != 2) ) {
      fprintf(stderr,
              "%s <test>\n",
              argv[0]);
      exit(-1);
   }
   
   
     
   
   switch( atoi( argv[1] ) )
   {
   case 0x01:
      printf("You have choisen ffttest\n");
	  ffttest_main(argv);
      break;
   case 0x02:
      printf("You have choisen mpe_testC\n");
	  mpe_testC_main(argv);
      break;
   case 0x03:
      printf("You have choisen mpe_testLJ\n");
	  mpe_testLJ_main(argv);
      break;
   case 0x04:
	  printf("You have choisen dpmta_test\n");
	  dpmta_test_main(argv);
      break;
 
     default:
      printf("There is no testprogramm with this number!\n");
      return 0;
   }

    return 0;
}